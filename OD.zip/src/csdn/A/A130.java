package csdn.A;

//
public class A130 {

}
