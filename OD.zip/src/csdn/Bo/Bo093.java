package csdn.Bo;

import java.util.ArrayList;
import java.util.Scanner;

// 英文输入法
public class Bo093 {

    public static int count = 0;
    public static ArrayList<String> wordList;
    public static String word = "";

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input1 = in.nextLine();
        String input2 = in.nextLine();
        wordList = new ArrayList<>();

        for (int i = 0; i < input1.length(); i++) {
            char c = input1.charAt(i);
            if (!((c <= 'z' && c >= 'a') || (c <= 'Z' && c >= 'A')) || c == ' ' || c == '\'') {
                get_word();
                continue;
            }
            word += c;
            if (i == input1.length() - 1) {
                get_word();
            }
        }
        boolean flag = false;
        String result = "";
        for (String wd : wordList) {
            if (wd.startsWith(input2)) {
                flag = true;
                result += wd + " ";
            }
        }
        if (!flag) {
            System.out.println(input2);
        } else {
            System.out.println(result);
        }


    }

    public static void get_word() {
        if (word.length() > 0) {
            wordList.add(word);
            word = "";
        }
    }
}
