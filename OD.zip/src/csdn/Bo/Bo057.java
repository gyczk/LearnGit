package csdn.Bo;


import java.util.Scanner;

// 分月饼
public class Bo057 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();
        int p = n - m;
        int count = 0;

        if (m > n) {
            System.out.println(0);
            return;
        }

        int i = 0;
        for (i = 0; i < p; i++) {
            count = count + distribute(m - 1, p - i, i);
        }
        System.out.println(count);

    }

    public static int distribute(int m, int p, int k) {
        if (p <= 0) return 0;
        if (m <= 0) return 0;

        if (m == 1) {
            if (p >= k && p <= k + 3) {
                return 1;
            }
            return 0;
        }
        int ncount = 0;
        for (int i = k; i <= k + 3; i++) {
            ncount = ncount + distribute(m - 1, p - i, i);
        }
        return ncount;
    }
}
