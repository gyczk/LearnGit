package csdn.Bo;


import java.util.Scanner;


// 最小传输时延II
public class Bo018 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();

        int[][] times = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                times[i][j] = in.nextInt();
            }
        }

        System.out.println(bfs(times));
    }

    public static int bfs(int[][] m) {

        int M = m.length, N = m[0].length;
        int[][] dp = new int[M][N];
        dp[0][0] = m[0][0];
        // 初始化第0列（它只可能从上面转换而来）
        for (int i = 1; i < M; ++i) {
            if (m[i][0] != m[i - 1][0]) {    // 当前值和上一个值不一样
                dp[i][0] = m[i][0] + dp[i - 1][0]; // 那么它需要在dp[i - 1][0]的基础上+自己的耗费
            } else {
                dp[i][0] = m[i][0] + dp[i - 1][0] - 1;
            }
        }

        //初始化第1列（它只可能从左边转换而来）
        for (int j = 1; j < N; ++j) {
            if (m[0][j] != m[0][j - 1]) {
                dp[0][j] = m[0][j] + dp[0][j - 1];
            } else {
                dp[0][j] = m[0][j] + dp[0][j - 1] - 1;
            }
        }

        for (int i = 1; i < M; ++i) {
            for (int j = 1; j < N; ++j) {
                int up = m[i][j] + dp[i - 1][j]; // 从上面走来
                if (m[i][j] == m[i - 1][j]) {
                    up = up - 1;
                }

                int left = m[i][j] + dp[i][j - 1];  // 从左边来
                if (m[i][j] == m[i][j - 1]) {
                    left = left - 1;
                }

                int tri = m[i][j] + dp[i - 1][j - 1]; // 从上斜边来
                if (m[i][j] == m[i][j - 1]) {
                    tri = tri - 1;
                }
                dp[i][j] = Math.min(left, Math.min(up, tri));
            }
        }

        return dp[M - 1][N - 1];
    }
}


