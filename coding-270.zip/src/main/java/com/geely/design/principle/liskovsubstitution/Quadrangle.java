package com.geely.design.principle.liskovsubstitution;

/**
 * Created by geely
 */
public interface Quadrangle {
    long getWidth();
    long getLength();

}
