package csdn.Bo;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


// 内存资源分配
public class Bo119 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String memoryInfo = in.next();
        String applyList = in.next();

        List<Integer> memoryList = new ArrayList<>();
        List<String> memoryInfoList = new ArrayList<>(Arrays.asList(memoryInfo.split(",")));
        for (String info : memoryInfoList) {
            int colonIndex = info.indexOf(":");
            int size = Integer.parseInt(info.substring(0, colonIndex));
            int count = Integer.parseInt(info.substring(colonIndex + 1));
            for (int i = 0; i < count; i++) {
                memoryList.add(size);
            }
        }
        List<Integer> applyMemoryList = new ArrayList<>();
        List<String> applyListList = new ArrayList<>(Arrays.asList(applyList.split(",")));
        for (String apply : applyListList) {
            applyMemoryList.add(Integer.parseInt(apply));
        }

        List<Boolean> resultList = new ArrayList<>();
        for (int applyMemory : applyMemoryList) {
            boolean flag = false;
            for (int i = 0; i < memoryList.size(); i++) {
                if (memoryList.get(i) >= applyMemory) {
                    flag = true;
                    memoryList.remove(i);
                    break;
                }
            }
            resultList.add(flag);
        }

        for (int i = 0; i < resultList.size(); i++) {
            System.out.print(resultList.get(i));
            if (i != resultList.size() - 1) {
                System.out.print(",");
            }
        }
    }

}
