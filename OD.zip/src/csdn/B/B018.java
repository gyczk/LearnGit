package csdn.B;

import java.util.*;

// AI 识别面板
public class B018 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        in.nextLine();

        Integer[][] items = new Integer[n][4];
        for (int i = 0; i < n; i++) {
            int[] data = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
            //分别表示输入的各项指标
            items[i] = new Integer[]{data[0], (data[1] + data[3]) / 2, (data[2] + data[4]) / 2, (data[3] - data[1]) / 2};
        }

        //new一个MyComparator的对象
        MyComparator myComparator = new MyComparator();
        Arrays.sort(items, myComparator);

        ArrayList<Integer[]> all_lights = new ArrayList<>();
        Integer[] base = items[0];
        all_lights.add(items[0]);

        String result = "";
        int x = 1;
        while (x < items.length) {
            Collections.sort(all_lights, new Comparator<Integer[]>() {
                @Override
                public int compare(Integer[] p1, Integer[] p2) {
                    return p1[1] - p2[1];
                }
            });
            Integer[] light = items[x];
            if (light[2] - base[2] <= base[3]) {
                all_lights.add(light);
            } else {
                for (Integer[] temp : all_lights) {
                    result += temp[0] + " ";
                }
                all_lights.clear();
                base = light;
                all_lights.add(base);
            }
            x++;
        }

        if (all_lights.size() == 0) {
            System.out.println();
        } else {
            Collections.sort(all_lights, new Comparator<Integer[]>() {
                @Override
                public int compare(Integer[] p1, Integer[] p2) {
                    return p1[1] - p2[1];
                }
            });
            for (Integer[] temp : all_lights) {
                result += temp[0] + " ";
            }
            System.out.println(result.substring(0, result.length() - 1));
        }

    }


}

class MyComparator implements Comparator<Integer[]> {
    @Override
    public int compare(Integer[] o1, Integer[] o2) {
        return -o2[2] + o1[2];
    }
}