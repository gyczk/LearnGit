package com.geely.design.pattern.creational.factorymethod;

/**
 * Created by geely
 */
public abstract class Video {
    public abstract void produce();

}
