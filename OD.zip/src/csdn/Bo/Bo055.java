package csdn.Bo;


import java.util.Scanner;

// 可以组成网络的服务器
public class Bo055 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();

        int[][] matrix = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                matrix[i][j] = in.nextInt();
            }
        }

        int result = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                result = Math.max(result, bfs(n, m, matrix, i, j, 0));
            }
        }

        System.out.println(result);
    }

    public static int bfs(int n, int m, int[][] matrix, int i, int j, int count) {
        if (i < 0 || i >= n || j < 0 || j >= m || matrix[i][j] == 0) {
            return count;
        }

        count++;
        matrix[i][j] = 0;

        count = bfs(n, m, matrix, i - 1, j, count);
        count = bfs(n, m, matrix, i + 1, j, count);
        count = bfs(n, m, matrix, i, j - 1, count);
        count = bfs(n, m, matrix, i, j + 1, count);

        return count;
    }
}
