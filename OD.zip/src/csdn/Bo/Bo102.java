package csdn.Bo;

import java.util.Scanner;

// 密钥格式化
public class Bo102 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int k = in.nextInt();
        String input_str = in.next();
        String[] strs = input_str.split("-");

        String first = strs[0];

        String temp = "";
        for (int i = 1; i < strs.length; i++) {
            temp += strs[i];
        }
        String[] chars = temp.split("");

        String result = "";
        result += first;
        for (int i = 0; i < chars.length; i++) {
            String v = chars[i].toUpperCase();
            if (i % k == 0) {
                v = "-" + v;
            }
            result += v;
        }


        System.out.println(result);
    }
}


