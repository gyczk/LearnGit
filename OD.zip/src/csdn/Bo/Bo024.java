package csdn.Bo;


import java.util.Arrays;
import java.util.Scanner;

// 高效的任务规划
public class Bo024 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int[][][] tasks = new int[m][][];

        for (int i = 0; i < m; i++) {
            int n = in.nextInt();
            int[][] task = new int[n][2];
            for (int j = 0; j < n; j++) {
                task[j][0] = in.nextInt();
                task[j][1] = in.nextInt();
            }
            tasks[i] = task;
        }

        for (int[][] task : tasks) {
            // 按照运行时间降序排序
            Arrays.sort(task, (a, b) -> b[1] - a[1]);

            int end_time = 0;
            int result = 0;
            for (int[] info : task) {
                int old_cost = info[0];
                int run_cost = info[1];

                end_time += old_cost;
                result = Math.max(result, end_time + run_cost);
            }

            System.out.println(result);
        }

    }
}
