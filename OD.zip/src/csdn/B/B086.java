package csdn.B;


import java.util.Arrays;
import java.util.Scanner;

// 最多团队
public class B086 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] nums = new int[n];
        for (int i = 0; i < n; i++) {
            nums[i] = in.nextInt();
        }
        // 先排序
        Arrays.sort(nums);
        int threshold = in.nextInt();
        int count = 0;
        // 卡阈值
        for (int num : nums) {
            if (num >= threshold) {
                count++;
            }
        }
        // 左右两个指针一起向中间移动
        int left = 0, right = n - count - 1;
        while (left < right) {
            if (nums[left] + nums[right] >= threshold) {
                count++;
                left++;
                right--;
            } else {
                left++;
            }
        }
        System.out.println(count);
    }
}

