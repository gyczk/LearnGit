package csdn.Bo;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

// 任务最优调度
public class Bo032 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        Integer[] v = Arrays.stream(in.next().split(",")).map(Integer::parseInt).toArray(Integer[]::new);
        int N = in.nextInt();

        //数字出现次数统计
        HashMap<Integer, Integer> num_count = new HashMap<>();

        for (Integer t : v) {
            num_count.put(t, num_count.getOrDefault(t, 0) + 1);
        }

        //转为数组，保存的是[任务类型出现次数, 0]
        ArrayList<Integer[]> tasks = new ArrayList<>();
        for (Integer index : num_count.keySet()) {
            tasks.add(new Integer[]{num_count.get(index), 0});
        }

        tasks.sort((a, b) -> b[0] - a[0]);

        //任务总数
        int total = v.length;
        int result = 0;

        while (total > 0) {
            result++;
            boolean flag = true;
            for (Integer[] task : tasks) {
                //三个条件来判断
                //1：当前种类是否有任务。2：任务冷却结束。3：本轮时间可用
                if (flag && task[0] > 0 && task[1] == 0) {
                    //本轮时间已被使用
                    flag = false;
                    //本种类任务减1
                    task[0]--;
                    //总等待任务减1
                    total--;
                    //冷却时间置为N
                    task[1] = N;
                } else {
                    // 冷却任务
                    if (task[1] > 0) {
                        task[1]--;
                    }
                }
            }
        }

        System.out.println(result);
    }
}

