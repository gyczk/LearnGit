package csdn.Bo;


import java.util.*;

// 最长广播效应
public class Bo021 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
        int T = in.nextInt();

        // 初始化节点之间的关系，
        // key为节点，value为相邻节点set
        HashMap<Integer, HashSet<Integer>> map_info = new HashMap<>();
        for (int i = 0; i < T; i++) {
            int start = in.nextInt();
            int end = in.nextInt();
            if (!map_info.containsKey(start)) {
                map_info.put(start, new HashSet<>());
            }
            if (!map_info.containsKey(end)) {
                map_info.put(end, new HashSet<>());
            }
            //注意这里是无向图，所以节点是相互连接的！
            map_info.get(start).add(end);
            map_info.get(end).add(start);
        }

        // 起始节点
        int head = in.nextInt();
        Deque<Integer> node_queue = new LinkedList<>();
        node_queue.add(head);
        // 是否已经访问过节点
        Set<Integer> visited = new HashSet<>();
        int[] d = new int[N + 1];  // 最短路径长度数组
        while (!node_queue.isEmpty()) {
            int poll = node_queue.pollFirst();
            for (int node : map_info.get(poll)) {
                if (!visited.contains(node)) {
                    visited.add(node);
                    d[node] = d[poll] + 1;
                    node_queue.add(node);
                }
            }
        }

        //求最长
        int max_time = 0;
        for (int i = 1; i < N + 1; i++) {
            max_time = Math.max(max_time, d[i]);
        }
        System.out.println(max_time * 2);
    }
}
