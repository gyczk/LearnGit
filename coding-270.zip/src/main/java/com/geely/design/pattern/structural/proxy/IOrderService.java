package com.geely.design.pattern.structural.proxy;

/**
 * Created by geely
 */
public interface IOrderService {
    int saveOrder(Order order);
}
