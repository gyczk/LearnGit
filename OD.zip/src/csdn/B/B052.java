package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

// 	数字序列比大小
public class B052 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        int[] a = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        int[] b = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();

        Arrays.sort(a);
        Arrays.sort(b);
        //审核大佬请注意，这是leetcode官方的题解。

        int m = b.length;
        int k = a.length;
        int count = 0;
        for (int i = 0, j = 0; i < m && j < k; i++, j++) {
            while (j < k && b[i] > a[j]) {
                j++;
            }
            if (j < k) {
                count++;
            }
        }
        System.out.println(count);
    }
}
