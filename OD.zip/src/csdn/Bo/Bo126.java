package csdn.Bo;


import java.util.Scanner;

// 最少交换次数
public class Bo126 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String[] numsStr = in.nextLine().split(" ");
        int[] nums = new int[numsStr.length];
        for (int i = 0; i < numsStr.length; i++) {
            nums[i] = Integer.parseInt(numsStr[i]);
        }
        int k = in.nextInt();

        //大于k为0，小于k为1
        int m = 0;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] < k) {
                m++;
                nums[i] = 1;
            } else {
                nums[i] = 0;
            }
        }

        int left = 0;
        int right = 0;
        int total_count = Integer.MAX_VALUE;
        int result = 0;
        while (right < nums.length) {
            if (nums[right] == 0) {
                result += 1;
            }
            if (right - left + 1 == m) {
                total_count = Math.min(total_count, result);
                if (nums[left] == 0) result--;
                left += 1;
            }
            right += 1;
        }
        if (total_count == Integer.MAX_VALUE) {
            System.out.println(0);
        } else {
            System.out.println(total_count);
        }
    }

}
