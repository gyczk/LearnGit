package csdn.B;


import java.util.Scanner;

// 	查字典
public class B078 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String word = in.next();
        int length = in.nextInt();
        boolean flag = true;
        //遍历所有的输入单词
        for (int i = 0; i < length; i++) {
            String source = in.next();
            if (source.length() >= word.length() && source.startsWith(word)) {
                System.out.println(source);
                flag = false;
            }
        }
        if (flag) {
            System.out.println(-1);
        }
    }
}
