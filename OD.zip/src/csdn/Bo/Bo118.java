package csdn.Bo;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

// 找到比自己强的人 / 师徒关系
public class Bo118 {
    public static int[][] directions = {{-1, 0}, {1, 0}, {0, 1}, {0, -1}};

    public static int[] getStrongPeople(Integer[][] people) {
        if (people == null || people.length == 0) {
            return null;
        }
        Map<Integer, Integer> hashMap = new HashMap<>();
        for (int i = 0; i < people.length; i++) {
            int teacher = people[i][0];
            int student = people[i][1];
            if (teacher > student) {
                hashMap.put(teacher, hashMap.getOrDefault(student, 0) + 1);
            }
            if (!hashMap.containsKey(student)) {
                hashMap.put(student, 0);
            }
        }
        int[] ans = new int[hashMap.keySet().size()];
        int index = 0;
        for (int key : hashMap.keySet()) {
            ans[index] = hashMap.get(key);
            index++;
        }
        return ans;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        Integer[][] relations =
                Arrays.stream(str.substring(1, str.length() - 1).split("(?<=\\]),(?=\\[)"))
                        .map(s -> Arrays.stream(s.substring(1, s.length() - 1).split(","))
                                .map(Integer::parseInt)
                                .toArray(Integer[]::new))
                        .toArray(Integer[][]::new);
        int[] ans = getStrongPeople(relations);
        System.out.print("[");
        for (int i = 0; i < ans.length; i++) {
            System.out.print(ans[i]);
            if (i != ans.length - 1) {
                System.out.print(",");
            }
        }
        System.out.print("]");
    }
}
