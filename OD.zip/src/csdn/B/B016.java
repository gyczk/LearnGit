package csdn.B;

import java.util.*;

//	字符串摘要
public class B016 {
    public static HashMap<Character, Integer> char_count_map;
    public static int count = 1;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine().toLowerCase();
        char_count_map = new HashMap<>();
        for (int i = 0; i < input_str.length(); i++) {
            if (Character.isLetter(input_str.charAt(i))) {
                if (char_count_map.containsKey(input_str.charAt(i))) {
                    char_count_map.put(input_str.charAt(i), char_count_map.get(input_str.charAt(i)) + 1);
                } else {
                    char_count_map.put(input_str.charAt(i), 1);
                }
            } else {
                continue;
            }
        }
        input_str = input_str + " ";
        char_count_map.put(' ', 0);
        ArrayList<Integer[]> result = new ArrayList<>();
        char tpm = input_str.charAt(0);
        char_count_map.put(tpm, char_count_map.get(tpm) - 1);

        int i = 1;
        while (true) {
            if (i >= input_str.length()) {
                break;
            } else {
                char_count_map.put(input_str.charAt(i), char_count_map.get(input_str.charAt(i)) - 1);
                if (input_str.charAt(i) == tpm) {
                    count += 1;
                } else {
                    int new_tmp = tpm;
                    result.add(new Integer[]{new_tmp, count > 1 ? count : char_count_map.get(tpm)});
                    tpm = input_str.charAt(i);
                    count = 1;
                }
            }
            i += 1;
        }

        Collections.sort(result, new Comparator<Integer[]>() {
            @Override
            //在这里主要是重写了 Comparator类的compare方法，
            //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
            public int compare(Integer[] o1, Integer[] o2) {
                if (o1[1] == o2[1]) {
                    return o1[0] - o2[0];
                }
                return o2[1] - o1[1];
            }
        });

        String output_str = "";
        for (int j = 0; j < result.size(); j++) {
            //System.out.println(result.get(j)[0]+ 'a');
            int c = result.get(j)[0];
            output_str += (char) c + "" + result.get(j)[1];
        }
        System.out.println(output_str);
    }
}