package com.geely.design.principle.interfacesegregation;

/**
 * Created by geely
 */
public interface IAnimalAction {
    void eat();
    void fly();
    void swim();

}
