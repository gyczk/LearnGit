package csdn.Bo;


import java.util.*;

// 查找接口成功率最优时间段
public class Bo100 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int k = Integer.parseInt(in.nextLine());
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        int count = 0;
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
            count += 1;
        }
        HashMap<Integer, Integer> prefix_vals = new HashMap<>();
        prefix_vals.put(0, nums[0]);
        for (int i = 1; i < count; i++) {
            prefix_vals.put(i, prefix_vals.get(i - 1) + nums[i]);
        }

        ArrayList<Integer[]> result = new ArrayList<>();
        int length = 0;
        int i = 0;
        while (true) {
            if (i >= count) {
                break;
            } else {
                int j = 0;
                while (true) {
                    if (j >= count) {
                        break;
                    } else {
                        int sum_val = 0;
                        if (i == 0) {
                            sum_val = prefix_vals.get(j);
                        } else {
                            sum_val = prefix_vals.get(j) - prefix_vals.get(i - 1);
                        }
                        if (sum_val <= (j - i + 1) * k) {
                            if ((j - i + 1) > length) {
                                result = new ArrayList<>();
                                result.add(new Integer[]{i, j});
                                length = (j - i + 1);
                            } else if ((j - i + 1) == length) {
                                result.add(new Integer[]{i, j});
                            }
                        }
                    }
                    j += 1;
                }
            }
            i += 1;
        }

        Collections.sort(result, new Comparator<Integer[]>() {
            @Override
            //在这里主要是重写了 Comparator类的compare方法，
            //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
            public int compare(Integer[] o1, Integer[] o2) {
                return o1[0] - o2[0];//当大于0就交换，否则不交换。
            }
        });


        String output_str = "";
        for (Integer[] x : result) {
            output_str += x[0] + "-" + x[1] + " ";
        }
        System.out.println(output_str.substring(0, output_str.length() - 1));
    }
}
