package csdn.B;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

// 支持优先级的队列
public class B038 {


    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        String[] operations = in.nextLine().replaceAll("\\(", "")
                .replaceAll("\\)", "")
                .split(",");

        PriorityQueue<Task> queue = new PriorityQueue<>();
        for (int i = 0; i < operations.length; i += 2) {
            int data = Integer.valueOf(operations[i]);
            int priority = Integer.valueOf(operations[i + 1]);
            Task task = new Task(data, priority);
            queue.add(task);
        }

        List<Integer> result = new ArrayList<>();
        Task tail = queue.poll();
        while (tail != null) {
            Task top = queue.peek();
            if (!tail.equals(top)) {
                result.add(tail.data);
            }
            tail = queue.poll();
        }

        System.out.println(result);
    }

    static class Task implements Comparable<Task> {

        int data;
        int priority;

        public Task(int data, int priority) {

            this.data = data;
            this.priority = priority;

        }

        @Override
        public int compareTo(Task o) {
            return o.priority - this.priority;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Task task = (Task) o;
            return data == task.data &&
                    priority == task.priority;
        }
    }
}
