package csdn.B;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

//报文回路
public class B019 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());

        int[][] matrix = new int[n][2];
        for (int i = 0; i < n; i++) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(" ");
            int[] nums = new int[tmp2.length];
            for (int j = 0; j < tmp2.length; j++) {
                nums[j] = Integer.parseInt(tmp2[j]);
            }
            matrix[i][0] = nums[0];
            matrix[i][1] = nums[1];
        }

        HashMap<Integer, HashSet<Integer>> relations = new HashMap<>();
        for (int i = 0; i < n; i++) {
            if (!relations.containsKey(matrix[i][0])) {
                relations.put(matrix[i][0], new HashSet<>());
            }
            if (!relations.containsKey(matrix[i][1])) {
                relations.put(matrix[i][1], new HashSet<>());
            }
            relations.get(matrix[i][0]).add(matrix[i][1]);
        }

        int flag = 0;
        for (Integer num1 : relations.keySet()) {
            for (Integer num2 : relations.get(num1)) {
                if (!relations.get(num2).contains(num1)) {
                    flag = 1;
                    break;
                }
            }
        }

        if (flag == 0) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }

    }
}