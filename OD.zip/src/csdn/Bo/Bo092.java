package csdn.Bo;


import java.util.Scanner;


// 考勤信息
public class Bo092 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());

        String[][] logs = new String[n][];
        for (int i = 0; i < n; i++) {
            logs[i] = in.nextLine().split(" ");
        }

        for (int j = 0; j < n; j++) {
            int count = 0;
            int total = 0;
            boolean flag = true;
            boolean skip_flag = true;

            for (int i = 0; i < logs[j].length; i++) {
                switch (logs[j][i]) {
                    case "absent":
                        if (++count > 1) flag = false;
                        total++;
                        break;
                    case "late":
                        if (i > 0 && logs[j][i - 1].equals("late")) flag = false;
                        total++;
                        break;
                    case "leaveearly":
                        if (i > 0 && logs[j][i - 1].equals("leaveearly")) flag = false;
                        total++;
                        break;
                }

                if (!flag) {
                    System.out.println("false");
                    skip_flag = false;
                    break;
                }
                if (i >= 7 && !logs[j][i - 7].equals("present")) {
                    total--;
                }
                if (total > 3) {
                    System.out.println("false");
                    skip_flag = false;
                    break;
                }

            }
            if (skip_flag) {
                System.out.println("true");
            }
        }
    }

}



