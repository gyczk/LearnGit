package csdn.Bo;


import java.util.*;

// 字符串排序
public class Bo108 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        List<String> list = new ArrayList<String>();

        String input = in.nextLine();

        String[] str = input.split(" ");
        Collections.addAll(list, str);

        //自定义排序
        Collections.sort(list, new Comparator<String>() {
            public int compare(String o1, String o2) {

                char[] char1 = o1.toCharArray();
                char[] char2 = o2.toCharArray();

                int length = char1.length < char2.length ? char1.length : char2.length;

                for (int i = 0; i < length; i++) {

                    char a = char1[i] > 'a' ? char1[i] : (char) (char1[i] + 32);
                    char b = char2[i] > 'a' ? char2[i] : (char) (char2[i] + 32);

                    if (a < b) {
                        return -1;
                    } else if (a > b) {
                        return 1;
                    } else {
                        continue;
                    }
                }

                return 0;
            }
        });


        List<String> revdup_list = new ArrayList<String>();
        revdup_list.add(list.get(0));
        int p = 1;
        for (int i = 0; i < list.size(); i++) {

            if (p < list.size() && revdup_list.get(i).equalsIgnoreCase(list.get(p))) {
                p = p + 1;
                i--;
            } else if (p < list.size() && !revdup_list.get(i).equalsIgnoreCase(list.get(p))) {
                revdup_list.add(list.get(p));
                if (p == list.size() - 1)
                    break;
            }

        }

        for (int k = 0; k < revdup_list.size(); k++) {
            if (k == list.size() - 1) {
                System.out.print(revdup_list.get(k));
            } else {
                System.out.print(revdup_list.get(k) + " ");
            }
        }
    }

}
