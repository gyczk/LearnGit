package csdn.B;

// 恢复数字序列

import java.util.Arrays;
import java.util.Scanner;

public class B029 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.next();
        int length = in.nextInt();
        System.out.println(getminint(input_str, length));
    }

    public static int getminint(String input_str, int n) {
        String orderstr = getorderedstring(input_str);
        int start = 1;
        while (true) {
            int[] nums = getcontints(start, n);
            String strings = getstring(nums);
            if (strings.equals(orderstr)) {
                return start;
            } else {
                start = start + 1;
            }
        }
    }

    public static int[] getcontints(int start, int n) {
        int[] conint = new int[n];
        for (int i = 0; i < n; i++) {
            conint[i] = start + i;
        }
        return conint;
    }

    public static String getstring(int[] nums) {

        String orderstr = "";
        for (int num : nums) {
            orderstr += Integer.toString(num);
        }
        String[] split_strs = orderstr.split("");
        int[] new_nums = new int[split_strs.length];
        for (int i = 0; i < split_strs.length; i++) {
            new_nums[i] = Integer.parseInt(split_strs[i]);
        }

        Arrays.sort(new_nums);
        String res = "";
        for (int num : new_nums) {
            res += Integer.toString(num);
        }
        return res;
    }

    public static String getorderedstring(String strs) {
        String[] split_strs = strs.split("");
        int[] nums = new int[split_strs.length];
        for (int i = 0; i < split_strs.length; i++) {
            nums[i] = Integer.parseInt(split_strs[i]);
        }
        Arrays.sort(nums);
        String orderstr = "";
        for (int num : nums) {
            orderstr += Integer.toString(num);
        }
        return orderstr;
    }
}
