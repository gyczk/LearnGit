package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

// 	战场索敌
public class B042 {


    public static int[][] visited;
    public static int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    public static int count = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int k = in.nextInt();

        visited = new int[n][m];

        char[][] matrix = new char[n][m];
        for (int i = 0; i < n; i++) {
            String input_str = in.next();
            for (int j = 0; j < m; j++) {
                matrix[i][j] = input_str.charAt(j);
            }
        }

        int result = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (visited[i][j] == 1 || matrix[i][j] == '#') {
                    continue;
                }
                count = 0;
                dfs(i, j, matrix, n, m);
                if (count < k) {
                    result += 1;
                }
            }
        }
        System.out.println(result);
    }

    public static boolean canPartitionKSubsets(int[] nums, int k, int all) {
        if (all % k != 0) {
            return false;
        }
        int per = all / k;
        Arrays.sort(nums);
        int n = nums.length;
        if (nums[n - 1] > per) {
            return false;
        }
        boolean[] dp = new boolean[1 << n];
        int[] curSum = new int[1 << n];
        dp[0] = true;
        for (int i = 0; i < 1 << n; i++) {
            if (!dp[i]) {
                continue;
            }
            for (int j = 0; j < n; j++) {
                if (curSum[i] + nums[j] > per) {
                    break;
                }
                if (((i >> j) & 1) == 0) {
                    int next = i | (1 << j);
                    if (!dp[next]) {
                        curSum[next] = (curSum[i] + nums[j]) % per;
                        dp[next] = true;
                    }
                }
            }
        }
        return dp[(1 << n) - 1];
    }

    public static void dfs(int i, int j, char[][] matrix, int n, int m) {
        visited[i][j] = 1;

        // 敌军数量+1
        if (matrix[i][j] == 'E') {
            count += 1;
        }
        //已经不适用栈结构来实现了
        for (int k = 0; k < 4; k++) {
            int new_x = i + directions[k][0];
            int new_y = j + directions[k][1];

            if (new_x >= 0 && new_x < n && new_y >= 0 && new_y < m && visited[new_x][new_y] == 0 && matrix[new_x][new_y] != '#') {
                dfs(new_x, new_y, matrix, n, m);
            }
        }
    }

}