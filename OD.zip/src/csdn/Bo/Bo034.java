package csdn.Bo;


import java.util.HashMap;
import java.util.Scanner;

// 翻牌求最大分
public class Bo034 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(",");
        int[] nums = new int[tmp2.length];
        int count = 0;
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
            count += 1;
        }

        HashMap<Integer, Integer> vals = new HashMap<>();

        int target0 = Math.max(0, nums[0]);
        vals.put(0, target0);
        int target1 = 0;
        for (int i = 1; i < 4; i++) {
            if (target0 + nums[i] > 0) {
                target1 = target0 + nums[i];
            }
            vals.put(i, target1);
            target0 = target1;
        }

        for (int i = 4; i < nums.length; i++) {
            if (vals.get(i - 3) > vals.get(i - 1) + nums[i]) {
                vals.put(i, vals.get(i - 3));
            } else {
                vals.put(i, vals.get(i - 1) + nums[i]);
            }
        }

        System.out.println(vals.get(count - 1));
    }
}



