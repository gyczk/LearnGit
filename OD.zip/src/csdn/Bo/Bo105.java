package csdn.Bo;


import java.util.Scanner;


// 分糖果
public class Bo105 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);

        long s = in.nextLong();

        System.out.println(dfs(s));

    }

    public static int dfs(long n) {
        if (n == 0 || n == 1) {
            return 0;
        }
        if (n % 2 == 0) {
            return dfs(n / 2) + 1;
        } else {
            return Math.min(dfs(n + 1), dfs(n - 1)) + 1;
        }
    }
}