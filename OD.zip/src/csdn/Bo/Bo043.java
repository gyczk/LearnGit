package csdn.Bo;


import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 分积木
public class Bo043 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        Integer[] weights = new Integer[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            weights[i] = Integer.parseInt(tmp2[i]);
        }

        Arrays.sort(weights, new Comparator<Integer>() {
            //重写compare方法，最好加注解，不加也没事
            public int compare(Integer a, Integer b) {
                return a - b;
            }
        });
        int count1 = weights[0];
        int count2 = weights[0];
        int i = 1;
        while (true) {
            if (i >= tmp2.length) {
                break;
            } else {
                count1 += weights[i];
                count2 ^= weights[i];
            }
            i += 1;
        }
        System.out.println(count2 == 0 ? count1 - weights[0] + "" : "NO");
    }

}
