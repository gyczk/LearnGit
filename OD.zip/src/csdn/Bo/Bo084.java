package csdn.Bo;


import java.util.LinkedList;
import java.util.Scanner;

// 二叉树中序遍历
public class Bo084 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        LinkedList<Integer> left_pos = new LinkedList<>();
        LinkedList<String> container = new LinkedList<>();

        int i = 0;
        while (true) {
            if (i >= str.length()) {
                System.out.println(container.get(0));
                break;
            } else {
                if (str.charAt(i) == '}') {
                    String temp = "";
                    int new_idx = left_pos.get(left_pos.size() - 1) + 1;
                    left_pos.removeLast();
                    while (true) {
                        if (new_idx >= container.size()) {
                            break;
                        } else {
                            temp += container.remove(new_idx);
                        }
                    }
                    String[] split = temp.split(",");
                    container.removeLast();
                    String new_root = container.get(container.size() - 1);
                    container.removeLast();
                    container.addLast(split[0] + new_root + (split.length > 1 ? split[1] : ""));
                    i += 1;
                    continue;
                } else if (str.charAt(i) == '{') {
                    left_pos.addLast(container.size());
                    container.addLast(str.charAt(i) + "");
                } else {
                    container.addLast(str.charAt(i) + "");
                }
            }
            i += 1;
        }

    }

}
