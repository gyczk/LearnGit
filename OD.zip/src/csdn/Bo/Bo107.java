package csdn.Bo;


import java.util.HashMap;
import java.util.Scanner;

// 数组连续和
public class Bo107 {
    public static int count = 0;
    public static int left = 0;
    public static int right = 0;

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] params = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            params[i] = Integer.parseInt(tmp2[i]);
        }
        int n = params[0];
        int target = params[1];

        String input_str1 = in.nextLine();
        String[] tmp3 = input_str1.split(" ");
        int[] nums = new int[tmp3.length];
        int length = 0;
        for (int i = 0; i < tmp3.length; i++) {
            nums[i] = Integer.parseInt(tmp3[i]);
            length += 1;
        }

        HashMap<Integer, Integer> prefix = new HashMap<Integer, Integer>();
        prefix.put(0, 0);
        for (int i = 1; i <= n; i++) {
            if (!prefix.containsKey(i)) {
                prefix.put(i, prefix.get(i - 1) + nums[i - 1]);
            }
        }

        while (true) {
            if (right > length) {
                break;
            } else {
                if (prefix.get(right) - prefix.get(left) < target) {
                    right += 1;

                } else {
                    count += length - right + 1;
                    left += 1;
                    right = left + 1;
                }
            }

        }

        System.out.println(count);

    }
}


