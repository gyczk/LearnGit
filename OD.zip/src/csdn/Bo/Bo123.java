package csdn.Bo;


import java.util.*;


// 正方形数量
public class Bo123 {

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        List<int[]> points = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int[] point = new int[2];
            point[0] = in.nextInt();
            point[1] = in.nextInt();
            points.add(point);
        }

        int count = 0;
        int len = points.size();
        if (len > 3) {
            //暴力循环可破
            for (int i = 0; i < len - 3; i++) {
                for (int j = i + 1; j < len - 2; j++) {
                    for (int k = j + 1; k < len - 1; k++) {
                        for (int l = k + 1; l < len; l++) {
                            if (isSquare(points.get(i), points.get(j), points.get(k), points.get(l))) {
                                count++;
                            }
                        }
                    }
                }
            }
        }

        System.out.print(count);


    }

    public static boolean isSquare(int[] a, int[] b, int[] c, int[] d) {

        List<int[]> list = Arrays.asList(a, b, c, d);
        Map<Integer, Integer> map = new HashMap<>();
        int temp = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = i + 1; j < 4; j++) {
                int x = list.get(i)[0] - list.get(j)[0];
                int y = list.get(i)[1] - list.get(j)[1];
                int len = x * x + y * y;
                temp = len;
                map.put(len, map.getOrDefault(len, 0) + 1);
            }
        }

        return map.size() == 2 && (map.get(temp) == 2 || map.get(temp) == 4);
    }

}
