package csdn.Bo;


import java.util.Arrays;
import java.util.Scanner;


// 采样过滤
public class Bo135 {

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int t = in.nextInt();
        int p = in.nextInt();
        in.nextLine();
        Integer[] sample_data = Arrays.stream(in.nextLine().split(" "))
                .map(Integer::parseInt)
                .toArray(Integer[]::new);

        // 判断数据异常
        int[] items = new int[sample_data.length];
        for (int i = 0; i < sample_data.length; i++) {
            if (sample_data[i] <= 0) {
                items[i] = 0;
            } else if (i > 0 && ((sample_data[i] - sample_data[i - 1] >= 10) || sample_data[i] < sample_data[i - 1])) {
                items[i] = 0;
            } else {
                items[i] = 1;
            }
        }

        //
        int i = 0;
        while (i < sample_data.length) {
            //可以用之前数据替代的情况
            if (items[i] == 0 && i > 0 && items[i - 1] == 1) {
                sample_data[i] = sample_data[i - 1];
                items[i] = 1;
            }
            int error_num = 0;
            int corrent = 0;
            int j = i;

            //求得采样错误总数量
            while (m > 0 && j < sample_data.length) {
                if (items[j] == 0) {
                    error_num += 1;
                    if (error_num >= t) {
                        if (j > 0) {
                            corrent = j - 1;
                        } else {
                            corrent = 0;
                        }
                    }
                }
                j += 1;
            }

            // 大于故障次数门限 T
            if (error_num >= t) {
                boolean pos = false;
                int k = 0;
                while (k < i && items[k] != 1) {
                    k += 1;
                }
                pos = true;

                if (i + t == sample_data.length - 1) {
                    k = i;
                    while (k < corrent + 1) {
                        sample_data[k] = sample_data[i - 1];
                        items[k] = 1;
                        k += 1;
                    }
                    break;
                } else if (i + m <= sample_data.length) {
                    for (int l = i; l < sample_data.length; l++) {
                        if (l < corrent + 1) {
                            if (i > 0) {
                                sample_data[l] = sample_data[i - 1];
                            } else {
                                sample_data[l] = sample_data[0];
                            }
                            items[l] = 1;
                        } else {
                            items[l] = 0;
                        }
                    }
                } else {
                    for (int q = i; q < i + m; q++) {
                        if (q < corrent + 1) {
                            sample_data[q] = sample_data[i - 1];
                            items[q] = 1;
                        } else {
                            items[q] = 0;
                        }
                    }
                    if (i + m + p >= sample_data.length + 1) {
                        for (int k_1 = i; k_1 < sample_data.length; k_1++) {
                            items[k_1] = 0;
                        }
                        items[k] = 0;
                        i = k + p;
                    }
                }
            } else {
                i += 1;
            }
        }

        int res = 0;
        int location = 0;
        for (int item : items) {
            if (item != 1) {
                if (location > res) {
                    res = location;
                }
                location = 0;
            } else {
                location += 1;
            }
        }
        System.out.println(Math.max(res, location));

    }

}
