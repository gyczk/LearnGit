package csdn.B;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

// 	选举拉票
public class B091 {

    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

        int max_b = 1, max_a = 0, result = 0;
        ArrayList<ArrayList<Integer>> tree1 = new ArrayList<>();
        ArrayList<ArrayList<Integer>> f = new ArrayList<>();
        int[] num = new int[40000];
        int[] t = new int[40000];

        for (int i = 0; i < 10005; i++) {
            tree1.add(new ArrayList<>());
            f.add(new ArrayList<>());
        }

        //分别取出a,b两个数组的最大值
        for (int i = 0; i < n; i++) {
            int x = in.nextInt();
            int y = in.nextInt();

            max_a = Math.max(max_a, x);
            if (y == 0) {
                continue;
            }
            max_b = Math.max(y, max_b);
            result += y;
            tree1.get(x).add(y);
        }


        for (int i = 1; i <= max_a; ++i) {
            ArrayList<Integer> temp = tree1.get(i);
            if (temp.size() > 0) {
                Collections.sort(temp);
                for (int j = 0; j < temp.size(); ++j)
                    f.get(j + 1).add(temp.get(j));
            }
        }
        int k = n;
        int tmp = result;
        for (int i = 1; i <= n; ++i) {
            k -= f.get(i).size();
            for (int j = 0; j < f.get(i).size(); ++j) {
                change(1, 1, max_b, f.get(i).get(j), num, t);
                tmp -= f.get(i).get(j);
            }
            int add = 0;
            if (k <= i)
                add = query(1, 1, max_b, Math.min(i + 1 - k, n), num, t);
            result = Math.min(result, tmp + add);
        }
        System.out.println(result);


    }


    public static void change(int x, int l, int r, int q, int[] num, int[] t) {
        if (l == r) {
            ++num[x];
            t[x] += l;
            return;
        }
        int mid = (l + r) >> 1;
        if (q <= mid) change(x << 1, l, mid, q, num, t);
        else change(x << 1 | 1, mid + 1, r, q, num, t);
        t[x] = t[x << 1] + t[x << 1 | 1];
        num[x] = num[x << 1] + num[x << 1 | 1];
    }

    public static int query(int x, int l, int r, int q, int[] num, int[] t) {
        if (l == r) return l * q;
        int mid = (l + r) >> 1;
        if (q == num[x << 1]) return t[x << 1];
        if (q > num[x << 1]) return t[x << 1] + query(x << 1 | 1, mid + 1, r, q - num[x << 1], num, t);
        else return query(x << 1, l, mid, q, num, t);
    }

}
