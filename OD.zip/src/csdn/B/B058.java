package csdn.B;


import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Scanner;

// 矩阵中非1的元素个数
public class B058 {
    public static int result = 1;

    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();

        int[][] matrix = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = in.nextInt();
            }
        }

        matrix[0][0] = 1;

        //使用 QUEUE 队列来实现
        Queue<int[]> queue = new ArrayDeque<>();
        queue.offer(new int[]{0, 0});
        int result = 1;

        int[] node = null;
        while (!queue.isEmpty()) {
            node = queue.poll();
            int x = node[0], y = node[1];
            if (x + 1 < m && matrix[x + 1][y] == 0) {
                matrix[x + 1][y] = matrix[x][y] + 1;
                result += 1;
                queue.offer(new int[]{x + 1, y});
            }
            if (y + 1 < n && matrix[x][y + 1] == 0) {
                matrix[x][y + 1] = matrix[x][y] + 1;
                result += 1;
                queue.offer(new int[]{x, y + 1});
            }
            if (x - 1 >= 0 && matrix[x - 1][y] == 0) {
                matrix[x][y + 1] = matrix[x][y] + 1;
                result += 1;
                queue.offer(new int[]{x - 1, y});
            }
            if (y - 1 >= 0 && matrix[x][y - 1] == 0) {
                matrix[x][y - 1] = matrix[x][y] + 1;
                queue.offer(new int[]{x, y - 1});
                result += 1;
            }

        }
        System.out.println(m * n - result);
    }

}
