package csdn.B;

import java.util.Scanner;

// 求最小步数
public class B047 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        int x = 0, y = 0;
        if (n % 2 != 0) {
            n -= 3;
            y = 1;
        }
        x = n % 6 / 2;
        y += n / 6 * 2;
        System.out.println(Math.abs(x) + Math.abs(y));
    }
}

