package csdn.Bo;


import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

// 快速人名查找
public class Bo035 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        List<String> names = Arrays.asList(in.nextLine().split(","));
        String pattern = in.nextLine();

        String output_str = "";
        int i = 0;
        while (true) {
            if (i >= names.size()) {
                break;
            } else {
                List<String> single_names = Arrays.asList(names.get(i).split(" "));
                if ((single_names.size() > pattern.length())) {
                    i += 1;
                    continue;
                } else {
                    if (dfs(single_names, 0, pattern, 0)) {
                        output_str += names.get(i) + ",";
                    }
                }
            }
            i += 1;
        }

        System.out.println(output_str.substring(0, output_str.length() - 1));
    }

    public static boolean dfs(List<String> single_names, int position, String pattern, int pattern_position) {
        if (pattern_position >= pattern.length()) {
            return position >= single_names.size();
        }
        if (position >= single_names.size()) {
            return pattern_position >= pattern.length();
        }
        if (single_names.get(position).charAt(0) != pattern.charAt(pattern_position)) {
            return false;
        }
        int index = 1;
        while (index < single_names.get(position).length() && pattern_position + index < pattern.length()
                && single_names.get(position).charAt(index) == pattern.charAt(pattern_position + index)) {
            if (dfs(single_names, position + 1, pattern, pattern_position + index + 1)) {
                return true;
            }
            index += 1;
        }
        return dfs(single_names, position + 1, pattern, pattern_position + 1);
    }

}
