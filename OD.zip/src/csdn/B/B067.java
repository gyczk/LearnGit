package csdn.B;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

// 报数游戏
public class B067 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = Integer.parseInt(in.nextLine());
        if (m <= 1 || m >= 100) {
            System.out.println("ERROR!");
            return;
        }
        ArrayList<Integer> nums = new ArrayList<Integer>();
        for (int i = 1; i <= 100; i++) {
            nums.add(i);
        }

        int flag = 1;

        while (nums.size() >= m) {
            if (flag == m) {
                flag = 1;
            } else {
                nums.add(nums.get(0));
                flag += 1;
            }
            nums.remove(0);
        }

        Collections.sort(nums);
        System.out.print(nums);
    }

    public static int[][] getTag(String ltv, int[] tags) {
        if (ltv == null || ltv.length() == 0) {
            return null;
        }
        int n = tags.length;
        int[][] ans = new int[n][2];
        int preIndex = 0;
        for (int i = 0; i < ltv.length(); i += preIndex) {
            int tag = Integer.parseInt((ltv.substring(i, i + 2)), 16);
            int len = Integer.parseInt(ltv.substring(i + 2, i + 4));
            for (int j = 0; j < tags.length; j++) {
                if (tag == tags[j]) {
                    ans[j][0] = len;
                    ans[j][1] = preIndex / 2 + 2;
                }
            }
            preIndex += 2 * len + 4;
        }
        return ans;
    }
}