package csdn.Bo;


import java.util.Scanner;
import java.util.TreeSet;

// 分班问题
public class Bo149 {
    public static TreeSet<Integer> intSet = new TreeSet();

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        boolean isInvalid = false;
        String[] input = in.nextLine().split(" ");
        String[] flags = new String[input.length];
        for (int i = 0; i < input.length; i++) {
            String[] temp = input[i].split("/");
            int idx = Integer.parseInt(temp[0]);
            if (idx <= 0 || idx > 999) {
                isInvalid = true;
                break;
            }
            flags[i] = temp[1];
        }

        if (isInvalid) {
            System.out.println("ERROR");
            return;
        }

        boolean[] res = new boolean[flags.length];
        res[0] = true;
        for (int i = 1; i < flags.length; i++) {
            res[i] = flags[i].equals("N") != res[i - 1];
        }

        StringBuilder one = new StringBuilder();
        StringBuilder two = new StringBuilder();
        for (int i = 0; i < res.length; i++) {
            if (res[i]) {
                one.append(i + 1).append(" ");
            } else {
                two.append(i + 1).append(" ");
            }
        }

        System.out.println(one.toString().trim());
        System.out.println(two.toString().trim());
    }
}
