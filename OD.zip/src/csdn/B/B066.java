package csdn.B;


import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 冠亚军排名
public class B066 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        String[][] countries = new String[n][];
        for (int i = 0; i < n; i++) {
            countries[i] = in.nextLine().split(" ");
        }

        //自定义排序
        Arrays.sort(countries, new Comparator<String[]>() {
            @Override
            public int compare(String[] o1, String[] o2) {
                if (o1[1].equals(o2[1])) {
                    if (o1[2].equals(o2[2])) {
                        return -Integer.parseInt(o1[3]) + Integer.parseInt(o2[3]);
                    } else {
                        return -Integer.parseInt(o1[2]) + Integer.parseInt(o2[2]);
                    }
                }
                return -Integer.parseInt(o1[1]) + Integer.parseInt(o2[1]);
            }
        });

        for (String[] country : countries) {
            System.out.println(country[0]);
        }
    }
}
