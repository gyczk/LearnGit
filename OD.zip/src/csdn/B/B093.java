package csdn.B;


import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

// 	购物
public class B093 {
    public static String output_str = "";

    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] params = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            params[i] = Integer.parseInt(tmp2[i]);
        }
        int n = params[0];
        int m = params[1];

        String input_str1 = in.nextLine();
        String[] tmp21 = input_str1.split(" ");
        Integer[] nums = new Integer[tmp21.length];
        for (int i = 0; i < tmp21.length; i++) {
            nums[i] = Integer.parseInt(tmp21[i]);
        }
        Arrays.sort(nums, new Comparator<Integer>() {
            @Override
            //在这里主要是重写了 Comparator类的compare方法，
            //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
            public int compare(Integer o1, Integer o2) {
                return o1 - o2;
            }
        });

        PriorityQueue<Integer[]> queue =
                new PriorityQueue<>((a, b) -> a[0] + nums[a[1]] - (b[0] + nums[b[1]]));
        Integer[] c = new Integer[]{0, 0};

        int i = 1;
        while (true) {
            if (i > m) {
                System.out.println(output_str);
                break;
            } else {
                output_str += (c[0] + nums[c[1]]) + "\n";
                if (c[1] + 1 >= n) {
                    c = queue.poll();
                } else {
                    queue.offer(new Integer[]{c[0] + nums[c[1]], c[1] + 1});
                    c[1] += 1;
                    queue.offer(c);
                    c = queue.poll();
                }
            }
            i += 1;
        }

    }
}
