package csdn.B;

import java.util.Scanner;

// 分割数组的最大差值
public class B045 {


    public static long max_diff = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        long prefix = 0;
        long suffix = 0;
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
            suffix += nums[i];
        }

        for (int num : nums) {
            prefix += num;
            suffix -= num;
            max_diff = Math.abs(prefix - suffix) > max_diff ? Math.abs(prefix - suffix) : max_diff;
        }
        System.out.println(max_diff);
    }
}
