package csdn.Bo;


import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 快递运输
public class Bo022 {
    public static int result = 0;

    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(",");
        Integer[] weights = new Integer[tmp2.length];
        int count = 0;
        for (int i = 0; i < tmp2.length; i++) {
            weights[i] = Integer.parseInt(tmp2[i]);
            count += 1;
        }
        int threshold = Integer.parseInt(in.nextLine());
        Arrays.sort(weights, new Comparator<Integer>() {
            //重写compare方法，最好加注解，不加也没事
            public int compare(Integer a, Integer b) {
                return a - b;
            }
        });
        int sum = 0;
        int i = 0;
        while (true) {
            if (i >= count) {
                break;
            } else {
                sum += weights[i];
                if (sum > threshold) {
                    break;
                } else {
                    result += 1;
                }
            }
            i += 1;
        }

        System.out.println(result);

    }
}
