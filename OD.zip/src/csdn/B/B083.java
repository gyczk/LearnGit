package csdn.B;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

// 玩牌高手
public class B083 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] nums = Arrays.stream(in.nextLine().split(",")).mapToInt(Integer::parseInt).toArray();

        List<Integer> list_total = new ArrayList<>();
        int result = 0;
        int total_negative = 0;
        int total_positive = 0;
        //分以下正负统计即可
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] >= 0) {
                result += nums[i];
                list_total.add(result);
            } else if (nums[i] < 0) {
                total_negative = result + nums[i];
                if (i - 3 >= 0) {
                    total_positive = list_total.get(i - 3);
                } else {
                    total_positive = 0;
                }
                result = Math.max(total_negative, total_positive);
                list_total.add(result);
            }
        }
        System.out.println(result);
    }
}
