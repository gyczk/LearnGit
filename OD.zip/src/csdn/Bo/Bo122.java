package csdn.Bo;


import java.util.Scanner;


// IPv4地址转换为整数
public class Bo122 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String[] ips = in.nextLine().split("#");
        int len = ips.length;
        long count = 0;
        boolean flag = true;

        if (len == 4) {
            for (int i = 0; i < len; i++) {
                long n = Integer.parseInt(ips[i]);
                if (i == 0 && (n < 1 || n > 128)) {
                    flag = false;
                    break;
                } else if (n < 0 || n > 255) {
                    flag = false;
                    break;
                }
                count += n << (8 * (3 - i));
            }
        } else {
            flag = false;
        }

        if (flag) {
            System.out.print(count);
        } else {
            System.out.print("invalid IP");
        }
    }


}
