package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

// 	MELON的难题
public class B057 {
    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        int[] nums = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();

        int sum = Arrays.stream(nums).sum();

        // 分给两个人，不能评分直接返回
        if (sum % 2 != 0) {
            System.out.println(-1);
            return;
        }

        //二维DP转为1维DP
        int[] dp = new int[(sum / 2) + 1];
        for (int i = 1; i <= (sum / 2); i++) {
            dp[i] = n;
        }
        for (int i = 1; i <= sum / 2; i++) {
            System.out.println(dp[i]);
        }
        for (int i = 1; i <= n; i++) {
            for (int j = (sum / 2); j >= nums[i - 1]; j--) {
                dp[j] = Math.min(dp[j], dp[j - nums[i - 1]] + 1);
            }
        }

        if (dp[sum / 2] == n) {
            System.out.println(-1);
        } else {
            System.out.println(dp[sum / 2]);
        }
    }

}
