package csdn.Bo;


import java.util.Scanner;

// 单词搜索/找到它
public class Bo067 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        int n = nums[0];
        int m = nums[1];
        String target = in.nextLine();
        String[] matrix = new String[n];
        for (int i = 0; i < n; i++) {
            matrix[i] = in.nextLine();
        }
        boolean[][] visited = new boolean[n][m];

        int i = 0;
        boolean flag = false;
        int pos_x = 0;
        int pos_y = 0;
        while (i < n) {
            int j = 0;
            while (j < m) {
                if (bfs(i, j, 0, n, m, matrix, visited, target)) {
                    pos_x = i;
                    pos_y = j;
                    flag = true;
                    break;
                }
                j += 1;
            }
            i += 1;
        }
        if (flag) {
            String output_str = "";
            output_str += (pos_x + 1) + " " + (pos_y + 1);
            System.out.println(output_str);
        } else {
            System.out.println("NO");
        }

    }

    public static boolean bfs(int i, int j, int index, int n, int m, String[] matrix, boolean[][] visited, String target) {
        if (index == target.length()) {
            return true;
        } else {
            if (i < 0 || i >= n || j < 0 || j >= m || visited[i][j] || matrix[i].charAt(j) != target.charAt(index)) {
                return false;
            }
        }
        visited[i][j] = true;
        boolean flag = false;
        if (i - 1 >= 0) {
            flag = flag || bfs(i - 1, j, index + 1, n, m, matrix, visited, target);
        }
        if (i + 1 < n) {
            flag = flag || bfs(i + 1, j, index + 1, n, m, matrix, visited, target);
        }
        if (j - 1 >= 0) {
            flag = flag || bfs(i, j - 1, index + 1, n, m, matrix, visited, target);
        }
        if (j + 1 < m) {
            flag = flag || bfs(i, j + 1, index + 1, n, m, matrix, visited, target);
        }
        visited[i][j] = false;
        return flag;
    }
}


