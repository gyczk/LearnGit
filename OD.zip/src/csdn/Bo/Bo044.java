package csdn.Bo;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

// 解密犯罪时间
public class Bo044 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        System.out.println(cal(in.nextLine()));

    }

    public static String format(String time) {
        String[] split = time.split(":");
        String H = split[0];
        String M = split[1];
        H = H.length() == 2 ? H : "0" + H;
        M = M.length() == 2 ? M : "0" + M;
        return H + ":" + M;
    }

    public static String cal(String time) {
        char[] chars = time.toCharArray();
        ArrayList<Integer> nums = new ArrayList<>();
        for (char c : chars) {
            if (c != ':') {
                nums.add(c - '0');
            }
        }
        String[] split = time.split(":");
        Integer H = Integer.parseInt(split[0]);

        Integer M = Integer.parseInt(split[1]);
        ArrayList<Integer> list = new ArrayList<>();
        for (int i : nums) {
            for (int j : nums) {
                if (i <= 5) {
                    list.add(i * 10 + j);
                }
            }
        }
        list.sort(Comparator.comparing(o -> o));
        //仅仅改变分钟就能得到最近的值
        for (int i : list) {
            if (i <= M) {
                continue;
            }
            return format(H + ":" + i);
        }
        //小时数在23以下，可以使用最近的小时数
        if (H != 23) {
            for (int i : list) {
                if (i <= H) {
                    continue;
                }
                if (i <= 23) {
                    return format(i + ":" + list.get(0));
                }
            }
        }

        return format(list.get(0) + ":" + list.get(0));
    }

}
