package csdn.B;


import java.util.ArrayList;
import java.util.Scanner;

// 找车位
public class B090 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(",");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        ArrayList<Integer> index = new ArrayList<>();
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] == 1)
                index.add(i);
        }
        //停车场没车
        if (index.size() == 0) {
            System.out.println(nums.length - 1);
        } else {
            int res = 0;

            //如果最左边或者最右边没停车
            int leftside = 0;
            int rightside = nums.length - 1;
            if (index.get(0) != 0 || index.get(index.size() - 1) != rightside) {
                res = Math.max(index.get(0), rightside - index.get(index.size() - 1));
            }

            for (int i = 1; i < index.size(); i++) {
                res = Math.max(res, (index.get(i) - index.get(i - 1)) / 2);
            }
            System.out.println(res);
        }
    }
}


