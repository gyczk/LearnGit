package csdn.Bo;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


// 九宫格按键输入法
public class Bo046 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input = in.nextLine();
        Map<Character, String> characterStringMap = buildMap();
        boolean isNumber = true;
        StringBuffer stringBuffer = new StringBuffer();
        int inputLength = input.length();
        for (int i = 0; i < inputLength; i++) {
            char ch = input.charAt(i);
            // # 切换输入法
            if (ch == '#') {
                isNumber = !isNumber;
                continue;
            }
            if (ch == '/') {
                continue;
            }
            if (isNumber) {
                stringBuffer.append(ch);
                continue;
            }
            if (ch == '0') {
                stringBuffer.append(" ");
                continue;
            }
            int repeatCharNum = getRepeatCharNum(input, inputLength, ch, i);

            i = i + repeatCharNum;
            String ziMu = characterStringMap.get(ch);
            if (repeatCharNum > 0) {
                int i1 = repeatCharNum % ziMu.length();
                stringBuffer.append(ziMu.charAt(i1));
            } else {
                stringBuffer.append(ziMu.charAt(repeatCharNum));
            }
        }
        System.out.println(stringBuffer);
    }


    private static int getRepeatCharNum(String input, int inputLength, char ch, int i) {
        int repeatCharNum = 0;
        for (int j = i + 1; j < inputLength; j++) {
            char next = input.charAt(j);
            if (next == '/') {
                break;
            }
            if (ch != next) {
                break;
            }
            repeatCharNum++;
        }
        return repeatCharNum;
    }

    private static Map<Character, String> buildMap() {
        Map<Character, String> map = new HashMap<>();
        map.put('1', ",.");
        map.put('2', "abc");
        map.put('3', "def");
        map.put('4', "ghi");
        map.put('5', "jkl");
        map.put('6', "mno");
        map.put('7', "pqrs");
        map.put('8', "tuv");
        map.put('9', "wxyz");
        return map;
    }
}
