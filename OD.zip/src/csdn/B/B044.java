package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

// 跳房子I
public class B044 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input = in.nextLine();
        int[] nums = Arrays.stream(input.substring(1, input.length() - 1).split(",")).mapToInt(Integer::parseInt).toArray();
        int count = Integer.parseInt(in.nextLine());

        int result1 = -1;
        int result2 = -1;
        int small_index = Integer.MAX_VALUE;

        //暴力双循环方法
        for (int i = 0; i < nums.length; i++) {// 枚举 i
            for (int j = i + 1; j < nums.length; j++) // 枚举 i 右边的 j
                if (nums[i] + nums[j] == count) {  // 满足要求
                    if (i + j < small_index) {
                        result1 = i;
                        result2 = j;
                        small_index = i + j;
                    }
                }
        }

        System.out.println("[" + nums[result1] + ", " + nums[result2] + "]");

    }

}
