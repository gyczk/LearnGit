package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

// 计算最接近的数
public class B040 {


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String[] input_str = in.nextLine().replace("[", "")
                .replace("]", "")
                .split(",");
        int N = input_str.length - 1;
        int[] nums = new int[N];
        int K = Integer.valueOf(input_str[N]);
        for (int i = 0; i < N; i++) {
            nums[i] = Integer.valueOf(input_str[i]);
        }

        int[] new_nums = Arrays.copyOf(nums, N);
        // 先排序
        Arrays.sort(new_nums);
        // 再求中位数
        int mid = new_nums[N / 2];

        int min = Integer.MAX_VALUE;
        //最终的索引
        int result = -1;
        for (int i = 0; i <= N - K; i++) {
            int count = nums[i];
            for (int j = i + 1; j < i + K; j++) {
                count -= nums[j];
            }
            //求计算结果与中位数的距离
            int abs = Math.abs(count - mid);
            min = Math.min(min, abs);
            if (min == abs) {
                result = i;
            }
        }

        System.out.println(result);
    }

}
