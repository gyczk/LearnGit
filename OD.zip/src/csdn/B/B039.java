package csdn.B;

import java.util.*;

// 乘坐保密电梯
public class B039 {
    public static void main(String[] args) {
        //输入处理，这里用了多种方法的输入，大家需要熟悉
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] params = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            params[i] = Integer.parseInt(tmp2[i]);
        }
        int target = params[0];
        int count = params[1];
        int[] nums = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();

        //求和
        int sum = 0;
        int min_distance = Integer.MAX_VALUE;
        List<Integer> floor_list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            floor_list.add(nums[i]);
            sum += nums[i];
        }

        //找出下降层数
        List<Integer> downs = new ArrayList<>();
        boolean flag = false;
        solve(target, sum, floor_list, min_distance, count / 2, new ArrayList<>(), 0, downs, flag);

        for (Integer down : downs) {
            if (floor_list.contains(down)) {
                floor_list.remove(down);
            }
        }
        Collections.reverse(floor_list);
        Collections.reverse(downs);

        String result_str = "";
        //上升和下降交替存在
        for (int i = 0; i < floor_list.size(); i++) {
            result_str += floor_list.get(i) + " ";
            if (i < downs.size()) {
                result_str += downs.get(i) + " ";
            }
        }
        System.out.println(result_str);
    }

    public static void solve(int target, int sum, List<Integer> floor_list, int min_distance, int n, List<Integer> list, int index, List<Integer> downs, boolean flag) {
        if (flag) {
            return;
        }

        if (n != 0) {
            for (int i = index; i < floor_list.size(); i++) {
                list.add(floor_list.get(i));
                solve(target, sum, floor_list, min_distance, n - 1, list, i + 1, downs, flag);
                list.remove(list.size() - 1);
            }
        } else {
            int cnt1 = 0;
            for (int i = 0; i < list.size(); i++) {
                cnt1 += list.get(i);
            }
            int distance = Math.abs(sum - 2 * cnt1 - target);
            if (distance == 0) {
                downs = new ArrayList<>(list);
                flag = true;
            } else if (min_distance > distance) {
                min_distance = distance;
                downs = new ArrayList<>(list);
            }

        }

    }
}
