package csdn.Bo;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


// 求解连续数列
public class Bo113 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int s = in.nextInt();
        int n = in.nextInt();
        int num;
        List<Integer> result = new ArrayList<>();
        if (2 * s % n != 0) {
            System.out.print(-1);
        } else if ((2 * s / n - n) % 2 == 0) {
            System.out.print(-1);
        } else {
            num = (2 * s / n + 1 - n) / 2;
            for (int i = 0; i < n; i++) {
                result.add(num + i);
            }
            for (int i = 0; i < result.size(); i++) {
                System.out.print(result.get(i));
                if (i != result.size() - 1) {
                    System.out.print(' ');
                }
            }
        }


    }

}
