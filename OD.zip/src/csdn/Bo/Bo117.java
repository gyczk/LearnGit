package csdn.Bo;


import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 输出指定字母在字符串中的索引
public class Bo117 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String[] strs = in.nextLine().split(" ");
        String origin_str = strs[0];
        int idx = Integer.parseInt(strs[1]);
        Character[] split_arr = new Character[origin_str.length()];
        int i = 0;
        while (true) {
            if (i >= origin_str.length()) {
                break;
            } else {
                split_arr[i] = origin_str.charAt(i);
            }
            i += 1;
        }

        Arrays.sort(split_arr, new Comparator<Character>() {
            @Override
            //在这里主要是重写了 Comparator类的compare方法，
            //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
            public int compare(Character o1, Character o2) {
                return o1.compareTo(o2);
            }
        });

        System.out.println(origin_str.indexOf(split_arr[idx - 1]));
    }
}
