package csdn.Bo;


import java.util.*;

// 树形目录删除
public class Bo058 {
    public static Map<Integer, List<Integer>> tree = new TreeMap<>();

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        List<Integer> parents = new ArrayList<>();
        List<Integer> childs = new ArrayList<>();
        int num = in.nextInt();
        for (int i = 0; i < num; i++) {
            childs.add(in.nextInt());
            parents.add(in.nextInt());
        }
        int rmId = in.nextInt();

        //建立树形结构
        buildTree(parents, childs);
        rmNode(rmId);

        //输出
        tree.keySet().forEach(e -> {
            System.out.print(e);
            System.out.print(" ");
        });
        System.out.println();


    }

    public static void buildTree(List<Integer> parent, List<Integer> node) {
        for (int i = 0; i < node.size(); i++) {
            Integer nodeKey = node.get(i);
            Integer parentKey = parent.get(i);
            if (!tree.containsKey(nodeKey)) {
                tree.put(nodeKey, new ArrayList<>());
            }
            if (parentKey.equals(0)) {
                continue;
            }
            List<Integer> parentList = null;
            if (tree.containsKey(parentKey)) {
                parentList = tree.get(parentKey);
            } else {
                parentList = new ArrayList<>();
                tree.put(parentKey, parentList);
            }

            parentList.add(nodeKey);
        }
    }

    public static void rmNode(Integer node) {
        List<Integer> children = tree.get(node);
        if (children == null) {
            return;
        }
        if (children.size() == 0) {
            tree.remove(node);
            return;
        }

        for (Integer child : children) {
            rmNode(child);
        }
        tree.remove(node);
    }

}
