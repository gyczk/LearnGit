package csdn.A;

//
public class A126 {

}
