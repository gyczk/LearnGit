package csdn.Bo;


import java.util.Scanner;

// 事件推送
public class Bo004 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String param_str = in.nextLine();
        String m_str = in.nextLine();
        String n_str = in.nextLine();

        String[] param_list = param_str.split(" ");
        int R = Integer.valueOf(param_list[2]);

        String[] m_List = m_str.split(" ");
        String[] n_List = n_str.split(" ");

        int index = 0;
        //双层循环判定
        for (int i = 0; i < m_List.length; i++) {
            if (m_List[i].trim().length() <= 0) {
                continue;
            }
            int m_temp = Integer.valueOf(m_List[i]);
            for (int j = index; j < n_List.length; j++) {
                index = j;
                if (n_List[j].trim().length() <= 0) {
                    continue;
                }
                int n_temp = Integer.valueOf(n_List[j]);
                if (m_temp <= n_temp) {
                    if (n_temp - m_temp <= R) {
                        System.out.println(m_temp + " " + n_temp);
                    }
                    break;
                }

            }
        }

    }
}

