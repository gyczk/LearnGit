package csdn.Bo;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

// 信道分配
public class Bo070 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int R = Integer.parseInt(in.nextLine());

        String[] NiStrs = in.nextLine().split(" ");
        int[][] Nis = new int[R + 1][2];
        for (int i = 0; i < Nis.length; i++) {
            Nis[i][0] = (int) Math.pow(2, i);
            Nis[i][1] = Integer.parseInt(NiStrs[i]);
        }

        int D = Integer.parseInt(in.nextLine());

        int count = 0;
        Map<Integer, Integer> shizhi = new HashMap<>();
        for (int[] ni : Nis) {
            int Ni = ni[0];
            int Ni_count = ni[1];

            if (Ni_count == 0) {
                continue;
            }

            if (Ni >= D) {
                count += Ni_count;
                continue;
            }

            int mo = D % Ni;
            int shang = D / Ni;
            int need_count = mo == 0 ? shang : shang + 1;

            count += Ni_count / need_count;

            // 剩余个数
            int Ni_count_left = Ni_count - (Ni_count / need_count) * need_count;

            if (shizhi.size() != 0) {
                int temp = 0;
                for (Map.Entry<Integer, Integer> en : shizhi.entrySet()) {
                    temp += en.getKey() * en.getValue();
                }

                // 单个用户还剩多少数据量
                int D_left = D - temp;
                int mo_left = D_left % Ni;
                int shang_left = D_left / Ni;
                int need_count_left = mo_left == 0 ? shang_left : shang_left + 1;

                if (Ni_count_left >= need_count_left) {
                    shizhi.clear();
                    count++;
                    Ni_count_left -= need_count_left;
                }

            }

            if (Ni_count_left > 0) {
                shizhi.put(Ni, Ni_count_left);
            }
        }

        System.out.println(count);
    }
}


