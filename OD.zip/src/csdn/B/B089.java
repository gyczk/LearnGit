package csdn.B;


import java.util.Scanner;

// 整数编码
public class B089 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int num = in.nextInt();
        String binary = Integer.toBinaryString(num);

        int len = binary.length();

        StringBuilder builder = new StringBuilder();

        for (int i = len; i > 0; i -= 7) {
            int start = Math.max(i - 7, 0);
            String bin = binary.substring(start, i);
            if (bin.length() < 7) {
                StringBuilder head = new StringBuilder();
                for (int j = 0; j < 7 - bin.length(); j++) {
                    head.append("0");
                }
                bin = head.append(bin).toString();
            }
            bin = i - 7 <= 0 ? "0" + bin : "1" + bin;
            String hex = Integer.toHexString(Integer.parseInt(bin, 2)).toUpperCase();
            if (hex.length() == 1) hex = "0" + hex;
            builder.append(hex);
        }
        System.out.println(builder);

    }

}
