package csdn.B;


import java.util.HashMap;
import java.util.Scanner;

// 	最佳的出牌方法
public class B094 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String cards = in.nextLine();
        HashMap<Integer, Integer> card_count = new HashMap<>();
        for (int i = 1; i <= 13; i++) {
            card_count.put(i, 0);
        }

        // 统计各种牌的数量
        for (int i = 0; i < cards.length(); i++) {
            char card = cards.charAt(i);
            if (card == '0') {
                if (!card_count.containsKey(10)) {
                    card_count.put(10, 0);
                }
                card_count.put(10, card_count.get(10) + 1);
            } else if (card == 'J') {
                if (!card_count.containsKey(11)) {
                    card_count.put(11, 0);
                }
                card_count.put(11, card_count.get(11) + 1);
            } else if (card == 'Q') {
                if (!card_count.containsKey(12)) {
                    card_count.put(12, 0);
                }
                card_count.put(12, card_count.get(12) + 1);
            } else if (card == 'K') {
                if (!card_count.containsKey(13)) {
                    card_count.put(13, 0);
                }
                card_count.put(13, card_count.get(13) + 1);
            } else {
                if (!card_count.containsKey(card - '0')) {
                    card_count.put(card - '0', 0);
                }
                card_count.put(card - '0', card_count.get(card - '0') + 1);
            }
        }

        int value = 0;

        // 找顺子
        while (true) {
            int maxest = 0;
            int left = 0;
            int m = 1;
            while (true) {
                if (m >= 10) {
                    break;
                } else {
                    int temp = solve(card_count, m);
                    if (temp > maxest) {
                        maxest = temp;
                        left = m;
                    }
                }
                m += 1;
            }

            if (left == 0) {
                break;
            }

            for (int i = left; i <= left + 4; i++) {
                value += i * 2;
                card_count.put(i, card_count.get(i) - 1);
            }
        }

        for (int i = 1; i <= 13; i++) {
            System.out.println(card_count.get(i));
            if (card_count.get(i) == 1) {
                value += i;
            } else if (card_count.get(i) == 3 || card_count.get(i) == 2) {
                value += i * card_count.get(i) * 2;
            } else if (card_count.get(i) == 4) {
                value += i * card_count.get(i) * 3;
            }
        }

        System.out.println(value);
    }

    public static int solve(HashMap<Integer, Integer> card_count, int index) {
        int add_val = 0;
        for (int i = index; i <= index + 4; i++) {
            if (card_count.get(i) == 0) {
                return Integer.MIN_VALUE;
            } else if (card_count.get(i) == 1) {
                add_val += i;
            } else if (card_count.get(i) == 2) {
                add_val -= i;
            } else if (card_count.get(i) == 4) {
                add_val -= i * 4;
            }
        }

        return add_val;
    }
}

