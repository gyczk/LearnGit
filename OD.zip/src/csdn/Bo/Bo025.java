package csdn.Bo;


import java.util.Arrays;
import java.util.Scanner;

// 乱序整数序列两数之和绝对值最小
public class Bo025 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        int[] v = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();

        int result = 0;
        int sum = 0;

        Arrays.sort(v);

        int target = 0;
        int value_1 = 0, value_2 = 0;
        // 第一步先找到最靠近0的位置(左侧)
        int pos_0 = find_k(v, 0, v.length - 1, 0);

        // 无负数
        if (pos_0 == 0) {
            System.out.println(v[0] + " " + v[1] + " " + (v[0] + v[1]));
            return;
            // 只有一个负数
        } else if (pos_0 == 1) {
            target = Math.abs(v[0]);
            // 超过两个负数
        } else {
            target = Math.abs(v[pos_0 - 1] + v[pos_0 - 2]);
        }

        // 然后遍历负数区,找到正数区域最接近x的那个位置j
        for (int i = 0; i < pos_0; ++i) {
            int j = find_k(v, pos_0, v.length - 1, Math.abs(v[i]));
            if (target > Math.abs(v[i] + v[j])) {
                target = Math.abs(v[i] + v[j]);
                value_1 = v[i];
                value_2 = v[j];
            }
        }
        System.out.println(value_1 + " " + value_2 + " " + target);

    }

    public static int find_k(int[] arr, int left, int right, int k) {
        // 特殊情况
        if (left > right) {
            return -1;
        }
        if (left == right) {
            return arr[left];
        }

        // 二分查找
        int j = left;
        while (left <= right) {
            int mid = left + ((right - left) >> 1);
            if (arr[mid] <= k) {
                j = mid;
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        //如果没有找到，那最接近k的只能是 left 位置了
        if (j == left) {
            return j;
        } else {
            // 注意一个特殊情况，可能j+1位置更近
            return k - arr[j] <= k - arr[j + 1] ? j : j + 1;
        }
    }
}
