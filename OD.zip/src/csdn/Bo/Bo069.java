package csdn.Bo;


import java.util.Scanner;


// 竖直四子棋
public class Bo069 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String[] params = in.nextLine().split(" ");
        int m = Integer.parseInt(params[0]);
        int n = Integer.parseInt(params[1]);

        String[] nums = in.nextLine().split(" ");
        int[][] matrix = new int[n][m];
        boolean isOver = false;
        for (int i = 0; i < nums.length; i++) {
            int index = -1;
            int color = 1;
            int num = Integer.parseInt(nums[i]);
            if (num <= 0 || num > m || matrix[0][num - 1] != 0) {
                isOver = true;
                System.out.println(i + 1 + ",error");
                break;
            }
            //偶数下标为red，用1表示, 奇数下标为blue，用2表示
            if (i % 2 != 0) {
                color = 2;
            }
            for (int j = n - 1; j >= 0; j--) {
                if (matrix[j][num - 1] == 0) {
                    index = j;
                    matrix[j][num - 1] = color;
                    break;
                }
            }
            if (index == -1) {
                System.out.println(i + 1 + ",error");
                isOver = true;
                break;
            }
            //第七个棋子开始才能符合四棋子
            if (i >= 6 && check(matrix, index, num - 1)) {
                if (color == 1) {
                    System.out.println(i + 1 + ",red");
                    isOver = true;
                    break;
                } else {
                    System.out.println(i + 1 + ",blue");
                    isOver = true;
                    break;
                }
            }
        }
        if (!isOver) {
            System.out.println("0,draw");
        }
    }

    public static boolean check(int[][] matrix, int x, int y) {
        int h = matrix.length;    //数组有h行
        int l = matrix[0].length; //数组有l列
        int count = 0;  //统计相同的棋子（3即可）
        int jishu = 3;  //四个棋子只要统计三次

        if (x < h - 3) {  //纵向四棋子
            int a = x;
            while ((jishu != 0) && matrix[a][y] == matrix[++a][y]) {
                count++;
                jishu--;
            }
            if (count == 3) {
                return true;
            }
            count = 0;
            jishu = 3;
        }
        if (y >= 3) {   //左边横向四棋子
            int b = y;
            while ((jishu != 0) && matrix[x][b] == matrix[x][--b]) {
                count++;
                jishu--;
            }
            if (count == 3) {
                return true;
            }
            count = 0;
            jishu = 3;
        }
        if (y < l - 3) {  //右边横向四棋子
            int b = y;
            while ((jishu != 0) && matrix[x][b] == matrix[x][++b]) {
                count++;
                jishu--;
            }
            if (count == 3) {
                return true;
            }
            count = 0;
            jishu = 3;
        }
        if (x < h - 3 && y >= 3) {  //左边斜向四棋子
            int a = x;
            int b = y;
            while ((jishu != 0) && matrix[a][b] == matrix[++a][--b]) {
                count++;
                jishu--;
            }
            if (count == 3) {
                return true;
            }
            count = 0;
            jishu = 3;
        }
        if (x < h - 3 && y < l - 3) { //右边斜向四棋子
            int a = x;
            int b = y;
            while ((jishu != 0) && matrix[a][b] == matrix[++a][++b]) {
                count++;
                jishu--;
            }
            return count == 3;
        }
        return false;
    }
}
