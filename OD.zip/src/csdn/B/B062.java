package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

// 计算礼品发放的最小分组数目
public class B062 {
    public static int count = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int target = Integer.parseInt(in.nextLine());
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        Arrays.sort(nums);
        int j = nums.length - 1;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] + nums[j] > target) {
                i -= 1;
            }
            j -= 1;
            count += 1;
            if (i >= j) {
                break;
            }
        }
        System.out.println(count);
    }
}