package csdn.B;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

// 周末爬山
public class B079 {
    public static int count = 0;

    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String input_str1 = in.nextLine();
        String[] tmp1 = input_str1.split(" ");
        int[] params = new int[tmp1.length];
        for (int j = 0; j < tmp1.length; j++) {
            params[j] = Integer.parseInt(tmp1[j]);
        }
        int m = params[0];
        int n = params[1];
        int k = params[2];

        int[][] matrix = new int[m][n];
        for (int i = 0; i < m; i++) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(" ");
            int[] nums = new int[tmp2.length];
            for (int j = 0; j < tmp2.length; j++) {
                nums[j] = Integer.parseInt(tmp2[j]);
            }
            System.arraycopy(nums, 0, matrix[i], 0, n);
        }

        HashMap<Integer, Integer> temp_map = new HashMap<>();
        temp_map.put(matrix[0][0], 0);

        ArrayList<int[]> stack = new ArrayList<>();
        // 访问记录
        int[][] visited = new int[m][n];

        stack.add(new int[]{0, 0});
        visited[0][0] = 1;
        while (stack.size() > 0) {
            ArrayList<int[]> empty_stack = new ArrayList<>();
            count += 1;
            int i = 0;
            while (true) {
                if (i >= stack.size()) {
                    break;
                } else {
                    int x = stack.get(i)[0];
                    int y = stack.get(i)[1];

                    int last_height = matrix[x][y];

                    if (x + 1 < m) {
                        if (visited[x + 1][y] == 0) {
                            if (Math.abs(matrix[x + 1][y] - matrix[x][y]) <= k) {
                                visited[x + 1][y] = 1;
                                if (!temp_map.containsKey(matrix[x + 1][y]) || temp_map.get(matrix[x + 1][y]) > count)
                                    temp_map.put(matrix[x + 1][y], count);
                                empty_stack.add(new int[]{x + 1, y});
                            }
                        }
                    }
                    if (x - 1 >= 0) {
                        if (visited[x - 1][y] == 0) {
                            if (Math.abs(matrix[x - 1][y] - matrix[x][y]) <= k) {
                                visited[x - 1][y] = 1;
                                if (!temp_map.containsKey(matrix[x - 1][y]) || temp_map.get(matrix[x - 1][y]) > count)
                                    temp_map.put(matrix[x - 1][y], count);
                                empty_stack.add(new int[]{x - 1, y});
                            }
                        }
                    }
                    if (y - 1 >= 0) {
                        if (visited[x][y - 1] == 0) {
                            if (Math.abs(matrix[x][y - 1] - matrix[x][y]) <= k) {
                                visited[x][y - 1] = 1;
                                if (!temp_map.containsKey(matrix[x][y - 1]) || temp_map.get(matrix[x][y - 1]) > count)
                                    temp_map.put(matrix[x][y - 1], count);
                                empty_stack.add(new int[]{x, y - 1});
                            }
                        }
                    }
                    if (y + 1 < n) {
                        if (visited[x][y + 1] == 0) {
                            if (Math.abs(matrix[x][y + 1] - matrix[x][y]) <= k) {
                                visited[x][y + 1] = 1;
                                if (!temp_map.containsKey(matrix[x][y + 1]) || temp_map.get(matrix[x][y + 1]) > count)
                                    temp_map.put(matrix[x][y + 1], count);
                                empty_stack.add(new int[]{x, y + 1});
                            }
                        }
                    }
                }
                i += 1;
            }
            stack = empty_stack;
        }

        int max_height = 0;
        for (Integer key : temp_map.keySet()) {
            max_height = Math.max(max_height, key);
        }
        System.out.println(max_height + " " + temp_map.get(max_height));
    }
}

