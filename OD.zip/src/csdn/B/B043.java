package csdn.B;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.Scanner;

// 二维伞的雨滴效应
public class B043 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        // 前序遍历的输入
        int[] pre_order = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        TreeNode root = new TreeNode(pre_order[0]);

        // 用一个栈来保存节点
        Deque<TreeNode> stack = new ArrayDeque<>();
        stack.push(root);
        // 辅助节点, 用来判断是否是二叉搜索树
        TreeNode helper = new TreeNode(-1);
        boolean flag = true;
        // 判断并构造二叉搜索树
        for (int i = 1; i < pre_order.length; i++) {
            TreeNode node = stack.peekLast();
            TreeNode currentNode = new TreeNode(pre_order[i]);
            while (!stack.isEmpty() && stack.peekLast().val < currentNode.val) {
                node = stack.removeLast();
                if (!stack.isEmpty()) {
                    helper = stack.peekLast();
                }
            }

            //不满足二叉搜索树属性直接跳出
            if (node.val < currentNode.val) {
                node.right = currentNode;
                helper = node;
            } else {
                if (currentNode.val < helper.val) {
                    flag = false;
                    break;
                }
                node.left = currentNode;
            }
            stack.addLast(currentNode);
        }

        if (flag) {
            TreeNode leftNode = root;
            while (leftNode.left != null || leftNode.right != null) {

                if (leftNode.left != null) {
                    leftNode = leftNode.left;
                } else {
                    leftNode = leftNode.right;
                }
            }
            TreeNode rightNode = root;
            while (rightNode.left != null || rightNode.right != null) {

                if (rightNode.right != null) {
                    rightNode = rightNode.right;
                } else {
                    rightNode = rightNode.left;
                }
            }

            System.out.println("1 " +
                    (leftNode.val == root.val ? 0 : leftNode.val) + " " +
                    (rightNode.val == root.val ? 0 : rightNode.val));
        } else {
            System.out.println("0 0 0");
        }
    }

    static class TreeNode {

        int val;
        TreeNode left;
        TreeNode right;

        public TreeNode() {
        }

        public TreeNode(int val) {
            this.val = val;
        }

    }
}
