package csdn.A;

//
public class A046 {

}
