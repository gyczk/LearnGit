package csdn.B;


import java.util.Scanner;


// 单词加密
public class B092 {

    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();

        String[] words = input_str.split(" ");

        String yuanyin = "aeiouAEIOU";

        //使用暴力遍历的方法，不涉及抄袭了吧
        for (int i = 0; i < words.length; i++) {
            int yuanyin_count = 0;
            for (int j = 0; j < words[i].length(); j++) {
                boolean status = yuanyin.contains(String.valueOf(words[i].charAt(j)));
                if (status) {
                    //words[i][j] = '*';
                    StringBuffer sb = new StringBuffer(words[i]);
                    sb.replace(j, j + 1, "*");
                    words[i] = sb.toString();
                    yuanyin_count += 1;
                }
            }
            if (yuanyin_count == 0) {
                //首尾字符交换
                words[i] = swap(words[i]);
            }
        }

        System.out.println(String.join(" ", words));
    }

    public static String swap(String s) {
        char[] ch = s.toCharArray();
        char tmp = ch[0];
        ch[0] = ch[ch.length - 1];
        ch[ch.length - 1] = tmp;
        return new String(ch);
    }
}
