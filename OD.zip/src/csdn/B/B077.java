package csdn.B;


import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.Scanner;


// 	荒岛求生
public class B077 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        int[] nums = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        System.out.println(asteroidCollision(nums));
    }

    public static int asteroidCollision(int[] asteroids) {
        Deque<Integer> stack = new ArrayDeque<Integer>();
        int i = 0;
        int left_cnt = 0;
        while (true) {
            if (i >= asteroids.length) {
                break;
            } else {
                if (asteroids[i] <= 0) {
                    while (true) {
                        if (stack.isEmpty()) {
                            left_cnt += 1;
                            break;
                        }
                        if ((asteroids[i] + stack.peekLast()) > 0) {
                            stack.addLast(asteroids[i] + stack.peekLast());
                            stack.removeLast();
                            break;
                        } else if ((asteroids[i] + stack.peekLast()) < 0) {
                            asteroids[i] = asteroids[i] + stack.peekLast();
                            stack.removeLast();
                        } else if ((asteroids[i] + stack.peekLast()) == 0) {
                            stack.removeLast();
                            break;
                        }
                    }
                } else {
                    stack.addLast(asteroids[i]);
                }
            }
            i += 1;
        }
        int right_cnt = stack.size();
        return left_cnt + right_cnt;
    }
}
