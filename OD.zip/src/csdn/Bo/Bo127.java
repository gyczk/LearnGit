package csdn.Bo;


import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 叠积木
public class Bo127 {
    public static int result = 0;

    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String[] s = in.nextLine().split(" ");
        Integer[] nums = new Integer[s.length];
        int count = 0;
        for (int i = 0; i < nums.length; i++) {
            nums[i] = Integer.parseInt(s[i]);
            count += 1;
        }
        if (count == 1 || count == 2) {
            solve(nums.length, nums);
            return;
        }

        Arrays.sort(nums, new Comparator<Integer>() {
            //重写compare方法，最好加注解，不加也没事
            public int compare(Integer a, Integer b) {
                return b - a;
            }
        });
        int len = nums[0];
        boolean flag = false;
        while (true) {
            if (len > nums[0] + nums[1]) {
                break;
            } else {
                result = 0;
                int left = 0, right = count - 1;
                while (true) {
                    if (left >= count || nums[left] != len) {
                        break;
                    } else {
                        left += 1;
                        result += 1;
                    }
                }
                while (true) {
                    if (left >= right) {
                        break;
                    } else {
                        if (nums[left] + nums[right] == len) {
                            left += 1;
                            right -= 1;
                            result += 1;
                        } else {
                            break;
                        }
                    }

                }
                if (left > right) {
                    System.out.println(result);
                    flag = true;
                    break;
                }
            }
            len += 1;
        }
        if (!flag) {
            System.out.println(-1);
        }

    }

    public static void solve(int n, Integer[] nums) {
        System.out.println(n == 1 ? 1 : (nums[0] - nums[1] != 0 ? 1 : 2));
    }
}

