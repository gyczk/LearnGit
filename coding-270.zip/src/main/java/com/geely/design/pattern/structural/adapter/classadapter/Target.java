package com.geely.design.pattern.structural.adapter.classadapter;

/**
 * Created by geely
 */
public interface Target {
    void request();
}
