package com.geely.design.principle.singleresponsibility;

/**
 * Created by geely
 */
public class FlyBird {
    public void mainMoveMode(String birdName){
        System.out.println(birdName+"用翅膀飞");
    }
}
