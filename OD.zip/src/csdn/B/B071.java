package csdn.B;


import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 	字符串筛选排序
public class B071 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        int count = Integer.parseInt(in.nextLine());
        //这里直接进行比较
        count = count > input_str.length() ? input_str.length() : count;
        char[] chars = input_str.toCharArray();
        //还熟悉试试自定义排序嘛？
        Integer[] nums3 = new Integer[]{4, 6, 8, 0, 5, 9, 7, 2, 1, 3};
        Arrays.sort(nums3, new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o2 - o1;
            }
        });
        Arrays.sort(chars);
        System.out.println(input_str.indexOf(chars[count - 1]));
    }
}
