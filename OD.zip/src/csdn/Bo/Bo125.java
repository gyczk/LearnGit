package csdn.Bo;


import java.util.Scanner;


// 判断一组不等式是否满足约束并输出最大差
public class Bo125 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String[] input_str = in.nextLine().split(";");

        //各项系数初始化
        int num_eq = input_str[input_str.length - 1].split(",").length;
        int num_x = input_str[0].split(",").length;
        double[][] a = new double[num_eq][num_x];
        int[] x = new int[num_x];
        double[] b = new double[num_eq];
        String[] eq = new String[num_eq];
        int[] res = new int[num_eq];
        int result = 0;
        boolean flag = true;

        // 输入字符串处理
        for (int i = 0; i < num_eq; i++) {
            String[] param_a = input_str[i].split(",");
            for (int j = 0; j < param_a.length; j++) {
                a[i][j] = Double.valueOf(param_a[j]);
            }
        }
        String[] param_b = input_str[num_eq + 1].split(",");
        for (int i = 0; i < param_b.length; i++) {
            b[i] = Double.valueOf(param_b[i]);
        }
        String[] param_x = input_str[num_eq].split(",");
        for (int i = 0; i < param_x.length; i++) {
            x[i] = Integer.parseInt(param_x[i]);
        }
        String[] param_char = input_str[num_eq + 2].split(",");
        System.arraycopy(param_char, 0, eq, 0, param_char.length);

        //算不等式结果
        for (int i = 0; i < num_eq; i++) {
            double tmp = 0.0;
            for (int j = 0; j < num_x; j++) {
                tmp += a[i][j] * x[j];
            }
            if ("<=".equals(eq[i])) {
                flag = tmp <= b[i] ? flag : false;
            } else if ("<".equals(eq[i])) {
                flag = tmp < b[i] ? flag : false;
            } else if ("=".equals(eq[i])) {
                flag = tmp == b[i] ? flag : false;
            } else if (">=".equals(eq[i])) {
                flag = tmp >= b[i] ? flag : false;
            } else if (">".equals(eq[i])) {
                flag = tmp > b[i] ? flag : false;
            }
            res[i] = (int) ((tmp - b[i]));
        }
        for (int i = 0; i < num_eq; i++) {
            result = Math.max(result, res[i]);
        }
        System.out.println(flag + " " + result);
    }
}

