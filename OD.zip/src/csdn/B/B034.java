package csdn.B;

import java.util.LinkedList;
import java.util.Scanner;
import java.util.TreeSet;

// 	字符串化繁为简
public class B034 {


    public static LinkedList<TreeSet<Character>> equal_chars = new LinkedList<>();
    public static boolean flag = false;
    public static String result = "";

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();

        int k = 0;
        while (true) {
            if (k >= input_str.length()) {
                break;
            } else {
                if (input_str.charAt(k) == ')') {
                    flag = false;
                    TreeSet<Character> temp = equal_chars.getLast();
                    if (temp.size() == 0) {
                        equal_chars.removeLast();
                    }
                } else if (input_str.charAt(k) == '(') {
                    flag = true;
                    equal_chars.add(new TreeSet<>());
                } else {
                    TreeSet<Character> temp = equal_chars.getLast();
                    if (flag) {
                        temp.add(input_str.charAt(k));
                    } else {
                        result += input_str.charAt(k);
                    }
                }
            }
            k += 1;
        }
        global_merge();

        char[] tmp_res_arr = result.toCharArray();
        int m = 0;
        while (true) {
            if (m >= equal_chars.size()) {
                if (tmp_res_arr.length == 0) {
                    System.out.println(0);
                } else {
                    System.out.println(new String(tmp_res_arr));
                }
                break;
            } else {
                for (int i = 0; i < tmp_res_arr.length; i++) {
                    if (equal_chars.get(m).contains(tmp_res_arr[i])) {
                        tmp_res_arr[i] = equal_chars.get(m).first();
                    }
                }
            }
            m += 1;
        }
    }

    public static void global_merge() {
        int i = 0;
        while (true) {
            if (i >= equal_chars.size()) {
                break;
            } else {
                int j = i + 1;
                while (true) {
                    if (j >= equal_chars.size()) {
                        break;
                    } else {
                        boolean flag = false;
                        for (char single_char = 'a'; single_char <= 'z'; single_char++) {
                            char new_char = (char) (single_char - 32);
                            if ((equal_chars.get(i).contains(single_char) || equal_chars.get(i).contains(new_char))) {
                                if ((equal_chars.get(j).contains(single_char) || equal_chars.get(j).contains(new_char))) {
                                    flag = true;
                                    break;
                                }
                            }
                        }
                        if (flag) {
                            equal_chars.get(i).addAll(equal_chars.get(j));
                            equal_chars.remove(j);
                            global_merge();
                        }

                    }
                    j += 1;
                }
            }
            i += 1;
        }
    }

}
