package com.geely.design.pattern.structural.facade;

/**
 * Created by geely
 */
public class PointsGift {
    private String name;

    public PointsGift(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
