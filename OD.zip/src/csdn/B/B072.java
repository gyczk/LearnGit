package csdn.B;


import java.util.Scanner;
import java.util.regex.Pattern;

// 相对开音节
public class B072 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String[] words = in.nextLine().split(" ");
        int count = 0;

        Pattern nonLetter = Pattern.compile("[^a-z]");
        Pattern reg1 = Pattern.compile("[^aeiou][aeiou][^aeiour]e");
        Pattern reg2 = Pattern.compile("e[^aeiour][aeiou][^aeiou]");

        for (String word : words) {
            Pattern reg = nonLetter.matcher(word).find() ? reg1 : reg2;

            for (int i = 0; i <= word.length() - 4; i++) {
                String seg = word.substring(i, i + 4);

                if (nonLetter.matcher(seg).find()) continue;

                if (reg.matcher(seg).find()) count++;
            }
        }

        System.out.println(count);
    }
}
