package csdn.Bo;

// 太阳能板最大面积
public class Bo016 {

}
