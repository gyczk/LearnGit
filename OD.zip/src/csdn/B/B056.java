package csdn.B;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

// 矩阵元素边界值
public class B056 {

    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        //处理输入
        String input = in.nextLine();

        int index = 0;
        String value = "";
        // 用treeset来保存每列的数，自动排序
        List<TreeSet<Integer>> list = new ArrayList<>();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            // 下一行开始
            if (c == '[') {
                index = 0;
                // 本行结束
            } else if (c == ']' || c == ',') {
                if (value.equals("")) {
                    continue;
                }
                int num = Integer.valueOf(value);
                if (list.size() - 1 < index) {
                    TreeSet<Integer> treeSet = new TreeSet<>();
                    treeSet.add(num);
                    list.add(treeSet);
                } else {
                    list.get(index).add(num);
                }
                value = "";
                index++;
            } else {
                value += c;
            }
        }

        int result = Integer.MAX_VALUE;
        for (TreeSet<Integer> treeSet : list) {
            result = Math.min(result, treeSet.last());
        }
        System.out.println(result);
    }

}
