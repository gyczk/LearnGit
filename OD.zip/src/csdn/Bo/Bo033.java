package csdn.Bo;


import java.util.Scanner;

// 最长子字符串的长度
public class Bo033 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input = in.nextLine();
        char[] chrs = input.toCharArray();
        int len = chrs.length;
        int num = 0;
        for (char chr : chrs) {
            if (chr == 'o') {
                num += 1;
            }
        }
        if (num % 2 == 0) {
            System.out.println(len);
        } else {
            //出现了奇数次
            System.out.println(len - 1);
        }
    }
}
