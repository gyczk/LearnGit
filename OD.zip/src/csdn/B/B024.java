package csdn.B;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// 组装最大可靠性设备
public class B024 {
    public static long result = -1;
    public static int s = -1;
    public static int n = -1;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        //输入处理
        s = in.nextInt();
        n = in.nextInt();
        int total = in.nextInt();
        in.nextLine();
        List<long[]> items = new ArrayList<>();
        for (int i = 0; i < total; i++) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(" ");
            int[] nums = new int[tmp2.length];
            for (int j = 0; j < tmp2.length; j++) {
                nums[j] = Integer.parseInt(tmp2[j]);
            }
            items.add(new long[]{nums[0] + 1, nums[1], nums[2]});
        }

        long left = 0;
        long right = total * 10000L;
        while (true) {
            if (left > right) {
                System.out.println(result);
                break;
            } else {
                if (cal(left + (right - left) / 2, items)) {
                    result = left + (right - left) / 2;
                    left += (right - left) / 2 + 1;
                } else {
                    right = left + (right - left) / 2 - 1;
                }
            }

        }
    }

    public static boolean cal(long x, List<long[]> devices) {
        long[] temp = new long[n + 1];
        for (int i = 1; i <= n; i++) {
            temp[i] = Integer.MAX_VALUE;
        }
        int j = 0;
        while (true) {
            if (j >= devices.size()) {
                long all = 0;
                for (int i = 1; i <= n; i++) {
                    all += temp[i];
                }
                return all <= s;
            } else {
                if (devices.get(j)[1] >= x) {
                    temp[(int) devices.get(j)[0]] = Math.min(temp[(int) devices.get(j)[0]], devices.get(j)[2]);
                }
            }
            j += 1;
        }
    }
}
