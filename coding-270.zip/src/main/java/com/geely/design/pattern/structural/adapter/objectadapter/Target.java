package com.geely.design.pattern.structural.adapter.objectadapter;

/**
 * Created by geely
 */
public interface Target {
    void request();
}
