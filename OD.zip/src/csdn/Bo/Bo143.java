package csdn.Bo;


import java.util.Scanner;
import java.util.TreeSet;

// 用户调度问题
public class Bo143 {
    public static TreeSet<Integer> intSet = new TreeSet();

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int temp = in.nextInt();
        int[][] arr = new int[temp][3];

        for (int i = 0; i < temp; i++) {
            arr[i][0] = in.nextInt();
            arr[i][1] = in.nextInt();
            arr[i][2] = in.nextInt();
        }
        recursion(arr, 0, temp, arr[0][0], 1);
        recursion(arr, 1, temp, arr[0][1], 1);
        recursion(arr, 2, temp, arr[0][2], 1);
        System.out.println(intSet.first());
    }

    public static void recursion(int[][] arr, int duplicate, int leftCount, int total, int recursionCount) {
        int left = leftCount - 1;
        if (left == 0) {
            intSet.add(total);
            return;
        }
        if (duplicate == 0) {
            recursion(arr, 1, left, total + arr[recursionCount][1], recursionCount + 1);
            recursion(arr, 2, left, total + arr[recursionCount][2], recursionCount + 1);
        } else if (duplicate == 1) {
            recursion(arr, 0, left, total + arr[recursionCount][0], recursionCount + 1);
            recursion(arr, 2, left, total + arr[recursionCount][2], recursionCount + 1);
        } else if (duplicate == 2) {
            recursion(arr, 0, left, total + arr[recursionCount][0], recursionCount + 1);
            recursion(arr, 1, left, total + arr[recursionCount][1], recursionCount + 1);
        }
    }

}
