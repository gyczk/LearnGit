package csdn.Bo;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

// 连续字母长度
public class Bo140 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        char[] chars = in.nextLine().toCharArray();
        int k = in.nextInt();
        HashMap<Character, Integer> map = new HashMap<>();

        if (chars.length == 0) {
            System.out.println(-1);
            return;
        }

        char cur = chars[0];
        int count = 1;
        map.put(cur, count);

        for (int i = 1; i < chars.length; i++) {
            char c = chars[i];
            if (c == cur) count++;
            else {
                cur = c;
                count = 1;
            }
            map.put(cur, map.containsKey(cur) ?
                    map.get(cur) > count ? map.get(cur) : count :
                    count);
        }

        ArrayList<String> list = new ArrayList<>();
        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            list.add(entry.getKey() + "-" + entry.getValue());
        }
        list.sort((o1, o2) -> o2.split("-")[1].compareTo(o1.split("-")[1]));

        if (k > list.size()) {
            System.out.println(-1);
        } else {
            System.out.println(list.get(k - 1).split("-")[1]);
        }

    }

}
