package csdn.B;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

//告警抑制
public class B014 {
    public static int count = 0;
    public static HashMap<String, HashSet<String>> relationships;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        count = Integer.parseInt(in.nextLine());
        relationships = new HashMap<>();

        int i = 0;
        while (true) {
            if (i >= count) {
                break;
            } else {
                String[] pairs = in.nextLine().split(" ");
                if (relationships.containsKey(pairs[1])) {
                    relationships.get(pairs[1]).add(pairs[0]);
                } else {
                    HashSet<String> differents = new HashSet<>();
                    relationships.put(pairs[1], differents);
                    relationships.get(pairs[1]).add(pairs[0]);
                }
            }
            i += 1;
        }
        String[] inputs = in.nextLine().split(" ");
        HashSet<String> new_different = new HashSet<>();
        int j = 0;
        while (true) {
            if (j >= inputs.length) {
                break;
            } else {
                new_different.add(inputs[j]);
            }
            j += 1;
        }


        String output_str = "";
        int k = 0;
        while (true) {
            if (k >= inputs.length) {
                System.out.println(output_str);
                break;
            } else {
                if (!relationships.containsKey(inputs[k])) {
                    output_str += inputs[k];
                    if (k != inputs.length - 1) {
                        output_str += " ";
                    }
                } else if (Collections.disjoint(relationships.get(inputs[k]), new_different)) {
                    output_str += inputs[k];
                    if (k != inputs.length - 1) {
                        output_str += " ";
                    }
                }
            }
            k += 1;
        }
    }
}