package csdn.B;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

//	报文重排序
public class B015 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
        in.nextLine();
        String[] input_strs = in.nextLine().split(" ");

        Map<Integer, String> order_map = new HashMap<>();
        for (int i = 0; i < input_strs.length; i++) {
            String str = input_strs[i];
            int number_pos = 0;
            for (int j = 0; j < str.length(); j++) {
                if (Character.isDigit(str.charAt(j))) {
                    number_pos = j;
                    break;
                }
            }
            order_map.put(Integer.parseInt(str.substring(number_pos)), str.substring(0, number_pos));
        }

        String output_str = "";
        for (int i = 1; i <= N; i++) {
            output_str += order_map.get(i);
            if (i != N) {
                output_str += " ";
            }
        }

        System.out.println(output_str);
    }
}

 