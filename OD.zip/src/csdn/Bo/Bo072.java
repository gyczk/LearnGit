package csdn.Bo;


import java.util.*;

// 猜密码
public class Bo072 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(",");
        Integer[] nums = new Integer[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        int ken = Integer.parseInt(in.nextLine());
        List<Integer> list = new LinkedList<>();
        Arrays.sort(nums, new Comparator<Integer>() {
            @Override
            //在这里主要是重写了 Comparator类的compare方法，
            //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
            public int compare(Integer o1, Integer o2) {
                return o1 - o2;
            }
        });
        for (int i = 0; i < nums.length; i++) {
            ((LinkedList<Integer>) list).addLast(nums[i]);
        }
        List<Integer> res = new LinkedList<>();
        if (ken > nums.length)
            System.out.print("None");
        else {
            dfs(list, res, 0, 2);
        }
    }

    public static void dfs(List<Integer> list, List<Integer> res, int i, int ken) {
        if (res.size() >= ken) {
            for (int a : res) {
                if (a != res.get(res.size() - 1)) {
                    System.out.print(a + ",");
                } else {
                    System.out.println(a);
                }
            }
        }
        for (; i < list.size(); i++) {
            if (res.size() == 0 || list.get(i) > res.get(res.size() - 1)) {
                res.add(list.get(i));
                dfs(list, res, i, ken);
                res.remove(res.size() - 1);
            }
        }

    }


}
