import java.io.*;

public class CreateFile {
    public static void main(String[] args) throws FileNotFoundException {
        String templateFile = "D:\\work\\ideaworkspace\\OD\\src\\template.txt";
        String prefix = "Bo";
        String className;
        String remark;
        File destFile = null;
        FileWriter out = null;
        BufferedReader bufIn=null;
        try {
            String line = null;

            for (int i = 1; i <= 150; i++) {
                // 内存流, 作为临时流
                if (i < 10) {
                    className = prefix + "00" + i;
                } else if (i < 100) {
                    className = prefix + "0" + i;
                } else {
                    className = prefix + i;
                }
                remark = getRemark(i);
                destFile = new File("D:\\work\\ideaworkspace\\OD\\src\\" + className + ".java");
                destFile.createNewFile();
                FileReader in = new FileReader(templateFile);
                 bufIn = new BufferedReader(in);
                CharArrayWriter tempStream = new CharArrayWriter();

                while ((line = bufIn.readLine()) != null) {



                    line = line.replace("${className}", className);
                    line = line.replace("${remark}", remark);
                    // 将该行写入内存
                    tempStream.write(line);
                    // 添加换行符
                    tempStream.append(System.getProperty("line.separator"));

                }
                // 将内存中的流 写入 文件
                out = new FileWriter(destFile);
                tempStream.writeTo(out);
                tempStream.flush();
                bufIn.close();
                out.close();
                tempStream.close();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

    private static String getRemark(int i)  {
        String remarkFile = "D:\\work\\ideaworkspace\\OD\\src\\remark.txt";
        FileReader in = null;
        BufferedReader bufIn=null;
        try {
            in = new FileReader(remarkFile);
            bufIn = new BufferedReader(in);

            String line = null;
            int lineNum = 0;
            while ((line = bufIn.readLine()) != null) {
                lineNum++;
                if (i == lineNum){
                    return line;
                }
            }
        } catch (IOException e) {
            return "";
        }finally {
            try {
                assert bufIn != null;
                bufIn.close();
            } catch (IOException e) {
                System.out.println(123);
            }
        }
        return "";
    }
}

