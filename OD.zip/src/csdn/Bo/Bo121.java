package csdn.Bo;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

// 敏感字段加密
public class Bo121 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int k = Integer.parseInt(scanner.nextLine());
        String s = scanner.nextLine();
        System.out.println(getResult(k, s));
    }

    // 1 passowrd__a12345678_timeout_100              password_******_timeout_100
    // 2 aaa_paaaword_"12_45678"_timeout__100_""_     aaa_password_******_timeout_100_""
    private static String getResult(int k, String s) {
        StringBuilder stack = new StringBuilder();
        LinkedList<String> result = new LinkedList<>();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '_' && (stack.length() == 0 || '"' != stack.charAt(0))) {
                result.add(stack.toString());
                stack = new StringBuilder();
            } else if (c == '"' && stack.length() != 0) {
                stack.append(c);
                result.add(stack.toString());
                stack = new StringBuilder();
            } else {
                stack.append(c);
            }
        }
        if (stack.length() != 0) {
            result.add(stack.toString());
        }
        List<String> ans = result.stream().filter(str -> !"".equals(str)).collect(Collectors.toList());

        if (k > ans.size() - 1) {
            return "ERROR";
        }
        ans.set(k, "******");
        return ans.stream().collect(Collectors.joining("_"));
    }
}
