package csdn.B;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// 计算误码率
public class B059 {
    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        String s1 = in.nextLine();
        String s2 = in.nextLine();

        List<char[]> a_list = new ArrayList<>();
        List<char[]> b_list = new ArrayList<>();
        int index_tmp1 = 0;
        int total = 0;

        int len = s1.length();
        while (index_tmp1 < len) {
            int num = 0;
            while (index_tmp1 < len && Character.isDigit(s1.charAt(index_tmp1))) {
                num *= 10;
                num += s1.charAt(index_tmp1) - '0';
                index_tmp1 += 1;
            }
            char c = s1.charAt(index_tmp1);
            a_list.add(new char[]{c, (char) num});
            total += num;
            index_tmp1 += 1;
        }

        int index_tmp2 = 0;
        int len2_temp = s2.length();
        while (index_tmp2 < len2_temp) {
            int num = 0;
            while (index_tmp2 < len2_temp && Character.isDigit(s2.charAt(index_tmp2))) {
                num *= 10;
                num += s2.charAt(index_tmp2) - '0';
                index_tmp2 += 1;
            }
            char c = s2.charAt(index_tmp2);
            b_list.add(new char[]{c, (char) num});
            index_tmp2 += 1;
        }

        int index = 0;
        int tmp1 = 0, tmp2 = 0;
        int i = 0, j = 0;
        int count = 0;

        while (i < a_list.size() && j < b_list.size()) {
            char[] chars1 = a_list.get(i);
            char[] chars2 = b_list.get(j);
            tmp1 += chars1[1];
            tmp2 += chars2[1];
            chars1[1] = 0;
            chars2[1] = 0;
            char now1 = chars1[0];
            char now2 = chars2[0];

            while (index < tmp1 && index < tmp2) {
                if (now1 != now2) {
                    count += 1;
                }
                index += 1;
            }
            if (index >= tmp1) {
                i += 1;
            }
            if (index >= tmp2) {
                j += 1;
            }
        }

        System.out.println(count + "/" + total);
    }
}
