package csdn.Bo;


import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;


// 统计文本数量
public class Bo134 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str;
        int result = 0;
        Queue<Character> text_info = new LinkedList<>();

        while (in.hasNextLine()) {
            input_str = in.nextLine();
            for (int i = 0; i < input_str.length(); i++) {
                if (input_str.charAt(i) == ';') {
                    if (!text_info.isEmpty() && text_info.peek() != '\\') {
                        result++;
                        text_info.clear();
                    }
                } else if (input_str.charAt(i) != ' ') {
                    if (i != 0 && input_str.charAt(i) == '-' && input_str.charAt(i - 1) == '-' && input_str.charAt(i + 1) != '\'' && input_str.charAt(i + 1) != '"') {
                        text_info.poll();
                        break;
                    }
                    text_info.offer(input_str.charAt(i));
                }
            }
        }
        if (!text_info.isEmpty()) {
            result++;
        }
        System.out.println(result);
    }

}
