package csdn.Bo;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 最少面试官
public class Bo028 {
    public static int count = 0;

    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        int m = Integer.parseInt(in.nextLine());
        int n = Integer.parseInt(in.nextLine());

        Integer[][] matrix = new Integer[n][2];
        for (int i = 0; i < n; i++) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(" ");
            int[] nums = new int[tmp2.length];
            for (int j = 0; j < tmp2.length; j++) {
                nums[j] = Integer.parseInt(tmp2[j]);
            }
            matrix[i][0] = nums[0];
            matrix[i][1] = nums[1];
        }

        Arrays.sort(matrix, new Comparator<Integer[]>() {
            //重写compare方法，最好加注解，不加也没事
            public int compare(Integer[] a, Integer[] b) {
                //返回值>0交换
                return a[1] - b[1];
            }
        });

        ArrayList<ArrayList<Integer>> employers = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            employers.add(new ArrayList<>());
        }

        int i = 0;
        while (true) {
            if (i >= matrix.length) {
                break;
            } else {
                for (ArrayList<Integer> ee : employers) {
                    if (ee.size() < m && (ee.size() == 0 || ee.get(ee.size() - 1) < matrix[i][0])) {
                        ee.add(matrix[i][1]);
                        break;
                    }
                }
            }
            i += 1;
        }

        for (int j = 0; j < n; j++) {
            if (employers.get(j).size() > 0) {
                count += 1;
            }
        }

        System.out.println(count);
    }

}
