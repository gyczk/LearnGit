package csdn.A;

//
public class A088 {

}
