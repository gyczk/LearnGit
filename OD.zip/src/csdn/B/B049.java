package csdn.B;

import java.util.ArrayList;
import java.util.Scanner;

// 	评论转换输出
public class B049 {
    public static int pos = 0;
    public static int level = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String[] input_comments = in.nextLine().split(",|\\s");
        int size = input_comments.length;
        // 评论的树结构
        ArrayList<String> comment_tree = new ArrayList<>();
        comment_tree.add("");
        while (true) {
            if (pos >= size) {
                System.out.println(level + 1);
                for (String single_comment : comment_tree) {
                    System.out.println(single_comment.substring(1));
                }
                break;
            } else {
                comment_tree.set(0, comment_tree.get(0) + ' ' + input_comments[pos++]);
                int next_level_count = Integer.parseInt(input_comments[pos++]);

                for (; next_level_count > 0; next_level_count--) {
                    int[] result = dfs(input_comments, comment_tree, 1);
                    level = Math.max(result[0], level);
                    pos = result[1];
                }
            }
        }
    }

    public static int[] dfs(String[] input_comments, ArrayList<String> comment_tree, int k) {
        if (k >= comment_tree.size()) {
            comment_tree.add("");
        }

        comment_tree.set(k, comment_tree.get(k) + ' ' + input_comments[pos]);
        pos += 1;
        int next_level_count = Integer.parseInt(input_comments[pos]);
        pos += 1;
        int level_temp = k;

        for (; next_level_count > 0; next_level_count--) {
            int[] result = dfs(input_comments, comment_tree, k + 1);
            level_temp = Math.max(result[0], level_temp);
            pos = result[1];
        }
        return new int[]{level_temp, pos};
    }

}
