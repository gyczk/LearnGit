package csdn.Bo;


import java.util.Scanner;


// 转骰子
public class Bo054 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String operations = in.nextLine();

        int[][] dice = {
                {1, 2}, // 左右
                {3, 4}, // 前后
                {5, 6} // 上下
        };
        for (char c : operations.toCharArray()) {
            if (c == 'L' || c == 'R') {
                if (c == 'L') {
                    int x = dice[0][0], y = dice[0][1];
                    dice[0][0] = y;
                    dice[0][1] = x;
                } else if (c == 'R') {
                    int x = dice[2][0], y = dice[2][1];
                    dice[2][0] = y;
                    dice[2][1] = x;
                }
                int[] p = dice[2];
                dice[2] = dice[0];
                dice[0] = p;
            }
            if (c == 'B' || c == 'F') {
                if (c == 'F') {
                    int x = dice[1][0], y = dice[1][1];
                    dice[1][0] = y;
                    dice[1][1] = x;
                } else if (c == 'B') {
                    int x = dice[2][0], y = dice[2][1];
                    dice[2][0] = y;
                    dice[2][1] = x;
                }
                int[] p = dice[1];
                dice[1] = dice[2];
                dice[2] = p;
            }
            if (c == 'A' || c == 'C') {
                if (c == 'A') {
                    int x = dice[1][0], y = dice[1][1];
                    dice[1][0] = y;
                    dice[1][1] = x;
                } else if (c == 'C') {
                    int x = dice[0][0], y = dice[0][1];
                    dice[0][0] = y;
                    dice[0][1] = x;
                }
                int[] p = dice[0];
                dice[0] = dice[1];
                dice[1] = p;
            }
        }

        int m = dice.length, n = dice[0].length;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                sb.append(dice[i][j]);
            }
        }

        System.out.println(sb);
    }
}
