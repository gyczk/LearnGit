package csdn.Bo;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Scanner;


// 污染水域
public class Bo110 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String[] input_str = in.nextLine().split(",");
        int N = (int) Math.sqrt(input_str.length);
        int[][] matrix = new int[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                matrix[i][j] = Integer.parseInt(input_str[j + i * N]);
            }
        }
        //使用QUEUE队列来实现
        Queue<int[]> queue = new ArrayDeque<>();
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (matrix[i][j] == 1) {
                    queue.offer(new int[]{i, j});
                }
            }
        }
        if (queue.size() == 0 || queue.size() == N * N) {
            System.out.println(-1);
            return;
        }

        int[] node = null;
        while (!queue.isEmpty()) {
            node = queue.poll();
            int x = node[0], y = node[1];
            if (x + 1 < N && matrix[x + 1][y] == 0) {
                matrix[x + 1][y] = matrix[x][y] + 1;
                queue.offer(new int[]{x + 1, y});
            }
            if (y + 1 < N && matrix[x][y + 1] == 0) {
                matrix[x][y + 1] = matrix[x][y] + 1;
                queue.offer(new int[]{x, y + 1});
            }
            if (x - 1 >= 0 && matrix[x - 1][y] == 0) {
                matrix[x][y + 1] = matrix[x][y] + 1;
                queue.offer(new int[]{x, y + 1});
            }
            if (y - 1 >= 0 && matrix[x][y - 1] == 0) {
                matrix[x][y - 1] = matrix[x][y] + 1;
                queue.offer(new int[]{x, y - 1});
            }

        }
        System.out.println(matrix[node[0]][node[1]] - 1);
    }
}
