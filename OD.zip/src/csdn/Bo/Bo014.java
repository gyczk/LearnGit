package csdn.Bo;


import java.util.Scanner;

// 篮球比赛
public class Bo014 {
    public static boolean[] is_visited;

    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        String[] num_strs = str.split(" ");
        int[] num = new int[num_strs.length];
        for (int i = 0; i < num_strs.length; i++) {
            num[i] = Integer.parseInt(num_strs[i]);
        }
        int sum = 0;
        is_visited = new boolean[10];

        for (int k : num) {
            sum += k;
        }
        for (int min = 0; min <= sum; min++) {
            int target = (sum - min);
            if (target % 2 == 0) {
                if (dfs(target / 2, num, 0)) {
                    System.out.println(min);
                    break;
                }
            }
        }
    }

    private static boolean dfs(int target, int[] arr, int index) {
        int length = arr.length;
        if (index > 5 || target < 0) {
            return false;
        }

        if (index == 5 && target == 0) {
            return true;
        }
        for (int i = 0; i < length; i++) {
            if (is_visited[i]) {
                continue;
            }
            is_visited[i] = true;
            if (dfs(target - arr[i], arr, index + 1)) {
                return true;
            }
            is_visited[i] = false;
        }
        return false;
    }
}
