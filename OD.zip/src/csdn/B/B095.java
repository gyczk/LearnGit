package csdn.B;


import java.util.HashMap;
import java.util.Scanner;

// 字符串划分
public class B095 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();

        HashMap<Integer, Integer> pre_vals = new HashMap<Integer, Integer>();
        pre_vals.put(0, 0);
        for (int i = 1; i <= input_str.length(); i++) {
            if (!pre_vals.containsKey(i)) {
                pre_vals.put(i, pre_vals.get(i - 1) + (int) input_str.charAt(i - 1));
            } else {
                pre_vals.put(i, 0);
            }
        }

        int left = 1;
        while (true) {
            if (left >= input_str.length()) {
                break;
            } else {
                int sum_left = pre_vals.get(left) - pre_vals.get(0);
                for (int right = left + 2; right < input_str.length(); right++) {
                    int sum_mid = pre_vals.get(right) - pre_vals.get(left + 1);
                    if (sum_left == sum_mid) {
                        int sum_right = pre_vals.get(input_str.length()) - pre_vals.get(right + 1);
                        if (sum_mid == sum_right) {
                            System.out.println(left + "," + right);
                            return;
                        }
                    }
                }
            }
            left += 1;
        }

        System.out.println("0,0");

    }
}
