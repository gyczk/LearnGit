package csdn.Bo;


import java.util.Arrays;
import java.util.Scanner;

// 靠谱的车
public class Bo147 {
   /* public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        int price_after = in.nextInt();
        int ans = price_after;

        // k 表示当前跳过了多少个4
        // j 表示当前位数
        int skip_money = 0, k = 0, j = 1;
        while (price_after > 0) {
            //当前位上出现了4就 +1 (并考虑当前的位数)
            if (price_after % 10 > 4) {
                skip_money += (price_after % 10 - 1) * k + j;
            } else {
                skip_money += (price_after % 10) * k;
            }
            k = k * 9 + j;
            j *= 10;
            price_after /= 10;
        }
        System.out.println(ans - skip_money);
    }*/

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] arr = Arrays.stream(in.nextLine().split("")).mapToInt(Integer::parseInt).toArray();
        System.out.println(getResult(arr));
    }

    private static int getResult(int[] arr) {
        int correct = 0;
        for (int i = 0; i < arr.length; i++) {
            int fault = arr[i];
            if (fault > 4) {
                fault--;
            }
            for (int j = arr.length - 1 - i; j > 0; j--) {
                fault *= 9;
            }
            correct += fault;
        }
        return correct;
    }

}

