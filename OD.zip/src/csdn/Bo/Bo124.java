package csdn.Bo;

import java.util.Scanner;
import java.util.Stack;


// 消消乐游戏 / 字符串消除
public class Bo124 {

    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= 'A') && (c <= 'Z'))) {
                System.out.println(0);
                return;
            }
            if ((!stack.empty()) && (stack.peek() == c)) {
                stack.pop();
                continue;
            }
            stack.push(c);
        }
        System.out.println(stack.size());
    }

}

