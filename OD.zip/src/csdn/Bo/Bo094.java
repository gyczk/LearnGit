package csdn.Bo;


import java.util.Arrays;
import java.util.Scanner;

// 找终点
public class Bo094 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        Integer[] nums = Arrays.stream(in.nextLine().split(" ")).map(Integer::parseInt).toArray(Integer[]::new);
        int len = nums.length;
        int count = 0;
        for (int i = 1; i < len / 2; i++) {
            int index = i;
            int step = 0;
            while (true) {
                if (index >= len) {
                    count = -1;
                    break;
                }
                step++;
                int current = nums[index];
                if (len - 1 == index) {
                    if (count <= 0) {
                        count = step;
                    } else if (count <= step) {

                    } else {
                        count = step;
                    }
                    break;
                }
                index += current;
            }
        }

        System.out.println(count);
    }
}


