package csdn.B;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 跳房子2
public class B037 {

    public static int min_sum = Integer.MAX_VALUE;

    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        //处理输入
        int target = Integer.parseInt(in.nextLine());
        String[] tmp2 = in.nextLine().replace("[", "").replace("]", "").split(",");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        int[][] multi_nums = new int[nums.length][2];
        for (int i = 0; i < nums.length; i++) {
            multi_nums[i] = new int[]{nums[i], i};
        }
        MyComparator037 myComparator = new MyComparator037();
        Arrays.sort(multi_nums, myComparator);

        ArrayList<Integer> result = new ArrayList<>();
        int i = 0;
        while (i < nums.length && multi_nums[i][0] <= target) {
            int l = i + 1;
            int r = nums.length - 1;
            while (true) {
                if (l >= r) {
                    break;
                } else {
                    int sum1 = multi_nums[i][0] + multi_nums[l][0] + multi_nums[r][0];
                    int sum2 = multi_nums[i][1] + multi_nums[l][1] + multi_nums[r][1];
                    if (sum1 == target) {
                        if (sum2 < min_sum) {
                            min_sum = sum2;
                            result = new ArrayList<>();
                            get_result(multi_nums[i], multi_nums[l], multi_nums[r], result);
                        }
                        if (multi_nums[l][0] == multi_nums[l + 1][0]) {
                            do {
                                l++;
                            } while (l + 1 < r);
                        }
                        l++;
                        r--;
                    } else if (sum1 < target) {
                        l++;
                    } else {
                        r--;
                    }
                }
            }
            i += 1;
        }


        System.out.print("[");
        for (int x = 0; x < result.size(); x++) {
            System.out.print(result.get(x));
            if (x != result.size() - 1) {
                System.out.print(",");
            }
        }
        System.out.print("]");
    }

    public static void get_result(int[] a, int[] b, int[] c, ArrayList<Integer> result) {
        int[][] arr = {a, b, c};
        Arrays.sort(arr, (x, y) -> x[1] - y[1]);
        for (int[] step : arr) {
            result.add(step[0]);
        }
    }
}

class MyComparator037 implements Comparator<int[]> {
    @Override
    public int compare(int[] o1, int[] o2) {
        if (o1[0] == o2[0]) {
            return o1[1] - o2[1];
        }
        return o1[0] - o2[0];
    }
}
