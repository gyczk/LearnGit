package csdn.Bo;


import java.util.LinkedList;
import java.util.Scanner;

// 表达式括号匹配
public class Bo115 {
    public static int count = 0;

    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        LinkedList<Character> stack = new LinkedList<>();
        int i = 0;
        while (true) {
            if (i >= input_str.length()) {
                break;
            } else {
                if (input_str.charAt(i) != ')' && input_str.charAt(i) != '(') {
                    i += 1;
                    continue;
                } else {
                    if (stack.size() > 0 && input_str.charAt(i) == ')') {
                        if (stack.getLast() == '(') {
                            stack.removeLast();
                            count += 1;
                            i += 1;
                            continue;
                        }
                        System.out.println(-1);
                        return;
                    }
                    stack.add(input_str.charAt(i));
                }
            }
            i += 1;
        }

        System.out.println(stack.size() > 0 ? -1 : count);

    }
}
