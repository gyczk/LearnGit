package csdn.B;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

// 数字最低位排序
public class B088 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String[] nums = in.nextLine().split(",");
        List<Integer> list = new ArrayList<>();
        for (String num : nums) {
            list.add(Integer.parseInt(num));
        }
        list.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return getKey(o1) - getKey(o2);
            }

            public Integer getKey(int i) {
                i = i > 0 ? i : -i;
                return i % 10;
            }
        });

        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i));
            if (i != list.size() - 1) {
                System.out.print(",");
            }
        }
    }

}
