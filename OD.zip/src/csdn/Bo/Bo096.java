package csdn.Bo;


import java.util.*;

// We Are A Team
public class Bo096 {

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        int num = nums[0];
        int mes = nums[1];

        List<Set<Integer>> lists = new ArrayList<>();
        List<String> waitForVerify = new ArrayList<>();
        for (int i = 0; i < mes; i++) {

            String real = in.nextLine();
            String[] rels = real.split(" ");
            int i1 = Integer.parseInt(rels[0]);
            int i2 = Integer.parseInt(rels[1]);
            int i3 = Integer.parseInt(rels[2]);
            if (i3 != 0) {
                waitForVerify.add(real);
            } else {

                boolean flag = false;
                for (int j = 0; j < lists.size(); j++) {

                    Set<Integer> set = lists.get(j);
                    if (set.contains(i1) || set.contains(i2)) {

                        set.add(i1);
                        set.add(i2);
                        flag = true;
                        break;
                    }
                }
                if (!flag) {

                    Set<Integer> set = new HashSet<>();
                    set.add(i1);
                    set.add(i2);
                    lists.add(set);
                }
            }
        }
        //判断非0的关系
        for (int i = 0; i < waitForVerify.size(); i++) {

            String[] reli = waitForVerify.get(i).split(" ");
            int i1 = Integer.parseInt(reli[0]);
            int i2 = Integer.parseInt(reli[1]);
            int i3 = Integer.parseInt(reli[2]);
            if (i3 != 1) {

                System.out.println("da pian zi");
                continue;
            }
            boolean flag = false;
            for (int j = 0; j < lists.size(); j++) {
                Set<Integer> set = lists.get(j);
                if (set.contains(i1) && set.contains(i2)) {
                    System.out.println("we are a team");
                    flag = true;
                    break;
                }

            }
            if (!flag) {
                System.out.println("we are not a team");
            }
        }

    }
}

