package com.geely.design.principle.interfacesegregation;

/**
 * Created by geely
 */
public interface IFlyAnimalAction {
    void fly();
}
