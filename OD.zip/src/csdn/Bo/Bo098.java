package csdn.Bo;


import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 流水线调度
public class Bo098 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        int m = nums[0];
        int n = nums[1];

        String input_str1 = in.nextLine();
        String[] tmp21 = input_str1.split(" ");
        Integer[] times = new Integer[tmp21.length];
        for (int i = 0; i < tmp21.length; i++) {
            times[i] = Integer.parseInt(tmp21[i]);
        }

        Arrays.sort(times, new Comparator<Integer>() {
            @Override
            //在这里主要是重写了 Comparator类的compare方法，
            //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
            public int compare(Integer o1, Integer o2) {
                return o1 - o2;
            }
        });


        int[] temp = new int[m];
        for (int i = 0; i < n; i++) {
            temp[i % m] += times[i];
        }
        System.out.println(Arrays.stream(temp).max().getAsInt());
    }
}
