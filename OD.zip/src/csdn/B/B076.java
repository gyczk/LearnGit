package csdn.B;


import java.util.Arrays;
import java.util.Scanner;


// 	执行时长/GPU算力
public class B076 {
    public static int count = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int threshold = Integer.parseInt(in.nextLine());
        int n = Integer.parseInt(in.nextLine());
        int[] tasks = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        int flag = 0;

        //直接计算，无需多虑
        int i = 0;
        while (i < tasks.length) {
            if (threshold >= tasks[i] + flag) {
                flag = 0;
            } else {
                flag += tasks[i] - threshold;
            }
            count += 1;
            i += 1;
        }
        System.out.println(count += (flag / threshold));
    }
}
