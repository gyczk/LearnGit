package csdn.Bo;


import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

// 最长的指定瑕疵度的元音子串
public class Bo051 {
    public static HashSet<Character> vowels = new HashSet<>(
            Arrays.asList('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'));

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int flaw = Integer.parseInt(in.nextLine());
        String input = in.nextLine();
        int left = 0;
        int right = -1;
        int currentFlaw = 0;
        int result = 0;

        while (right < input.length() - 1) {
            right += 1;
            if (!vowels.contains(input.charAt(right))) {
                currentFlaw += 1;
            }

            while (currentFlaw > flaw) {
                if (!vowels.contains(input.charAt(left))) {
                    currentFlaw -= 1;
                }
                // 这步会提前到达下一个点，可能会超范围
                left += 1;
            }

            if (left < input.length() && currentFlaw == flaw && vowels.contains(input.charAt(left)) && vowels.contains(
                    input.charAt(right))) {
                result = Math.max(result, right + 1 - left);
            }
        }

        System.out.print(result);
    }

}
