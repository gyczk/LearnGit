package csdn.B;


import java.util.Scanner;


// 	最大岛屿体积
public class B097 {
    public static int area = 0;

    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        int row = in.nextInt();
        int col = in.nextInt();
        int[][] matrix = new int[row][col];
        int max = Integer.MIN_VALUE;
        //初始化岛屿
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                matrix[i][j] = in.nextInt();
            }
        }
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (matrix[i][j] > 0) {
                    area = 0;
                    //求当前点所属岛屿的大小
                    dfs(matrix, i, j);
                    max = Math.max(area, max);
                }
            }
        }
        System.out.println(max);

    }

    public static void dfs(int[][] matrix, int i, int j) {
        int row = matrix.length, col = matrix[0].length;
        if (i < 0 || i >= row || j < 0 || j >= col || matrix[i][j] == 0) {
            return;
        }
        area += matrix[i][j];
        matrix[i][j] = 0;
        //上下左右判断是否为1
        dfs(matrix, i - 1, j);
        dfs(matrix, i + 1, j);
        dfs(matrix, i, j - 1);
        dfs(matrix, i, j + 1);
    }
}
