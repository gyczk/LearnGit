package csdn.A;

//
public class A123 {

}
