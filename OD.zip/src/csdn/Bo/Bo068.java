package csdn.Bo;


import java.util.LinkedList;
import java.util.Scanner;


// 找单词
public class Bo068 {
    public static LinkedList<Integer[]> path;

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in).useDelimiter("[,\n]");
        int n = Integer.parseInt(in.nextLine());
        String[][] matrix = new String[n][n];
        for (int i = 0; i < n; i++) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(",");
            System.arraycopy(tmp2, 0, matrix[i], 0, n);
        }
        String target = in.nextLine();
        path = new LinkedList<>();
        int i = 0;
        boolean flag1 = false;
        while (i < n) {
            int j = 0;
            boolean flag2 = false;
            while (j < n) {
                if (dfs(i, j, 0, path, n, matrix, target)) {
                    flag2 = true;
                    break;

                }
                path = new LinkedList<>();
                j += 1;
            }
            if (flag2) {
                flag1 = true;
                break;
            }
            i += 1;
        }

        if (flag1) {
            String output_str = "";
            for (Integer[] pos : path) {
                output_str += pos[0] + "," + pos[1] + ",";
            }
            System.out.println(output_str.substring(0, output_str.length() - 1));
        } else {
            System.out.println("NO");
        }

    }

    public static boolean dfs(int i, int j, int k, LinkedList<Integer[]> path, int n, String[][] matrix, String target) {
        path.add(new Integer[]{i, j});
        if (path.size() == target.length()) {
            return true;
        } else {
            if (i < 0 || i >= n || j < 0 || j >= n || !target.substring(k, k + 1).equals(matrix[i][j])) {
                path.removeLast();
                return false;
            }
        }
        String tmp = matrix[i][j];
        matrix[i][j] = null;

        boolean flag = false;
        if (i - 1 >= 0) {
            flag = flag || dfs(i - 1, j, k + 1, path, n, matrix, target);
        }
        if (i + 1 < n) {
            flag = flag || dfs(i + 1, j, k + 1, path, n, matrix, target);
        }
        if (j - 1 >= 0) {
            flag = flag || dfs(i, j - 1, k + 1, path, n, matrix, target);
        }
        if (j + 1 < n) {
            flag = flag || dfs(i, j + 1, k + 1, path, n, matrix, target);
        }
        if (!flag) {
            matrix[i][j] = tmp;
            path.removeLast();
        }
        return flag;
    }
}
