package csdn.B;

import java.util.*;


// 人气最高的店铺
public class B041 {


    public static int money;
    public static int result = Integer.MAX_VALUE;

    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        int[] params = Arrays.stream(in.nextLine().split(",")).mapToInt(Integer::parseInt).toArray();
        int n = params[0];
        int m = params[1];
        // 初始化商店和投票人
        List<int[]> peoples = new ArrayList<>();
        Map<Integer, Integer> shop_info = new HashMap<>();
        shop_info.put(1, 0);
        for (int i = 0; i < n; i++) {
            int[] nums = Arrays.stream(in.nextLine().split(",")).mapToInt(Integer::parseInt).toArray();
            if (nums[0] != 1) {
                peoples.add(new int[]{nums[0], nums[1]});
            }
            shop_info.put(nums[0], shop_info.getOrDefault(nums[0], 0) + 1);
        }

        backfill(peoples, new ArrayList<>(), 0, shop_info);
        System.out.println(result);

    }

    public static void backfill(List<int[]> peoples, List<int[]> change_peoples, int index, Map<Integer, Integer> shop_info) {
        // 判断此时一号店铺是否是第一名,且所需要的钱最少
        if (check(change_peoples, shop_info) && result > money) {
            result = money;
        } else {
            // 组合求解
            for (int i = index; i < peoples.size(); i++) {
                change_peoples.add(peoples.get(i));
                backfill(peoples, change_peoples, i + 1, shop_info);
                change_peoples.remove(change_peoples.size() - 1);
            }

        }

    }

    public static boolean check(List<int[]> change_peoples, Map<Integer, Integer> shop_info) {
        Map<Integer, Integer> new_shop_info = new HashMap<>(shop_info);
        money = 0;
        for (int[] ints : change_peoples) {
            int shop_id = ints[0];
            money += ints[1];
            // 人气调换
            new_shop_info.put(shop_id, new_shop_info.get(shop_id) - 1);
            new_shop_info.put(1, new_shop_info.get(1) + 1);
        }

        List<Map.Entry<Integer, Integer>> shop_list = new ArrayList<>(new_shop_info.entrySet());
        // 降序排序
        shop_list.sort((a, b) -> b.getValue() - a.getValue());

        // 人气第一的店铺
        int top1_shop_id = shop_list.get(0).getKey();
        return top1_shop_id == 1 && (shop_list.size() == 1 || shop_list.get(0).getValue() > shop_list.get(1).getValue());
    }
}
