package csdn.Bo;


import java.util.Scanner;

// 字符串比较
public class Bo073 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String A = in.nextLine();
        String B = in.nextLine();
        String V = in.nextLine();

        char[] arr_a = A.toCharArray();
        char[] arr_b = B.toCharArray();
        int v = Integer.parseInt(V);

        int left = 0;
        int result = 0;
        int ascii_distance = 0;
        for (int i = 0; i < arr_a.length - 1; i++) {
            int right = 0;
            if (arr_a[i + 1] == arr_a[i] + 1) {
                right = i + 1;
            } else {
                left = i + 1;
                continue;
            }

            for (int j = left; j <= right - 1; j++) {
                if (arr_b[j + 1] != arr_b[j] + 1) {
                    ascii_distance = 0;
                    break;
                }

                if (j == left) {
                    ascii_distance += Math.abs(arr_a[j] - arr_b[j]);
                }
                ascii_distance += Math.abs(arr_a[j + 1] - arr_b[j + 1]);
            }

            int temp_length = right - left + 1;
            if (ascii_distance <= v && temp_length > result) {
                result = temp_length;
                ascii_distance = 0;
            }
        }

        System.out.println(result);
    }
}


