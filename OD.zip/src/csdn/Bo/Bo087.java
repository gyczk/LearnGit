package csdn.Bo;


import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 观看文艺汇演问题 / 计算最多能看几场演出
public class Bo087 {
    public static int count = 1;

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());

        Integer[][] matrix = new Integer[n][2];
        for (int i = 0; i < n; i++) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(" ");
            int[] nums = new int[tmp2.length];
            for (int j = 0; j < tmp2.length; j++) {
                nums[j] = Integer.parseInt(tmp2[j]);
            }
            matrix[i][0] = nums[0];
            matrix[i][1] = matrix[i][0] + nums[1];
        }

        Arrays.sort(matrix, new Comparator<Integer[]>() {
            //重写compare方法，最好加注解，不加也没事
            public int compare(Integer[] a, Integer[] b) {
                return a[1] - b[1];
            }
        });

        int t = matrix[0][1];
        int i = 0;

        while (true) {
            if (i >= n) {
                break;
            } else {
                if (matrix[i][0] - t >= 15) {
                    count += 1;
                    t = matrix[i][1];
                }
            }
            i += 1;
        }

        System.out.println(count);
    }
}


