package csdn.Bo;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

// 服务失效判断
public class Bo030 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] split = scanner.nextLine().split(",");
        List<String> list = new ArrayList<>();
        String[] brokes = scanner.nextLine().split(",");
        List<String[]> serverList = new ArrayList<>();
        for (String s : split) {
            String[] split1 = s.split("-");
            serverList.add(split1);
            list.add(split1[0]);
            list.add(split1[1]);
        }
        List<String> brokeList = new ArrayList<>();

        LinkedList<String> queue = new LinkedList<>();
        for (String s : brokes) {
            queue.offer(s);
            brokeList.add(s);
        }
        while (!queue.isEmpty()) {
            String broke = queue.pop();
            for (String[] strings : serverList) {
                if (strings[1].equals(broke)) {
                    queue.offer(strings[0]);
                    brokeList.add(strings[0]);
                }


            }
        }
        list.removeAll(brokeList);
        StringBuilder stringBuilder = new StringBuilder();
        for (String s : list) {
            stringBuilder.append(s);
            stringBuilder.append(",");
        }
        System.out.println(stringBuilder.substring(0, stringBuilder.length() - 1));
    }
}
