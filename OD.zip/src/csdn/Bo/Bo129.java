package csdn.Bo;


import java.util.*;
import java.util.stream.Collectors;

// 查找中位数及众数
public class Bo129 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        //转为数组
        List<Integer> nums = Arrays.stream(in.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        //  统计次数及出现最大次数
        Map<Integer, Integer> map = new HashMap<>();
        for (int num : nums) {
            if (map.containsKey(num)) {
                map.put(num, map.get(num) + 1);
            } else {
                map.put(num, 1);
            }
        }
        int max = 0;
        for (int count : map.values()) {
            if (count >= max) {
                max = count;
            }
        }

        // 排序
        List<Integer> num_list = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            if (entry.getValue() == max) {
                num_list.add(entry.getKey());
            }
        }
        Collections.sort(num_list);

        if (num_list.size() % 2 != 0) {
            int result = (num_list.size() + 1) / 2 - 1;
            System.out.println(num_list.get(result));
        } else {
            System.out.println((num_list.get(num_list.size() / 2) + num_list.get(num_list.size() / 2 - 1)) / 2);
        }
    }
}

