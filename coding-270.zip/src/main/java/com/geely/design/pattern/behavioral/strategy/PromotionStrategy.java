package com.geely.design.pattern.behavioral.strategy;

/**
 * Created by geely
 */
public interface PromotionStrategy {
    void doPromotion();
}
