package csdn.Bo;


import java.util.Scanner;

// 最大股票收益
public class Bo010 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] moneys = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            int real_money = 0;
            real_money += Integer.parseInt(tmp2[i].substring(0, 1));

            if (tmp2[i].charAt(1) == 'S')
                real_money = real_money * 7;
            moneys[i] = real_money;
        }
        int i = 1;
        int revenue = 0;
        while (true) {
            if (i >= tmp2.length) {
                System.out.println(revenue);
                break;
            } else {
                if (moneys[i] > moneys[i - 1])
                    revenue += moneys[i] - moneys[i - 1];
            }
            i += 1;
        }
    }
}
