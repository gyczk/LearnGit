package com.geely.design.principle.demeter;

/**
 * Created by geely
 */
public class Course {
}
