package csdn.Bo;

import java.util.ArrayList;
import java.util.Scanner;

// 欢乐的周末
public class Bo083 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] params = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            params[i] = Integer.parseInt(tmp2[i]);
        }
        int m = params[0];
        int n = params[1];
        int[][] matrix = new int[n][m];
        for (int i = 0; i < n; i++) {
            String input_str1 = in.nextLine();
            String[] tmp1 = input_str1.split(" ");
            int[] params1 = new int[tmp1.length];
            for (int k = 0; k < tmp1.length; k++) {
                params1[k] = Integer.parseInt(tmp1[k]);
            }
            System.arraycopy(params1, 0, matrix[i], 0, m);
        }
        UF083 uf = new UF083(n * m);
        ArrayList<Integer> positions = new ArrayList<>();
        ArrayList<Integer> diner = new ArrayList<>();

        int i = 0;
        while (true) {
            if (i >= n) {
                break;
            } else {
                int j = 0;
                while (true) {
                    if (j >= m) {
                        break;
                    } else {
                        if (matrix[i][j] == 1) {
                            j += 1;
                            continue;
                        } else {
                            int x = i * m + j;
                            if (matrix[i][j] == 2) {
                                positions.add(i * m + j);
                            } else if (matrix[i][j] == 3) {
                                diner.add(i * m + j);
                            }

                            if (i + 1 < m) {
                                if (matrix[i + 1][j] != 1) {
                                    uf.union_connect(i * m + j, (i + 1) * m + j);
                                }
                            }
                            if (i - 1 >= 0)
                                if (matrix[i - 1][j] != 1)
                                    uf.union_connect(i * m + j, (i - 1) * m + j);
                            if (j + 1 < n)
                                if (matrix[i][j + 1] != 1)
                                    uf.union_connect(i * m + j, (i) * m + j + 1);
                            if (j - 1 >= 0)
                                if (matrix[i][j - 1] != 1)
                                    uf.union_connect(i * m + j, (i) * m + j - 1);

                        }
                    }
                    j += 1;
                }
            }
            i += 1;
        }

        int target1 = uf.find(positions.get(0));
        int target2 = uf.find(positions.get(1));
        int result = 0;
        if (target1 == target1) {
            int x = 0;
            while (true) {
                if (x >= diner.size()) {
                    break;
                } else {
                    if (uf.find(diner.get(x)) == uf.find(positions.get(0))) {
                        result += 1;
                    }
                }
                x += 1;
            }
        }
        System.out.println(result);
    }
}

// 并查集模板
class UF083 {
    int[] item;
    int result;

    public UF083(int n) {
        item = new int[n + 1];
        result = n;
        for (int i = 0; i < n; i++) item[i] = i;
    }

    public int find(int x) {
        if (x != item[x]) {
            return (item[x] = find(item[x]));
        }
        return x;
    }

    public void union_connect(int x, int y) {
        int x_item = find(x);
        int y_item = find(y);

        if (x_item != y_item) {
            item[y_item] = x_item;
            result--;
        }
    }
}


