package csdn.Bo;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;

// 数字字符串组合倒序
public class Bo101 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String reg1 = "[^0-9a-zA-Z\\-]";
        Pattern reg2 = Pattern.compile("-");
        Pattern reg3 = Pattern.compile("(?<=\\w)-(?=\\w)");

        ArrayList<String> split_strs = new ArrayList<>();

        Arrays.stream(input_str.split(reg1)).filter(s -> !"".equals(s)).forEach(c -> {
            if (!reg2.matcher(c).find() || reg3.matcher(c).find()) {
                split_strs.add(c);
            } else {
                Arrays.stream(c.split("-")).filter(s -> !"".equals(s)).forEach(s -> split_strs.add(s));
            }
        });

        String result = "";
        for (int i = split_strs.size() - 1; i >= 0; i--) {
            result += split_strs.get(i);
            if (i != 0) {
                result += " ";
            }
        }

        System.out.println(result);
    }
}



