package csdn.Bo;


import java.util.Scanner;


// 求满足条件的最长子串的长度
public class Bo082 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        //初始窗口左右边界
        int left = 0;
        int right = 1;
        int result = -1;
        while (left < input_str.length() && right < input_str.length()) {
            right++;
            String subStr = input_str.substring(left, right);
            if (check(subStr)) {
                result = Math.max(result, subStr.length());
            } else {
                left++;
            }
        }
        System.out.println(result);
    }

    public static boolean check(String str) {
        String replace = str.replaceAll("[0-9]", "");
        return replace.length() != str.length() && replace.length() <= 1;
    }
}
