package csdn.Bo;


import java.util.*;

// 斗地主之顺子
public class Bo077 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String line = in.nextLine();
        String[] cardsArr = line.split(" ");
        Map<String, Integer> cards = new HashMap<>();
        cards.put("3", 3);
        cards.put("4", 4);
        cards.put("5", 5);
        cards.put("6", 6);
        cards.put("7", 7);
        cards.put("8", 8);
        cards.put("9", 9);
        cards.put("10", 10);
        cards.put("J", 11);
        cards.put("Q", 12);
        cards.put("K", 13);
        cards.put("A", 14);
        cards.put("2", 16);

        Arrays.sort(cardsArr, (a, b) -> cards.get(a) - cards.get(b));

        List<String> stack = new ArrayList<>();
        List<String> res = new ArrayList<>();

        for (String card : cardsArr) {
            if (stack.size() == 0) {
                stack.add(card);
            } else {
                String top = stack.get(stack.size() - 1);
                if (cards.get(card) - cards.get(top) == 1) {
                    stack.add(card);
                } else if (cards.get(card).equals(cards.get(top))) {
                    List<String> temp = new ArrayList<>(Arrays.asList(cardsArr));
                    temp.add(card);
                    cardsArr = temp.toArray(new String[0]);
                } else {
                    List<String> temp = new ArrayList<>(Arrays.asList(cardsArr));
                    temp.add(0, card);
                    cardsArr = temp.toArray(new String[0]);
                    if (stack.size() >= 5) {
                        if (stack.size() < 10) {
                            res.add(String.join(" ", stack));
                        } else {
                            res.add(String.join(" ", stack.subList(0, 5)));
                            res.add(String.join(" ", stack.subList(5, stack.size())));
                        }
                    }
                    stack.clear();
                }
            }
        }

        if (stack.size() >= 5) {
            res.add(String.join(" ", stack));
        }

        if (res.size() == 0) {
            System.out.println("No");
        } else {
            for (String str : res) {
                System.out.println(str);
            }
        }
    }

}
