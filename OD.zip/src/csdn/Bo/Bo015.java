package csdn.Bo;


import java.util.Scanner;

// 勾股数元组
public class Bo015 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();

        int count = 0;
        for (int a = n; a < m - 1; a++) {
            for (int b = a + 1; b < m; b++) {
                for (int c = b + 1; c < m + 1; c++) {
                    if (check(a, b) &&
                            check(b, c) &&
                            check(a, c) &&
                            a * a + b * b == c * c) {
                        count++;
                        System.out.printf("%d %d %d\n", a, b, c);
                    }
                }
            }
        }
        if (count == 0) {
            System.out.println("Na");
        }
    }

    public static boolean check(int x, int y) {
        if (x == y && y == 1) {
            return false;
        }
        int min = Math.min(x, y);
        for (int i = 2; i <= min; i++) {
            if (x % i == 0 && y % i == 0) {
                return false;
            }
        }
        return true;
    }


}
