package csdn.B;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;


// 拔河比赛
public class B048 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<Integer[]> players = new ArrayList<>();
        while (in.hasNextLine()) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(" ");
            int[] nums = new int[tmp2.length];
            for (int i = 0; i < tmp2.length; i++) {
                nums[i] = Integer.parseInt(tmp2[i]);
            }
            if ("".equals(input_str)) {
                break;
            } else {
                players.add(new Integer[]{nums[0], nums[1]});
            }
        }
        MyComparator048 myComparator = new MyComparator048();
        Collections.sort(players, myComparator);
        for (int i = 0; i < 10; i++) {
            System.out.println(players.get(i)[0] + " " + players.get(i)[1]);
        }
    }
}

class MyComparator048 implements Comparator<Integer[]> {
    @Override
    public int compare(Integer[] o1, Integer[] o2) {
        if (o1[0] == o2[0]) {
            return o1[1] - o2[1];
        }
        return -o1[0] + o2[0];
    }
}
