package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

// 最佳植树距离
public class B003 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

        int[] position = new int[n];
        for (int i = 0; i < n; i++) {
            position[i] = in.nextInt();
        }

        int m = in.nextInt();

        //参考链接：https://leetcode.cn/problems/magnetic-force-between-two-balls/solution/java-er-fen-zui-xiao-zhi-zui-da-by-deena/
        Arrays.sort(position);
        int len = position.length;
        int l = 1;
        int r = (position[len-1] - position[0]) / (m - 1);
        while(l < r){
            int mid = l + (r - l + 1) / 2;//mid代表当前最小磁力
            int cnt = 1;//符合相邻两个点之间的距离>=mid的个数
            int last = position[0];//选了第一个点
            for(int i = 1; i < n; i++){
                if(position[i] - last >= mid){
                    last = position[i];
                    cnt++;
                }
            }
            if(cnt >= m){
                //mid是符合的，mid也可以更大，最优解在右半区间
                l = mid;
            }else{
                r = mid - 1;
            }
        }
        System.out.println(l);
    }


}
