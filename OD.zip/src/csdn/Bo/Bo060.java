package csdn.Bo;


import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


// 简易内存池
public class Bo060 {
    public static void main(String[] args) {
        AllocatedMemory allocatedMemory = new AllocatedMemory();
        Scanner in = new Scanner(System.in, StandardCharsets.UTF_8.name());
        int line = Integer.parseInt(in.nextLine());
        String[][] ins = new String[line][2];
        for (int i = 0; i < line; i++) {
            ins[i] = in.nextLine().split("=");
            if (ins[i][0].startsWith("REQUEST")) {
                System.out.println(allocatedMemory.request(Integer.parseInt(ins[i][1])));
            } else {
                boolean ret = allocatedMemory.release(Integer.parseInt(ins[i][1]));
                if (!ret) {
                    System.out.println("error");
                }
            }
        }
    }

    static class AllocatedMemory {
        private final List<Integer[]> free;
        private final List<Integer[]> busy;

        AllocatedMemory() {
            free = new ArrayList<>();
            busy = new ArrayList<>();
            Integer[] info = new Integer[2];
            info[0] = 0;
            info[1] = 100;
            free.add(info);
        }

        // 返回分配的内存首地址(string)，失败返回字符串 "error"
        String request(int size) {
            if (size <= 0) return "error";
            int removeIndex = -1;
            for (int i = 0; i < free.size(); i++) {
                Integer[] info = free.get(i);
                if (info[1] - info[0] >= size) {
                    removeIndex = i;
                    break;
                }
            }
            if (removeIndex != -1) {
                Integer[] info = free.get(removeIndex);
                Integer[] res = new Integer[2];
                res[0] = info[0];
                res[1] = info[0] + size;
                if (info[1] - info[0] - size > 0) {
                    free.get(removeIndex)[0] = info[0] + size;
                } else {
                    free.remove(removeIndex);
                }
                busy.add(res);
                return res[0].toString();
            }
            return "error";
        }

        void changeFree(int start, int end) {
            int index;
            for (index = 0; index < free.size(); index++) {
                Integer[] info = free.get(index);
                if (info[0] > start) break;
            }
            Integer[] info = new Integer[2];
            info[0] = start;
            info[1] = end;
            free.add(index, info);

            // 整理碎片
            boolean change = true;
            while (change) {
                change = false;
                int i;
                for (i = 1; i < free.size(); i++) {
                    if (free.get(i)[0] == free.get(i - 1)[1]) {
                        change = true;
                        break;
                    }
                }
                if (change) {
                    free.get(i)[0] = free.get(i - 1)[0];
                    free.remove(i - 1);
                }
            }
        }

        // 成功返回 true；失败返回 false，失败时框架会自动输出 "error"
        boolean release(int startAddress) {
            int removeIndex = -1;
            for (int i = 0; i < busy.size(); i++) {
                Integer[] info = busy.get(i);
                if (info[0] == startAddress) {
                    removeIndex = i;
                    break;
                }
            }
            if (removeIndex != -1) {
                Integer[] info = busy.get(removeIndex);
                changeFree(info[0], info[1]);
                busy.remove(removeIndex);
                return true;
            }
            // 在此补充你的代码
            return false;
        }
    }
}
