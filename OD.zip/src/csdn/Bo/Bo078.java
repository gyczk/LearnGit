package csdn.Bo;


import java.util.LinkedList;
import java.util.Scanner;


// 计算疫情扩散时间
public class Bo078 {
    //扩散方向
    public static int[][] directions = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String[] split = in.nextLine().split(",");
        int n = (int) Math.sqrt(split.length);

        int[][] matrix = new int[n][n];
        int k = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = Integer.parseInt(split[k]);
                k++;
            }
        }
        int result = 0;

        while (check(matrix)) {
            // 找到所有感染位点
            LinkedList<int[]> virus = new LinkedList<>();
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    int x = matrix[i][j];
                    if (x == 1) {
                        int[] pos = {i, j};
                        virus.add(pos);
                    }
                }
            }

            // 感染
            for (int[] pos : virus) {
                for (int[] p : directions) {
                    int x1 = pos[0] + p[0];
                    x1 = Math.min(n - 1, Math.max(x1, 0));
                    int y1 = pos[1] + p[1];
                    y1 = Math.min(n - 1, Math.max(y1, 0));
                    matrix[x1][y1] = 1;
                }
            }

            result++;
        }

        result = result == 0 ? -1 : result;
        System.out.println(result);
    }

    private static boolean check(int[][] matrix) {
        int sum = 0;
        int n = matrix.length;
        for (int[] arr : matrix) {
            for (int j = 0; j < n; j++) {
                sum += arr[j];
            }
        }
        return sum != 0 && sum != n * n;
    }


}
