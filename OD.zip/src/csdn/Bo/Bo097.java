package csdn.Bo;


import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

// 免单统计
public class Bo097 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());

        String[] matrix = new String[n];
        for (int i = 0; i < n; i++) {
            matrix[i] = in.nextLine();
        }
        Arrays.sort(matrix, new Comparator<String>() {
            @Override
            //在这里主要是重写了 Comparator类的compare方法，
            //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        });

        LinkedList<String> result = new LinkedList<>();
        int count = 1;
        result.add(matrix[0]);
        int i = 1;
        while (true) {
            if (i >= matrix.length) {
                break;
            } else {
                if (result.getLast().equals(matrix[i])) {
                    result.add(matrix[i]);
                    count += 1;
                } else if (!result.getLast().substring(0, 19).equals(matrix[i].substring(0, 19))) {
                    result.add(matrix[i]);
                    count += 1;
                }
            }
            i += 1;
        }

        System.out.println(count);
    }
}

