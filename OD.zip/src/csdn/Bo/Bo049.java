package csdn.Bo;


import java.util.Arrays;
import java.util.Scanner;


// 导师请吃火锅
public class Bo049 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int[] x = new int[n];
        int[] y = new int[n];
        for (int i = 0; i < n; i++) {
            x[i] = in.nextInt();
            y[i] = in.nextInt();
        }

        int[] dishs = new int[n];
        for (int i = 0; i < n; i++) {
            dishs[i] = x[i] + y[i];
        }
        Arrays.sort(dishs);

        int[] res_arr = new int[n];

        int next = 0;
        res_arr[0] = 1;
        for (int i = 1; i < n; i++) {
            if (dishs[i] >= (dishs[next] + m)) {
                res_arr[i] = 1;
                next = i;
            }
        }

        int count = 0;
        for (int i = 0; i < n; i++) {
            if (res_arr[i] > 0) {
                count++;
            }
        }
        System.out.println(count);


    }
}
