package csdn.B;


import java.util.Arrays;
import java.util.Scanner;


// 猴子吃桃
public class B104 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String[] params = in.nextLine().split(" ");
        int[] nums = new int[params.length - 1];
        for (int i = 0; i < params.length - 1; i++) {
            nums[i] = Integer.parseInt(params[i]);
        }
        int leave_time = Integer.parseInt(params[params.length - 1]);
        Arrays.sort(nums);
        int left = 1, right = nums[nums.length - 1];

        //二分处理
        while (left < right) {
            int mid = (right - left) / 2 + left;
            int time = 0;
            for (int num : nums) {
                time += (num + mid - 1) / mid;
            }
            if (time <= leave_time) {
                right = mid;
            } else {
                left = mid + 1;
            }
        }
        System.out.println(left);
    }
}

