package csdn.Bo;


import java.util.Scanner;

// 符合要求的结对方式
public class Bo040 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[] v = new int[n];
        for (int i = 0; i < n; i++) {
            v[i] = in.nextInt();
        }
        int sum_value = in.nextInt();
        int res = 0;

        for (int i = 0; i < v.length; i++) {
            for (int j = i + 1; j < v.length; j++) {
                if (v[i] + v[j] == sum_value) {
                    res += 1;
                }
            }
        }

        System.out.println(res);
    }
}


