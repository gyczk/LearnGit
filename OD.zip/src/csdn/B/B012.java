package csdn.B;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

//	模拟消息队列
public class B012 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }

        String input_str1 = in.nextLine();
        String[] tmp1 = input_str1.split(" ");
        int[] nums1 = new int[tmp1.length];
        for (int i = 0; i < tmp1.length; i++) {
            nums1[i] = Integer.parseInt(tmp1[i]);
        }

        int n = nums.length;
        int m = nums1.length;

        // 发布信息
        Message[] producer_map = new Message[n / 2];
        int index = 0;
        for (int i = 0; i < n; i += 2) {
            producer_map[index++] = new Message(nums[i], nums[i + 1]);
        }
        Arrays.sort(producer_map, new Comparator<Message>() {
            @Override
            public int compare(Message o1, Message o2) {
                return o1.a - o2.a;
            }
        });

        // 消费信息
        Message[] consumer_map = new Message[m / 2];
        int index1 = 0;
        for (int j = 0; j < m; j += 2) {
            consumer_map[index1++] = new Message(nums1[j], nums1[j + 1]);
        }

        // 构造消费关系
        ArrayList<ArrayList<Integer>> relation_map = new ArrayList<>();
        for (int j = 0; j < m / 2; j++) {
            relation_map.add(new ArrayList<>());
        }

        // 遍历发布者
        for (int i = 0; i < n / 2; i++) {
            for (int j = m / 2 - 1; j >= 0; j--) {
                if (producer_map[i].a >= consumer_map[j].a)
                    if (producer_map[i].a < consumer_map[j].b) {
                        relation_map.get(j).add(producer_map[i].b);
                        break;
                    }
            }
        }

        int i = 0;
        while (true) {
            if (i >= m / 2) {
                break;
            } else {
                if (relation_map.get(i).size() == 0) {
                    System.out.println("-1");
                } else {
                    String result = "";
                    for (Integer x : relation_map.get(i)) {
                        result += x + " ";
                    }
                    System.out.println(result);
                }
            }
            i += 1;
        }

    }

    //消息类
    static class Message {
        int a;
        int b;

        public Message(int a, int b) {
            this.a = a;
            this.b = b;

        }
    }
}