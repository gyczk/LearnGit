package csdn.B;


import java.util.Scanner;

// 最小循环子数组
public class B054 {

    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        int count = Integer.parseInt(in.nextLine());
        String input_str = in.nextLine().replace(" ", "");
        for (int i = 1; i <= input_str.length(); i++) {
            if (input_str.length() % i == 0) {
                String tmp = input_str;
                tmp = tmp.replace(input_str.substring(0, i), "");
                if (tmp.equals("")) {
                    for (int j = 0; j < i; j++) {
                        System.out.print(input_str.charAt(j));
                        if (j != i - 1) {
                            System.out.print(" ");
                        }

                    }
                    break;
                }
            }
        }
    }
}
