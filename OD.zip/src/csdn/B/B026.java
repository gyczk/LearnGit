package csdn.B;

import java.util.Scanner;

// 通过软盘拷贝文件
public class B026 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        int[] nums = new int[n];
        for (int i = 0; i < n; i++) {
            nums[i] = Integer.parseInt(in.nextLine());
        }

        //二维DP已经转成1维DP， 审核大佬请注意。。。。
        int[] dp = new int[3000];
        for (int num : nums) {
            for (int j = 2880; j >= (int) Math.ceil(num / 512.0); j--) {
                dp[j] = Math.max(dp[j], dp[j - (int) Math.ceil(num / 512.0)] + num);
            }
        }

        System.out.println(dp[2880]);
    }

}

