package csdn.B;


import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Scanner;

// 	最小传输时延I
public class B064 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();

        int[][] matrix = new int[m][3];
        for (int i = 0; i < m; i++) {
            matrix[i][0] = in.nextInt();
            matrix[i][1] = in.nextInt();
            matrix[i][2] = in.nextInt();
        }

        int start = in.nextInt();
        int end = in.nextInt();

        //优先级队列的实现方式！！！
        PriorityQueue<int[]> queue = new PriorityQueue<>((a, b) -> a[1] - b[1]);
        int[] dist = new int[n + 1];
        Arrays.fill(dist, Integer.MAX_VALUE);
        dist[start] = 0;
        queue.add(new int[]{start, 0});
        while (!queue.isEmpty()) {
            int[] poll = queue.poll();
            int node = poll[0];
            for (int i = 0; i < matrix.length; i++) {
                if (matrix[i][0] == node) {
                    int next = matrix[i][1];
                    if (dist[next] > dist[node] + matrix[i][2]) {
                        dist[next] = dist[node] + matrix[i][2];
                        queue.add(new int[]{next, dist[next]});
                    }
                }
            }
        }
        if (dist[end] == Integer.MAX_VALUE) {
            System.out.println(-1);
        } else {
            System.out.println(dist[end]);
        }
    }

    public static int networkDelayTime(int[][] matrix, int n, int k) {
        final int INF = Integer.MAX_VALUE / 2;
        int[][] g = new int[n][n];
        for (int i = 0; i < n; ++i) {
            Arrays.fill(g[i], INF);
        }
        for (int[] t : matrix) {
            int x = t[0] - 1, y = t[1] - 1;
            g[x][y] = t[2];
        }

        int[] dist = new int[n];
        Arrays.fill(dist, INF);
        dist[k - 1] = 0;
        boolean[] used = new boolean[n];
        for (int i = 0; i < n; ++i) {
            int x = -1;
            for (int y = 0; y < n; ++y) {
                if (!used[y] && (x == -1 || dist[y] < dist[x])) {
                    x = y;
                }
            }
            used[x] = true;
            for (int y = 0; y < n; ++y) {
                dist[y] = Math.min(dist[y], dist[x] + g[x][y]);
            }
        }

        int ans = Arrays.stream(dist).max().getAsInt();
        return ans == INF ? -1 : ans;
    }
}
