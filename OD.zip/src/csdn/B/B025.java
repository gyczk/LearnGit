package csdn.B;

import java.util.*;

// 找出两个整数数组中同时出现的整数
public class B025 {


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(",");
        int[] nums1 = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums1[i] = Integer.parseInt(tmp2[i]);
        }

        String input_str1 = in.nextLine();
        String[] tmp1 = input_str1.split(",");
        int[] nums2 = new int[tmp1.length];
        for (int i = 0; i < tmp1.length; i++) {
            nums2[i] = Integer.parseInt(tmp1[i]);
        }

        HashMap<Integer, Integer> num1_map = new HashMap<>();
        int i = 0;
        while (true) {
            if (i >= nums1.length) {
                break;
            } else {
                if (num1_map.containsKey(nums1[i])) {
                    num1_map.put(nums1[i], num1_map.get(nums1[i]) + 1);
                } else {
                    num1_map.put(nums1[i], 1);
                }
            }
            i += 1;
        }

        HashMap<Integer, Integer> num2_map = new HashMap<>();
        int j = 0;
        while (true) {
            if (j >= nums2.length) {
                break;
            } else {
                if (num2_map.containsKey(nums2[j])) {
                    num2_map.put(nums2[j], num2_map.get(nums2[j]) + 1);
                } else {
                    num2_map.put(nums2[j], 1);
                }
            }
            j += 1;
        }


        boolean flag = true;
        String output_str = "NULL";
        HashMap<Integer, ArrayList<Integer>> result_map = new HashMap<>();
        for (Integer num : num1_map.keySet()) {
            if (num2_map.containsKey(num)) {
                flag = false;
                int count = Math.min(num1_map.get(num), num2_map.get(num));
                if (result_map.containsKey(count)) {
                    result_map.get(count).add(num);
                } else {
                    result_map.put(count, new ArrayList<>());
                    result_map.get(count).add(num);
                }
            }
        }
        if (!flag) {
            ArrayList<Integer> temp = new ArrayList<>();
            for (Integer num : result_map.keySet()) {
                temp.add(num);
            }
            Collections.sort(temp, new Comparator<Integer>() {
                @Override
                //在这里主要是重写了 Comparator类的compare方法，
                //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
                public int compare(Integer o1, Integer o2) {
                    return o1 - o2;//当大于0就交换，否则不交换。
                }
            });
            output_str = "";
            for (int m = 0; m < temp.size(); m++) {
                output_str += temp.get(m) + ":";
                for (int n = 0; n < result_map.get(temp.get(m)).size(); n++) {
                    output_str += result_map.get(temp.get(m)).get(n);
                    if (n != result_map.get(temp.get(m)).size() - 1) {
                        output_str += ",";
                    }
                }
                output_str += "\n";
            }
            System.out.println(output_str);

        } else {
            System.out.println(output_str);
        }
    }
}
