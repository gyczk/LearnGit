package csdn.B;

import java.util.Scanner;

//稀疏矩阵
public class B017 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int m = in.nextInt();
        int n = in.nextInt();

        int[][] matrix = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = in.nextInt();
            }
        }

        //统计出指定个数
        int[] arr1 = new int[m];
        int[] arr2 = new int[n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (matrix[i][j] == 0) {
                    arr1[i]++;
                    arr2[j]++;
                }
            }
        }

        //判断
        int count1 = 0;
        int count2 = 0;
        for (int num : arr1) {
            if (num >= n / 2) {
                count1 += 1;
            }
        }
        for (int num : arr2) {
            if (num >= m / 2) {
                count2 += 1;
            }
        }


        System.out.println(count1);
        System.out.println(count2);
    }
}