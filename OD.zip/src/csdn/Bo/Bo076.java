package csdn.Bo;


import java.math.BigInteger;
import java.util.Scanner;

// N进制减法
public class Bo076 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String[] split = in.nextLine().split(" ");
        int radix = Integer.parseInt(split[0]);
        if ((split[1].length() > 1 && split[1].startsWith("0")) ||
                split[2].length() > 1 && split[2].startsWith("0")) {
            System.out.print(-1);

        } else {
            BigInteger a = new BigInteger(split[1], radix);
            BigInteger b = new BigInteger(split[2], radix);

            BigInteger temp = a.subtract(b);
            int signum = temp.signum();
            String res = temp.abs().toString(radix);

            System.out.println((signum == 1 ? "0" : "1") + " " + res);

        }
    }

}
