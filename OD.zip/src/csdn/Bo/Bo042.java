package csdn.Bo;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// 出错的或电路
public class Bo042 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);

        int n = Integer.parseInt(in.nextLine());
        char[] input_str1 = in.nextLine().toCharArray();
        char[] input_str2 = in.nextLine().toCharArray();

        List<Integer> c = new ArrayList<Integer>();
        int[] cnt = new int[2];
        for (int i = 0; i < n; i++) {
            if (input_str2[i] == '0') {
                //System.out.println(input_str1[i]);
                c.add(Integer.parseInt(String.valueOf(input_str1[i])));
            }
            if (input_str1[i] == '0') {
                cnt[0] += 1;
            } else {
                cnt[1] += 1;
            }
        }
        //System.out.println(c);

        int total = 0;

        for (int i = 0; i < c.size(); i++) {
            total += cnt[c.get(i) ^ 1];
            cnt[c.get(i)] -= 1;
        }

        System.out.println(total);

    }
}

