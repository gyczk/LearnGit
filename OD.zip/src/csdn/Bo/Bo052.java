package csdn.Bo;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

// 数字反转打印
public class Bo052 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        List<List<String>> lists = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            List<String> list = new ArrayList<>();
            int fn = firstNum(i);
            lists.forEach(x -> {
                x.add(0, "    ");
            });
            for (int j = 0; j < i; j++) {
                String temp = fn++ + "***";
                list.add(temp.substring(0, 4));
                if (j != i - 1) {
                    list.add("    ");
                }
            }
            if ((i) % 2 == 0) {
                Collections.reverse(list);
            }
            lists.add(list);
        }
        lists.forEach(x -> {
            StringBuilder res = new StringBuilder();
            for (String s : x) {
                res.append(s);
            }
            System.out.println(res);
        });
    }

    public static int firstNum(int n) {
        if (n == 1) {
            return 1;
        }
        return firstNum(n - 1) + n - 1;
    }
}
