package csdn.B;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// 关联子串
public class B061 {
    public static void dfs(String str, boolean[] used, List<Character> path, List<String> result) {
        // 如果已经选出了str的所有字符，则将当前的排列组合加入结果集
        if (str.length() == path.size()) {
            StringBuilder res = new StringBuilder();
            for (char c : path) {
                res.append(c);
            }
            result.add(res.toString());
            return;
        }

        // 依次选取未被使用的字符，生成排列组合
        for (int i = 0; i < str.length(); i++) {
            if (!used[i]) {
                path.add(str.charAt(i));
                used[i] = true;
                dfs(str, used, path, result);
                used[i] = false;
                path.remove(path.size() - 1);
            }
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String line = in.nextLine();
        String str1 = line.substring(0, line.indexOf(" "));
        String str2 = line.substring(line.indexOf(" ") + 1);
        int index = -1;

        // 生成str1的所有排列组合
        List<String> result = new ArrayList<>();
        boolean[] used = new boolean[str1.length()];
        List<Character> path = new ArrayList<>();
        dfs(str1, used, path, result);

        // 在str2中查找是否存在str1的子串
        for (String substr : result) {
            int idx = str2.indexOf(substr);
            if (idx != -1) {
                index = idx;
                System.out.println(index);
                return;
            }
        }

        // 如果不存在，则返回-1
        System.out.println(-1);

    }
}
