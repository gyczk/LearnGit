package csdn.B;

import java.util.*;

// 宜居星球改造计划
public class B001 {
    public static int[] dr = new int[]{-1, 0, 1, 0};
    public static int[] dc = new int[]{0, -1, 0, 1};

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<String[]> matrix = new ArrayList<>();
        while (in.hasNextLine()) {
            String line = in.nextLine();
            //空行跳出
            if ("".equals(line)) {
                break;
            } else {
                matrix.add(line.split(" "));
            }
        }
        String[][] grid = new String[matrix.size()][matrix.get(0).length];
        matrix.toArray(grid);

        System.out.println(orangesRotting(grid));
    }

    public static int orangesRotting(String[][] grid) {
        int R = grid.length, C = grid[0].length;
        Queue<Integer> queue = new ArrayDeque<Integer>();
        Map<Integer, Integer> depth = new HashMap<Integer, Integer>();
        for (int r = 0; r < R; ++r) {
            for (int c = 0; c < C; ++c) {
                if (grid[r][c].equals("YES")) {
                    int code = r * C + c;
                    queue.add(code);
                    depth.put(code, 0);
                }
            }
        }
        int ans = 0;
        while (!queue.isEmpty()) {
            int code = queue.remove();

            int r = code / C, c = code % C;
            for (int k = 0; k < 4; ++k) {
                int nr = r + dr[k];
                int nc = c + dc[k];
                if (0 <= nr && nr < R && 0 <= nc && nc < C && grid[nr][nc].equals("NO")) {
                    grid[nr][nc] = "YES";
                    int ncode = nr * C + nc;
                    queue.add(ncode);
                    depth.put(ncode, depth.get(code) + 1);
                    ans = depth.get(ncode);
                }
            }
        }
        for (String[] row : grid) {
            for (String v : row) {
                if (v.equals("NO")) {
                    return -1;
                }
            }
        }
        return ans;
    }
}


