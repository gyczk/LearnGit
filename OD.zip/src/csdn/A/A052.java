package csdn.A;

//
public class A052 {

}
