package csdn.Bo;


import java.util.Scanner;


// 最长连续方波信号
public class Bo050 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.next();
        int n = input_str.length();
        input_str += "0";
        String result_str = "";
        int index = 0;
        while (index < n && input_str.charAt(index) == '1') {
            index++;
        }
        //特殊情况
        if (index >= n) {
            System.out.println(-1);
            return;
        }

        //波峰波谷判定
        for (int i = 0; i < n; i++) {
            if (input_str.charAt(i) == '0' && input_str.charAt(i + 1) == '0') {
                if (i != index && (i - index + 1) % 2 == 1) {
                    int t = 0;
                    boolean flag = true;
                    for (int j = index; j <= i; j++) {
                        if (input_str.charAt(j) - '0' != t) {
                            flag = false;
                            break;
                        }
                        t = (t + 1) % 2;
                    }
                    if (flag) {
                        if (result_str.length() < (i - index + 1))
                            result_str = input_str.substring(index, i + 1);
                    }
                }
                index = i + 1;
            }
        }

        if (result_str.length() > 0) {
            System.out.println(result_str);
        } else {
            System.out.println(-1);
        }

    }
}

