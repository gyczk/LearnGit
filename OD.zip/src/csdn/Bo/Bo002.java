package csdn.Bo;


import java.util.Scanner;

// 字符串子序列 II
public class Bo002 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        String input_str0 = in.nextLine();
        String input_str1 = in.nextLine();
        char target = input_str0.charAt(input_str0.length() - 1);
        int i = input_str1.length() - 1;
        int count = 1;
        while (true) {
            if (i < 0) {
                break;
            } else {
                char current = input_str1.charAt(i);
                if (current == target) {
                    count += 1;
                    if (input_str0.length() - count >= 0) {
                        target = input_str0.charAt(input_str0.length() - count);
                    } else {
                        System.out.println(i);
                        return;
                    }
                }
            }
            i -= 1;
        }

        System.out.println(-1);

    }

}
