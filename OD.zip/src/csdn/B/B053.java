package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

// 符合要求的元组的个数
public class B053 {
    public static int result = 0;
    public static int k;

    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        int[] nums = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        k = Integer.parseInt(in.nextLine());
        int target = Integer.parseInt(in.nextLine());
        Arrays.sort(nums);
        dfs(nums, target, 0, 0, 0);
        System.out.println(result);
    }

    public static void dfs(int[] nums, int target, int pos, int sum_val, int count) {

        int i = pos;
        while (true) {
            if (i >= nums.length) {
                break;
            } else {
                if (i > pos && nums[i - 1] == nums[i]) {
                    i += 1;
                    continue;
                } else {
                    if ((count + 1) == k) {
                        if ((sum_val + nums[i]) == target) {
                            result += 1;
                        } else {
                            i += 1;
                            continue;
                        }
                    } else {
                        int new_pos = i + 1;
                        dfs(nums, target, new_pos, sum_val + nums[i], count + 1);
                    }
                }
            }
            i += 1;
        }
    }

}
