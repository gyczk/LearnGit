package csdn.B;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

//比赛
public class B013 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String[] strings1 = in.nextLine().split(",");
        int m = Integer.valueOf(strings1[0]);
        int n = Integer.valueOf(strings1[1]);
        if (m < 3 || m > 10 || n < 3 || n > 100) {
            System.out.println("-1");
            return;
        }

        int[][] scores = new int[m][n];
        for (int i = 0; i < m; i++) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(",");
            int[] nums = new int[tmp2.length];
            for (int x = 0; x < tmp2.length; x++) {
                nums[x] = Integer.parseInt(tmp2[x]);
            }
            for (int j = 0; j < n; j++) {
                scores[i][j] = nums[j];
                if (scores[i][j] > 10 || scores[i][j] < 1) {
                    System.out.println("-1");
                    return;
                }
            }
        }

        ArrayList<Player> playerList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int total = 0;
            ArrayList<Integer> scoreList = new ArrayList<Integer>();
            for (int j = 0; j < m; j++) {
                scoreList.add(scores[j][i]);
                total += scores[j][i];
            }
            playerList.add(new Player(i, total, scoreList));
        }

        Collections.sort(playerList, new Comparator<Player>() {
            @Override
            public int compare(Player p1, Player p2) {
                // 比较总分
                if (p1.total != p2.total) {
                    return p2.total - p1.total;
                } else {
                    ArrayList<Integer> playerList = p1.scores;
                    ArrayList<Integer> scoreList = p2.scores;
                    for (int i = 10; i > 0; i--) {
                        if (single(playerList, i) < single(scoreList, i)) {
                            return -1;
                        }
                    }
                }
                return 0;
            }

        });

        for (int i = 0; i < 3; i++) {
            if (i == 2) {
                System.out.println(playerList.get(i).index + 1);
            } else {
                System.out.print(playerList.get(i).index + 1 + ",");
            }

        }

    }

    public static int single(ArrayList<Integer> list, int count) {
        int ret = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) == count) {
                ret++;
            }
        }
        return ret;
    }
}

class Player {
    int index;
    int total;
    ArrayList<Integer> scores;

    public Player(int index, int total, ArrayList<Integer> scores) {
        this.index = index;
        this.total = total;
        this.scores = scores;
    }
}
 