package csdn.Bo;


import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// 字符串序列判定
public class Bo106 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String subStr = in.nextLine();
        String str = in.nextLine();

        String regStr = subStr.replaceAll("", ".*");
        Pattern pattern = Pattern.compile(regStr, Pattern.MULTILINE);
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            int index = matcher.end() - 1;
            System.out.println(index);
        } else {
            System.out.println(-1);
        }
    }

}
