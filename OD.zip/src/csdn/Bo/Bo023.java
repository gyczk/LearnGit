package csdn.Bo;


import java.util.Arrays;
import java.util.Scanner;

// 打印任务排序
public class Bo023 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        Integer[] queue = Arrays.stream(in.nextLine().split(",")).map(Integer::parseInt).toArray(Integer[]::new);
        int n = queue.length;

        int[][] tasks = new int[n][2];
        for (int i = 0; i < n; i++) {
            tasks[i] = new int[]{queue[i], i};
        }

        //自定义排序
        Arrays.sort(tasks, (a, b) -> b[0] - a[0]);

        int[] printers = new int[n];
        for (int i = 0; i < n; i++) {
            printers[tasks[i][1]] = i;
        }

        String result = "";
        for (int print : printers) {
            result += print + ",";
        }
        System.out.println(result.substring(0, result.length() - 1));

    }

}
