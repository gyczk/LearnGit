package csdn.B;


import java.util.Arrays;
import java.util.Scanner;

// 	最长连续子序列
public class B084 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] nums = Arrays.stream(in.nextLine().split(",")).mapToInt(Integer::parseInt).toArray();
        int n = Integer.parseInt(in.nextLine());

        // 子序列最大长度，默认-1
        int maxLen = -1;
        for (int i = 0; i < nums.length - 1; i++) {
            int sum = nums[i];
            if (sum > n) {
                continue;
            } else if (sum == n) {
                maxLen = Math.max(maxLen, 1);
            }
            int count = 1;
            for (int j = i + 1; j < nums.length; j++) {
                sum += nums[j];
                count++;
                if (sum > n) {
                    break;
                } else if (sum == n) {
                    maxLen = Math.max(maxLen, count);
                    break;
                }
            }
        }

        System.out.println(maxLen);
    }
}
