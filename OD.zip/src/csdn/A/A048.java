package csdn.A;

//
public class A048 {

}
