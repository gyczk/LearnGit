package csdn.B;


import java.util.Scanner;

// 	找出经过特定点的路径长度
public class B068 {
    public static int count = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String str1 = in.nextLine();
        String str2 = in.nextLine();
        int distance = 0;
        int index1 = 0;
        for (int i = 0; i < str1.length(); i++) {
            if (str1.charAt(i) == str2.charAt(0)) {
                index1 = i;
                break;
            }
        }
        //System.out.println(index1);
        for (int i = 1; i < str2.length(); i++) {
            int index2 = 0;
            for (int j = 0; j < str1.length(); j++) {
                if (str1.charAt(j) == str2.charAt(i)) {
                    index2 = j;
                    break;
                }
            }
            distance += Math.abs(index2 - index1);
            index1 = index2;
        }
        System.out.println(distance);
    }
}
