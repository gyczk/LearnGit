package csdn.B;


import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

// 	最长的元音子串
public class B081 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        List<Character> vowel = Arrays.asList('a', 'e', 'i', 'o', 'u');

        int result = 0, tmpLen = 0;
        for (char c : input_str.toLowerCase().toCharArray()) {
            if (vowel.contains(c)) {
                tmpLen++;
            } else {
                result = Math.max(result, tmpLen);
                tmpLen = 0;
            }
        }
        result = Math.max(result, tmpLen);

        System.out.print(result);
    }

}
