package csdn.B;


import java.util.Scanner;

// 按单词下标区间翻转文章内容
public class B069 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        int start = in.nextInt();
        int end = in.nextInt();

        String[] words = input_str.split(" ");
        if (start > end || start > words.length - 1 || end < 0) {
            System.out.println(input_str);
        } else {
            int l = Math.max(0, start);
            int r = Math.min(words.length - 1, end);

            while (l <= r) {
                String tmp = words[l];
                words[l] = words[r];
                words[r] = tmp;
                l++;
                r--;
            }

            for (int i = 0; i < words.length; i++) {
                System.out.print(words[i]);
                if (i != words.length - 1) {
                    System.out.print(" ");
                }
            }
        }


    }

}
