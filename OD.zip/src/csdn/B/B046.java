package csdn.B;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// 生日礼物
public class B046 {
    public static int count = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(",");
        Integer[] cakes = new Integer[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            cakes[i] = Integer.parseInt(tmp2[i]);
        }

        String input_str1 = in.nextLine();
        String[] tmp21 = input_str1.split(",");
        int[] gifts = new int[tmp21.length];
        for (int i = 0; i < tmp21.length; i++) {
            gifts[i] = Integer.parseInt(tmp21[i]);
        }
        int target = Integer.parseInt(in.nextLine());

        Arrays.sort(cakes, new Comparator<Integer>() {
            @Override
            //在这里主要是重写了 Comparator类的compare方法，
            //sort方法可能也用了这个方法进行排序，然后在这里被重写了。
            public int compare(Integer o1, Integer o2) {
                return o1 - o2;
            }
        });
        int i = 0;
        while (true) {
            if (i >= gifts.length) {
                System.out.println(count);
                break;
            } else {
                if (target <= gifts[i]) {
                    continue;
                } else {
                    int left = 0;
                    int right = cakes.length - 1;
                    int k = 0;
                    boolean flag = false;
                    while (true) {
                        if (left > right) {
                            break;
                        } else {
                            int mid = (left + right) >> 1;
                            if (cakes[mid] > target - gifts[i]) {
                                right = mid - 1;
                            } else if (cakes[mid] < target - gifts[i]) {
                                left = mid + 1;
                            } else {
                                if (mid == cakes.length - 1 || cakes[mid] != cakes[mid + 1]) {
                                    k = mid;
                                    flag = true;
                                    break;
                                } else {
                                    left = mid + 1;
                                }
                            }
                        }
                    }
                    if (!flag) {
                        k = -left - 1;
                    }
                    count += (k >= 0) ? k + 1 : -k - 1;
                }
            }
            i += 1;
        }
    }
}
