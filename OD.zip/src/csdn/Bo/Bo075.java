package csdn.Bo;


import java.util.Scanner;

// 图像物体的边界
public class Bo075 {
    public static int row;
    public static int col;
    public static int[][] matrix;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        row = in.nextInt();
        col = in.nextInt();
        matrix = new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                matrix[i][j] = in.nextInt();
            }
        }

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (matrix[i][j] == 5) {
                    if (i > 0 && j > 0) matrix[i - 1][j - 1] = 0;
                    if (i > 0) matrix[i - 1][j] = 0;
                    if (i > 0 && j < col - 1) matrix[i - 1][j + 1] = 0;
                    if (j > 0) matrix[i][j - 1] = 0;
                    if (i > 0 && j < col - 1) matrix[i][j + 1] = 0;
                    if (i < row - 1 && j > 0) matrix[i + 1][j - 1] = 0;
                    if (i < row - 1 && j > 0) matrix[i + 1][j] = 0;
                    if (i < row - 1 && j < col - 1) matrix[i + 1][j + 1] = 0;
                }
            }
        }

        int count = 0;
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (matrix[i][j] == 0) {
                    count++;
                    matrix[i][j] = -1;
                    countBorder(i, j);
                }
            }
        }
        System.out.println(count);
    }

    public static void countBorder(int i, int j) {
        if (i > 0) {
            if (matrix[i - 1][j] == 0) {
                matrix[i - 1][j] = -1;
                countBorder(i - 1, j);
            }
            if (j > 0) {
                if (matrix[i - 1][j - 1] == 0) {
                    matrix[i - 1][j - 1] = -1;
                    countBorder(i - 1, j - 1);
                }
            }
            if (j < col - 1) {
                if (matrix[i - 1][j + 1] == 0) {
                    matrix[i - 1][j + 1] = -1;
                    countBorder(i - 1, j + 1);
                }
            }
        }
        if (j > 0) {
            if (matrix[i][j - 1] == 0) {
                matrix[i][j - 1] = -1;
                countBorder(i, j - 1);
            }
        }
        if (i < row - 1) {
            if (matrix[i + 1][j] == 0) {
                matrix[i + 1][j] = -1;
                countBorder(i + 1, j);
            }
            if (j > 0) {
                if (matrix[i + 1][j - 1] == 0) {
                    matrix[i + 1][j - 1] = -1;
                    countBorder(i + 1, j - 1);
                }
            }
            if (j < col - 1) {
                if (matrix[i + 1][j + 1] == 0) {
                    matrix[i + 1][j + 1] = -1;
                    countBorder(i + 1, j + 1);
                }
            }
        }
        if (j < col - 1) {
            if (matrix[i][j + 1] == 0) {
                matrix[i][j + 1] = -1;
                countBorder(i, j + 1);
            }
        }
    }
}

