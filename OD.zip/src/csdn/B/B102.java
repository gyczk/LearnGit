package csdn.B;


import java.util.*;
import java.util.stream.Collectors;

// 排队游戏
public class B102 {

    public static void main(String[] args) {
        //输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        int n = nums[0];
        int m = nums[1];
        int k = nums[2];

        //多种写法
        List<Integer> nums1 = Arrays.stream(in.nextLine().split(" "))
                .map(Integer::parseInt)
                .collect(Collectors.toList());
        HashMap<Integer, Integer> num1_map = new HashMap<>();
        for (int i = 0; i < nums1.size(); i++) {
            if (!num1_map.containsKey(nums1.get(i))) {
                num1_map.put(nums1.get(i), 1);
            }
        }

        String input_str2 = in.nextLine();
        String[] tmp22 = input_str2.split(" ");
        int[] nums2 = new int[tmp22.length];
        for (int i = 0; i < tmp22.length; i++) {
            nums2[i] = Integer.parseInt(tmp22[i]);
        }

        int sum_val = 0;
        ArrayList<Integer> students = new ArrayList<>();
        int i = 0;
        while (true) {
            if (i >= n) {
                if (sum_val <= k) {
                    System.out.println(0);
                } else {
                    System.out.println(1);
                }
                break;
            } else {
                int index = 0;
                int length = students.size();
                int left = 0;
                int right = length - 1;
                //二分法找到对应的位置
                while (left <= right) {
                    int mid = (left + right) / 2;
                    if (students.get(mid) < k) {
                        left = mid + 1;
                    } else if (students.get(mid) == k) {
                        if (mid == length - 1 || students.get(mid) - students.get(mid + 1) != 0) {
                            index = mid + 1;
                            break;
                        } else {
                            left = mid + 1;
                        }
                    } else {
                        right = mid - 1;

                    }
                }
                if (index == 0) {
                    index = left;
                }

                //快速判断是否对应位置
                if (num1_map.containsKey(i)) {
                    students.add(index, nums2[i]);
                } else {
                    sum_val += students.size() - index;
                }
            }
            i += 1;
        }
    }

}
