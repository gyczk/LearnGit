package csdn.Bo;


import java.util.Scanner;

// 喊七的次数重排
public class Bo027 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        String[] num_strs = in.nextLine().split(" ");
        int length = num_strs.length;
        int[] nums = new int[length];

        int total = 0;
        for (int i = 0; i < length; i++) {
            total += Integer.valueOf(num_strs[i]);
        }
        int count = 7;
        while (total > 0) {
            if (count % 7 == 0 || String.valueOf(count).contains("7")) {
                nums[(count - 1) % length]++;
                total--;
            }
            count++;
        }

        String result = "";
        for (int i = 0; i < length; i++) {
            result += String.valueOf(nums[i]);
            if (i != length - 1) {
                result += " ";
            }
        }

        System.out.println(result);
    }


}
