package csdn.Bo;


import java.util.LinkedList;
import java.util.Scanner;

// 水仙花数II(字符串分割)
public class Bo091 {
    public static LinkedList<Integer> resList = new LinkedList<>();

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String line = in.nextLine();
        int count = 2;
        find(line, count);

        int result = 0;
        if (resList.size() > 1) {
            result = -1;
        } else if (resList.size() == 1) {
            result = resList.get(0);
        }

        System.out.println(result);

    }

    //  递归求解
    public static void find(String line, int count) {
        for (int i = 1; i < line.length(); i++) {
            String sub1 = line.substring(0, i);
            String sub2 = line.substring(i);
            if (check(get_sum(sub1))) {
                if (check(get_sum(sub2))) {
                    resList.add(count);
                } else {
                    find(sub2, count++);
                }
            }
        }
    }

    public static int get_sum(String str) {
        int sum = 0;
        char[] chars = str.toCharArray();
        for (int i = 0; i < str.length(); i++) {
            sum += chars[i];
        }
        return sum;
    }

    public static boolean check(int sum) {
        int i = sum % 10;
        int j = sum / 10 % 10;
        int k = sum / 100;
        return i * i * i + j * j * j + k * k * k == sum;
    }

}
