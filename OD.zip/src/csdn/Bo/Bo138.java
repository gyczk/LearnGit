package csdn.Bo;


import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

// 最大时间
public class Bo138 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String str = in.nextLine().replace("[", "").replace("]", "");
        System.out.println(getResult(str));
    }

    private static String getResult(String line) {
        final String s = "invalid";
        final String c = ":";
        String[] strArray = line.split(",");
        // 转换为数组,放入集合
        List<Integer> list = Arrays.stream(strArray).map(Integer::parseInt).collect(Collectors.toList());
        StringBuilder result = new StringBuilder();
        //第一位不能大于3,获取数组中小于3的数字中最大的一个
        int data1 = getDataOfLocation(list, 3);
        if (data1 != -1) {
            list.remove(Integer.valueOf(data1));
            result.append(data1);
        } else {
            return s;
        }
        //如果第一位是2,那么第二位则不能超过4
        if (result.charAt(0) == '2') {
            //第二位
            int data2 = getDataOfLocation(list, 4);
            if (data2 != -1) {
                // 按照元素删除
                list.remove(Integer.valueOf(data2));
                result.append(data2);
                result.append(c);
            } else {
                return s;
            }
            // 否则,第一位可能是0或者1,这样第二位可以是0-9,即小于10
        } else {
            //第二位
            int data3 = getDataOfLocation(list, 10);
            if (data3 != -1) {
                list.remove(data3);
                result.append(data3);
                result.append(c);
            } else {
                return s;
            }
        }
        //第三位,分钟最大是59,即小于6
        int data4 = getDataOfLocation(list, 6);
        if (data4 != -1) {
            list.remove(Integer.valueOf(data4));
            result.append(data4);
        } else {
            return s;
        }
        //第四位,0-9
        int data5 = getDataOfLocation(list, 10);
        if (data5 != -1) {
            list.remove(Integer.valueOf(data5));
            result.append(data5);
            result.append(c);
        } else {
            return s;
        }
        //第五位
        int data6 = getDataOfLocation(list, 6);
        if (data6 != -1) {
            list.remove(Integer.valueOf(data6));
            result.append(data6);
        } else {
            return s;
        }
        //最后一位
        if (getDataOfLocation(list, 10) != -1) {
            result.append(getDataOfLocation(list, 10));
        } else {
            return s;
        }
        return result.toString();
    }

    /**
     * 获取数组中比 standard 小的数字中最大的一个数,没有返回-1
     */
    static int getDataOfLocation(List<Integer> list, int standard) {
        return list.stream().filter(x -> x < standard).mapToInt(x -> x).max().orElse(-1);
    }
}



