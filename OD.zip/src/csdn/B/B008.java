package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

//	座位调整
public class B008 {
    public static int count = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] nums = Arrays.stream(in.nextLine().split(",")).mapToInt(Integer::parseInt).toArray();
        int n = nums.length;
        // 新解法
        solve(nums, n);
        System.out.println(count);
    }

    public static void solve(int[] nums, int n) {
        for (int j = 0; j < n; j++) {
            if (nums[j] != 0) {
                continue;
            } else {
                if (j == 0 || nums[j] == 0) {
                    if (j == n - 1 || nums[j + 1] == 0) {
                        count += 1;
                        nums[j] = 1;
                        j += 1;
                    }
                }
            }
        }
    }

    public static int findTargetSumWays(int[] nums, int target) {
        backtrack(nums, target, 0, 0);
        return count;
    }

    public static void backtrack(int[] nums, int target, int index, int sum) {
        if (index == nums.length) {
            if (sum == target) {
                count++;
            }
        } else {
            backtrack(nums, target, index + 1, sum + nums[index]);
            backtrack(nums, target, index + 1, sum);
        }
    }

}

