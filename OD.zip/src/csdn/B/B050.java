package csdn.B;

import java.util.*;

// 树状结构查询
public class B050 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        HashMap<String, HashSet<String>> relation = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String input_str = in.nextLine();
            String[] tmp2 = input_str.split(" ");
            if (!relation.containsKey(tmp2[1])) {
                relation.put(tmp2[1], new HashSet<>());
            }
            relation.get(tmp2[1]).add(tmp2[0]);
        }

        String target = in.nextLine();
        ArrayList<String> queue = new ArrayList<>(relation.get(target));
        String[] result = new String[10000];
        for (int i = 0; i < 10000; i++) {
            result[i] = "";
        }
        int i = 0;
        while (queue.size() > 0) {
            String node = queue.get(0);
            queue.remove(0);
            if (relation.containsKey(node)) {
                for (String x : relation.get(node)) {
                    queue.add(x);
                }
            }
            result[i] = node;
            i += 1;
        }

        Arrays.sort(result);
        String output_str = "";
        for (int j = 0; j < 10000; j++) {
            if (!result[j].equals("")) {
                output_str += result[j] + "\n";
            }

        }
        System.out.print(output_str);

    }

}
