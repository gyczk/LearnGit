package csdn.B;


import java.util.Scanner;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// 		字符匹配
public class B063 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String line = in.nextLine();
        Scanner lineScanner = new Scanner(line);
        Vector<String> strArr = new Vector<String>();
        while (lineScanner.hasNext()) {
            String str = lineScanner.next();
            strArr.add(str);
        }

        String pattern = in.nextLine();
        Pattern compile = Pattern.compile("^" + pattern + "$");
        Vector<Integer> result = new Vector<Integer>();
        for (int i = 0; i < strArr.size(); i++) {
            String str = strArr.get(i);
            Matcher matcher = compile.matcher(str);
            if (matcher.matches()) {
                result.add(i);
            }
        }
        if (result.size() == 0) {
            System.out.println("-1");
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < result.size(); i++) {
                sb.append(result.get(i));
                if (i != result.size() - 1) {
                    sb.append(",");
                }
            }
            System.out.println(sb);
        }

    }
}