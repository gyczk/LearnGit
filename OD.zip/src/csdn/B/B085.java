package csdn.B;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

// 	路灯照明II
public class B085 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        int[] nums = Arrays.stream(in.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();

        int[][] lights = new int[n][2];
        for (int i = 0; i < n; i++) {
            lights[i][0] = Math.max(i * 100 - nums[i], 0);
            lights[i][1] = Math.min(i * 100 + nums[i], (n - 1) * 100);
        }

        List<int[]> pairs = new ArrayList<>();
        int start = lights[0][0];
        int end = lights[0][1];
        for (int i = 1; i < n; i++) {
            if (lights[i][0] > end) {
                pairs.add(new int[]{start, end});
                start = lights[i][0];
                end = lights[i][1];
            } else {
                end = Math.max(end, lights[i][1]);
            }
        }
        pairs.add(new int[]{start, end});

        int result = 0;
        int[] pair_start = pairs.get(0);
        int index = 0;
        for (int[] pair : pairs) {
            if (index == 0) {
                index += 1;
                continue;
            }
            result += pair[0] - pair_start[1];
            pair_start = pair;
        }

        System.out.println(result);
    }
}