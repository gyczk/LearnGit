package csdn.Bo;


import java.util.*;


// 发广播
public class Bo059 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String[] s = in.nextLine().split(" ");
        int n = s.length;
        int[][] matrix = new int[n][n];

        for (int i = 0; i < n; i++) {
            matrix[0][i] = Integer.parseInt(s[i]);
        }
        int m = 1;
        while (n > m) {
            for (int i = 0; i < n; i++) {
                matrix[m][i] = in.nextInt();
            }
            m++;
        }

        Map<Integer, List<Integer>> map = new HashMap<>();
        int mapKey = 0;
        for (int i = 0; i < matrix.length; i++) {
            boolean contain_flag = false;
            for (Map.Entry<Integer, List<Integer>> entry : map.entrySet()) {
                if (entry.getValue().contains(i)) {
                    contain_flag = true;
                    mapKey = entry.getKey();
                }
            }
            if (!contain_flag) {
                map.put(i, new ArrayList<>());
                mapKey = i;
            }
            for (int j = i; j < matrix.length; j++) {
                if (i != j && matrix[i][j] == 1) {
                    map.get(mapKey).add(j);
                }
            }
        }

        System.out.print(map.size());
    }

}
