package csdn.B;


import java.util.Scanner;

// 	DNA序列
public class B098 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        int n = in.nextInt();
        char[] char_array = input_str.toCharArray();

        //初始化窗口
        int count = 0, max = 0;
        for (int i = 0; i < n; i++) {
            if (char_array[i] == 'C' || char_array[i] == 'G') {
                count++;
            }
        }
        max = count;

        int left = 1, right = n;
        // 目标窗口的起始位置
        int start_pos = 0;
        while (right < char_array.length) {
            //退出窗口字符
            if (char_array[left - 1] == 'C' || char_array[left - 1] == 'G') {
                count--;
            }
            //移入窗口字符
            if (char_array[right] == 'C' || char_array[right] == 'G') {
                count++;
            }
            if (count > max) {
                max = count;
                start_pos = left;
            }
            left++;
            right++;
        }
        System.out.println(input_str.substring(start_pos, start_pos + n));
    }
}

