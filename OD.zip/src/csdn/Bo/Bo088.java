package csdn.Bo;


import java.util.*;
import java.util.stream.Collectors;

// 任务总执行时长
public class Bo088 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        //转为数组
        List<Integer> nums = Arrays.stream(in.nextLine().split(","))
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        int aTime = nums.get(0);
        int bTime = nums.get(1);
        int num = nums.get(2);
        if (num == 0) {
            System.out.println("[]");
            return;
        }
        Set<Integer> total = new TreeSet<>();
        for (int i = 0; i <= num; i++) {
            int res = aTime * (num - i) + i * bTime;
            total.add(res);
        }

        System.out.println(total);
    }
}
