package csdn.Bo;


import java.util.*;

// 数组拼接
public class Bo041 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int len = Integer.parseInt(in.nextLine());
        int num = Integer.parseInt(in.nextLine());
        String[] arrays = new String[num];
        for (int i = 0; i < num; i++) {
            arrays[i] = in.nextLine();
        }
        List<LinkedList<String>> list = new ArrayList<>();
        List<String> res = new ArrayList<>();
        int sum = 0;
        for (String array : arrays) {
            String[] arr = array.split(",");
            sum += arr.length;
            list.add(new LinkedList<>(Arrays.asList(arr)));
        }
        while (res.size() != sum) {
            for (LinkedList<String> strList : list) {
                if (strList.size() == 0) continue;
                int times = Math.min(strList.size(), len);
                for (int i = 0; i < times; i++) {
                    res.add(strList.remove(0));
                }
            }
        }

        for (int i = 0; i < res.size(); i++) {
            System.out.print(res.get(i));
            if (i != res.size() - 1) {
                System.out.print(",");
            }
        }
    }
}


