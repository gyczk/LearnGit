package csdn.Bo;


import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

// 高矮个子排队
public class Bo008 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);

        try {
            String s = in.nextLine();
            List<Integer> nums = Arrays.stream(s.split(" "))
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());

            getResult(nums);
        } catch (Exception e) {
            System.out.println("[]");
        }
    }

    public static void getResult(List<Integer> nums) {
        //比较
        for (int i = 0; i < nums.size() - 1; i++) {
            if (i % 2 == 0) {
                if (nums.get(i) < nums.get(i + 1)) {
                    int tmp = nums.get(i);
                    nums.set(i, nums.get(i + 1));
                    nums.set(i + 1, tmp);
                }
            } else {
                if (nums.get(i) > nums.get(i + 1)) {
                    int tmp = nums.get(i);
                    nums.set(i, nums.get(i + 1));
                    nums.set(i + 1, tmp);
                }
            }
        }
        for (int i = 0; i < nums.size(); i++) {
            System.out.print(nums.get(i) + " ");
        }

    }
}
