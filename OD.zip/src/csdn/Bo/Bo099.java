package csdn.Bo;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

// 小朋友排队
public class Bo099 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int h = Integer.parseInt(in.nextLine().split(" ")[0]);

        ArrayList<Integer> res = getList(in.nextLine());
        res.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                int d1 = o1 - h > 0 ? o1 - h : h - o1;
                int d2 = o2 - h > 0 ? o2 - h : h - o2;
                if (d1 == d2)
                    return o1 - o2;
                else
                    return d1 - d2;
            }
        });

        StringBuilder sb = new StringBuilder();
        for (int i : res) {
            sb.append(i).append(" ");
        }

        String ans = sb.toString().trim();
        System.out.println(ans);
    }

    public static ArrayList<Integer> getList(String s) {
        String[] split = s.split(" ");
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < split.length; i++) {
            list.add(Integer.parseInt(split[i]));
        }
        return list;
    }
}
