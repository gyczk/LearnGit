package csdn.B;


import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

// 不开心的小朋友
public class B051 {
    public static int count = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        String input_str = in.nextLine();
        String[] nums = input_str.split(" ");
        HashSet<String> now = new HashSet<>();
        Queue<String> lines = new LinkedList<String>();
        for (int i = 0; i < nums.length; i++) {
            if (now.contains(nums[i])) {
                now.remove(nums[i]);
                if (!lines.isEmpty()) {
                    now.add(lines.poll());
                }
            } else if (now.size() < n) {
                now.add(nums[i]);
            } else if (lines.contains(nums[i])) {
                lines.remove(nums[i]);
                count += 1;
            } else {
                lines.offer(nums[i]);
            }
        }
        System.out.println(count);
    }

}
