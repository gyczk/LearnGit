package csdn.Bo;


import java.util.LinkedList;
import java.util.Scanner;

// 迷宫问题
public class Bo112 {
    public static String output_str = "";

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(" ");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }
        int n = nums[0];
        int m = nums[1];

        int[][] matrix = new int[n][m];
        for (int i = 0; i < n; i++) {
            String input_str1 = in.nextLine();
            String[] tmp1 = input_str1.split(" ");
            int[] nums1 = new int[tmp1.length];
            for (int k = 0; k < tmp1.length; k++) {
                nums1[k] = Integer.parseInt(tmp1[k]);
            }
            System.arraycopy(nums1, 0, matrix[i], 0, m);
        }

        dfs(0, 0, new LinkedList<>(), n, m, matrix);
        output_str += "(" + (n - 1) + "," + (m - 1) + ")";
        System.out.println(output_str);

    }

    public static void dfs(int x, int y, LinkedList<String> path, int n, int m, int[][] matrix) {
        if (x == n - 1 && y == m - 1) {
            for (int i = 0; i < path.size(); i++) {
                output_str += path.get(i) + "\n";
            }
            return;
        }
        if (x + 1 < m) {
            if (matrix[x + 1][y] == 0) {
                path.add("(" + x + "," + y + ")");
                matrix[x][y] = 2;
                dfs(x + 1, y, path, n, m, matrix);
                path.removeLast();
            }
        }
        if (x - 1 >= 0) {
            if (matrix[x - 1][y] == 0) {
                path.add("(" + x + "," + y + ")");
                matrix[x][y] = 2;
                dfs(x - 1, y, path, n, m, matrix);
                path.removeLast();
            }
        }
        if (y + 1 < n) {
            if (matrix[x][y + 1] == 0) {
                path.add("(" + x + "," + y + ")");
                matrix[x][y] = 2;
                dfs(x, y + 1, path, n, m, matrix);
                path.removeLast();
            }
        }
        if (y - 1 >= 0) {
            if (matrix[x][y - 1] == 0) {
                path.add("(" + x + "," + y + ")");
                matrix[x][y] = 2;
                dfs(x, y - 1, path, n, m, matrix);
                path.removeLast();
            }
        }


    }
}
