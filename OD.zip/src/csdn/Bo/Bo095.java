package csdn.Bo;


import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


// 字符串中找到连续最长数字串
public class Bo095 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();

        Matcher matcher = Pattern.compile("([+-]?\\d+\\.?\\d+)").matcher(input_str);

        String result = "";
        int maxLen = 0;

        while (matcher.find()) {
            String group = matcher.group();
            if (group.length() >= maxLen) {
                maxLen = group.length();
                result = group;
            }
        }

        System.out.println(result);
    }
}


