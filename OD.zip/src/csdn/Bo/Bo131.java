package csdn.Bo;


import java.util.LinkedList;
import java.util.Scanner;

// 约瑟夫问题
public class Bo131 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        String[] tmp2 = input_str.split(",");
        int[] nums = new int[tmp2.length];
        for (int i = 0; i < tmp2.length; i++) {
            nums[i] = Integer.parseInt(tmp2[i]);
        }

        int size = Integer.parseInt(in.nextLine());
        int m = Integer.parseInt(in.nextLine());
        LinkedList<Integer> queue = new LinkedList<>();
        for (int i = 0; i < nums.length; i++) {
            queue.add(nums[i]);
        }
        String result = "";
        int i = 1;
        while (true) {
            if (size <= 0) {
                break;
            } else {
                if (i == m) {
                    result += queue.get(0) + ",";
                    m = queue.get(0);
                    size--;
                    i = 1;
                } else {
                    queue.add(queue.get(0));
                    i += 1;
                }
                queue.removeFirst();
            }

        }
        System.out.println(result);
    }
}
