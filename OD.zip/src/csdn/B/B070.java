package csdn.B;


import java.util.Scanner;

// 	数列描述
public class B070 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        String init = "1";
        for (int i = 1; i <= n; i++) {
            init = cal(init);
        }
        System.out.println(init);
    }

    public static String cal(String num_list) {
        StringBuilder sb = new StringBuilder();

        int count = 1;
        char val = num_list.charAt(0);

        for (int i = 1; i < num_list.length(); i++) {
            if (num_list.charAt(i) == num_list.charAt(i - 1)) {
                count++;
            } else {
                sb.append(count).append(val);
                count = 1;
                val = num_list.charAt(i);
            }
        }
        sb.append(count).append(val);
        return sb.toString();
    }
}
