package csdn.Bo;


import java.util.Scanner;

// 寻找相同子串
public class Bo036 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        String source = in.nextLine();
        String target = in.nextLine();
        System.out.println(source.indexOf(target) == -1 ? "NO" : source.indexOf(target) + 1 + "");
    }

}
