package csdn.B;

import java.util.HashMap;
import java.util.Scanner;


// 最长的顺子
public class B087 {
    public static String[] all_cards = {"3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        String current_cards = in.nextLine();
        String left_cards = in.nextLine();

        HashMap<String, Integer> cards = new HashMap<>();
        for (String card : all_cards) {
            cards.put(card, 4);
        }

        diff(cards, current_cards);
        diff(cards, left_cards);

        String result = "NO-CHAIN";

        int left = 0, right = 0;
        for (int i = 0; i < all_cards.length; i++) {
            String card = all_cards[i];
            if (cards.get(card) > 0) {
                left = i;
                while (i < all_cards.length - 1 && cards.get(all_cards[i + 1]) > 0) {
                    i++;
                }
                right = i + 1;
            }
        }

        if (right - left >= 5) {
            StringBuilder builder = new StringBuilder();
            for (int i = left; i < right; i++) {
                builder.append(all_cards[i]).append("-");
            }

            if (builder.length() > 0) {
                result = builder.substring(0, builder.length() - 1);
            }
        }
        System.out.println(result);

    }

    private static void diff(HashMap<String, Integer> cards, String str) {
        for (String card : str.split("-")) {
            if (cards.containsKey(card)) {
                cards.put(card, cards.get(card) - 1);
            }
        }
    }
}
