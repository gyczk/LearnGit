package csdn.B;


import java.util.Arrays;
import java.util.Scanner;

// 字符串变换最小字符串
public class B073 {
    public static void main(String[] args) {
        //处理输入
        Scanner in = new Scanner(System.in);
        String input_str = in.nextLine();
        char[] sortedCharArr = input_str.toCharArray();
        Arrays.sort(sortedCharArr);

        String minS = new String(sortedCharArr);
        if (minS.equals(input_str)) {
            System.out.println(input_str);
            return;
        }

        char[] originCharArr = input_str.toCharArray();

        //找到与排序后字符串的第一个不相等位置，然后交换即可
        for (int i = 0; i < input_str.length(); i++) {
            if (originCharArr[i] != sortedCharArr[i]) {
                char tmp = originCharArr[i];
                originCharArr[i] = sortedCharArr[i];

                int idx = input_str.lastIndexOf(sortedCharArr[i]);
                originCharArr[idx] = tmp;
                break;
            }
        }

        System.out.println(new String(originCharArr));
    }
}

