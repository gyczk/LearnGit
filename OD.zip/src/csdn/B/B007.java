package csdn.B;

import java.util.Arrays;
import java.util.Scanner;

//代表团坐车
public class B007 {
    public static int count = 0;

    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int[] nums = Arrays.stream(in.nextLine().split(",")).mapToInt(Integer::parseInt).toArray();

        int target = Integer.parseInt(in.nextLine());

        //使用回溯算法
        System.out.println(findTargetSumWays(nums, target));
    }

    public static int findTargetSumWays(int[] nums, int target) {
        backtrack(nums, target, 0, 0);
        return count;
    }

    public static void backtrack(int[] nums, int target, int index, int sum) {
        if (index == nums.length) {
            if (sum == target) {
                count++;
            }
        } else {
            backtrack(nums, target, index + 1, sum + nums[index]);
            backtrack(nums, target, index + 1, sum);
        }
    }

}
 
 