package csdn.Bo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// 找朋友
public class Bo011 {
    public static void main(String[] args) {
        // 输入处理
        Scanner in = new Scanner(System.in);
        int N = Integer.parseInt(in.nextLine());
        String height_str = in.nextLine();
        String[] heights = height_str.split(" ");

        //单调栈
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            int height1 = Integer.parseInt(heights[i]);
            int index = 0;
            for (int j = i; j < N; j++) {
                int height2 = Integer.parseInt(heights[j]);
                if (height2 > height1) {
                    index = j;
                    break;
                }
            }
            list.add(index);
        }

        //输出
        StringBuilder sb = new StringBuilder();
        for (int i : list) {
            sb.append(i).append(" ");
        }
        System.out.println(sb);
    }
}
