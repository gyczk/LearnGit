package csdn.Bo;


import java.util.Scanner;

// 矩形相交面积
public class Bo081 {
    public static void main(String[] args) {
        // 处理输入
        Scanner in = new Scanner(System.in);
        int[][] coords = new int[3][4];
        for (int i = 0; i < 3; i++) {
            coords[i][0] = in.nextInt();
            coords[i][1] = in.nextInt();
            coords[i][2] = in.nextInt();
            coords[i][3] = in.nextInt();
        }

        int left_x = Math.max(coords[0][0], Math.max(coords[1][0], coords[2][0]));
        int left_y = Math.min(coords[0][1], Math.min(coords[1][1], coords[2][1]));

        int right_x = Math.min(coords[0][0] + coords[0][2], Math.min(coords[1][0] + coords[1][2], coords[2][0] + coords[2][2]));
        int right_y = Math.max(coords[0][1] - coords[0][3], Math.max(coords[1][1] - coords[1][3], coords[2][1] - coords[2][3]));

        if (coords[0][0] >= (coords[1][0] + coords[1][2]) || (coords[0][0] + coords[0][2]) < coords[1][0]) {
            System.out.println(0);
            return;
        }

        int ans = (right_x - left_x) * (left_y - right_y);

        System.out.println(ans);
    }

}

// 并查集模板
class UF {
    int[] item;
    int resultult;

    public UF(int n) {
        item = new int[n + 1];
        resultult = n;
        for (int i = 0; i < n; i++) item[i] = i;
    }

    public int find(int x) {
        if (x != item[x]) {
            return (item[x] = find(item[x]));
        }
        return x;
    }

    public void union_connect(int x, int y) {
        int x_item = find(x);
        int y_item = find(y);

        if (x_item != y_item) {
            item[y_item] = x_item;
            resultult--;
        }
    }
}
